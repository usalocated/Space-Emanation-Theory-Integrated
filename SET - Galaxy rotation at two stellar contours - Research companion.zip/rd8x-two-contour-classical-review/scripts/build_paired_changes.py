"""Reconstruct the two-contour table from the original observational and forecast CSVs."""
import argparse
import csv
from math import isclose
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODELS = {
    "baryons": "gr",
    "nfw_primary": "klypin_all",
    "nfw_relaxed": "klypin_relaxed",
    "nfw_dutton_maccio": "dutton_maccio",
    "set": "set",
}


def load_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as source:
        return list(csv.DictReader(source))


def forecasts(path):
    return {
        (row["galaxy"], row["model"]): float(row["median"])
        for row in load_rows(path)
        if row["gas_model"] == "measured"
    }


def build(work, output):
    inner = {r["galaxy"]: r for r in load_rows(work / "audit8/flat_curve_audit_all18.csv")}
    outer = {r["galaxy"]: r for r in load_rows(work / "improved40_boundary/measured26.csv")}
    forecasts_inner = forecasts(work / "new40_model/final/forecasts.csv")
    forecasts_outer = forecasts(work / "improved40_boundary/forecasts26/forecasts.csv")
    result = []
    for galaxy in sorted(inner.keys() & outer.keys()):
        a, b = inner[galaxy], outer[galaxy]
        r1, r2 = float(a["R_kpc"]), float(b["radius_kpc"])
        onset = float(a["tail_start_kpc"])
        row = {
            "galaxy": galaxy, "radius_25p5_kpc": r1, "radius_26p5_kpc": r2,
            "outer_flat_onset_kpc": onset, "both_on_flat": int(min(r1, r2) >= onset),
            "ring_error_25p5_kms": float(a["err_same_sign"]),
            "ring_error_26p5_kms": float(b["observed_err_correlated_endpoints_kms"]),
        }
        pairs = {"observed": (float(a["observed_kms"]), float(b["observed_kms"]))}
        for display, model in MODELS.items():
            v1, v2 = forecasts_inner[galaxy, model], forecasts_outer[galaxy, model]
            assert isclose(v1, float(a[model + "_kms"]), abs_tol=1e-9)
            if model != "gr":
                assert isclose(v2, float(b[model + "_speed"]), abs_tol=1e-9)
            pairs[display] = v1, v2
        for name, (v1, v2) in pairs.items():
            row[name + "_25p5_kms"] = v1
            row[name + "_26p5_kms"] = v2
            row[name + "_change_kms"] = v2 - v1
        result.append(row)
    if len(result) != 16:
        raise ValueError(f"Expected 16 galaxies with both measured contours, found {len(result)}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as target:
        writer = csv.DictWriter(target, fieldnames=result[0].keys())
        writer.writeheader()
        writer.writerows(result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("research_work", type=Path, nargs="?", default=ROOT / "inputs/work",
                        help="Research input directory (defaults to the bundled inputs/work)")
    parser.add_argument("--output", type=Path, default=ROOT / "data/paired-changes.csv")
    args = parser.parse_args()
    build(args.research_work, args.output)
