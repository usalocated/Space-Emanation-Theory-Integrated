"""Plot predicted and observed circular-speed changes between two photometric contours."""
import argparse
import csv
from pathlib import Path
from statistics import median

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
INK = "#1c303a"
MID = "#4a5d65"
MODELS = [
    ("baryons", "Resolved baryons", "#704C89", "s"),
    ("nfw_primary", "Baryons + fixed NFW", "#AE521B", "^"),
    ("set", "SET", "#007865", "D"),
]


def pretty_name(name):
    for catalog in ("NGC", "UGC", "DDO"):
        if name.startswith(catalog):
            return f"{catalog} {int(name[len(catalog):])}"
    return name


def make_figure(data, outdir):
    with data.open(encoding="utf-8", newline="") as file:
        rows = sorted(csv.DictReader(file), key=lambda r: float(r["observed_change_kms"]))
    observed = [float(r["observed_change_kms"]) for r in rows]
    labels = [pretty_name(r["galaxy"]) for r in rows]
    y = list(range(len(rows)))
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 10, "text.color": INK,
        "axes.labelcolor": INK, "xtick.color": MID, "ytick.color": INK,
        "axes.unicode_minus": True, "pdf.fonttype": 42, "ps.fonttype": 42,
    })
    fig, axes = plt.subplots(1, 3, figsize=(11.4, 8.4), sharey=True)
    fig.subplots_adjust(left=.133, right=.971, bottom=.188, top=.759, wspace=.12)
    fig.text(.043, .951, "How circular speed changes between two stellar contours",
             va="top", fontsize=20, weight="bold")
    fig.text(.045, .9, "Outer (26.5) minus inner (25.5 mag arcsec⁻²) speed for the same 16 galaxies.",
             va="top", fontsize=12, color=MID)
    fig.text(.045, .863, "Black tick  =  observed change       •       Colored symbol  =  predicted change",
             va="top", fontsize=10.1, color=INK)
    for ax, (model, title, color, marker) in zip(axes, MODELS):
        predicted = [float(r[f"{model}_change_kms"]) for r in rows]
        error = median(abs(p - o) for p, o in zip(predicted, observed))
        ax.set_title(title, fontsize=13.5, loc="left", pad=28, fontweight="bold", color=color)
        ax.text(0, 1.016, f"Median absolute error   {error:.2f} km/s", transform=ax.transAxes,
                ha="left", va="bottom", fontsize=9.5, color=MID)
        for position in y:
            if position % 2 == 0:
                ax.axhspan(position - .49, position + .49, color="#f2f5f5", lw=0, zorder=0)
        ax.axvline(0, color="#a7b6ba", lw=.9, zorder=1)
        ax.hlines(y, observed, predicted, color=color, linewidth=1.5, alpha=.68, zorder=2)
        ax.scatter(predicted, y, marker=marker, s=34, facecolor=color, edgecolor="white",
                   linewidth=.5, zorder=3)
        ax.plot(observed, y, "|", ls="", color="#10191f", markeredgewidth=1.6,
                markersize=10, zorder=4)
        ax.set_xlim(-70, 23)
        ax.set_xticks([-60, -40, -20, 0, 20])
        ax.tick_params(axis="x", length=3, pad=5)
        ax.tick_params(axis="y", length=0, pad=7)
        ax.spines[["left", "right", "top"]].set_visible(False)
        ax.spines["bottom"].set_color("#b1bfc3")
    axes[0].set_yticks(y, labels, fontsize=10.2)
    axes[0].set_ylim(len(y)-.45, -.55)
    fig.text(.551, .119, "Change in circular speed, Δv (km/s)",
             fontsize=12, ha="center")
    fig.text(.045, .064, "The connecting line shows the error in each predicted change. Each prediction uses the median speed forecast at each contour.",
             fontsize=9.7, color=MID)
    fig.text(.045, .04, "The halo uses the fixed Klypin all-halo calibration. Central values are shown. Data: SPARC rotation curves and S⁴G photometry.",
             fontsize=9.7, color=MID)
    outdir.mkdir(parents=True, exist_ok=True)
    base = outdir / "02-between-contour-changes"
    fig.savefig(base.with_suffix(".pdf"), metadata={"Title": "Between-contour circular-speed changes"})
    fig.savefig(base.with_suffix(".png"), dpi=240)
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", default=ROOT / "data/paired-changes.csv", type=Path)
    parser.add_argument("--output-dir", default=ROOT / "figures", type=Path)
    args = parser.parse_args()
    make_figure(args.data, args.output_dir)
