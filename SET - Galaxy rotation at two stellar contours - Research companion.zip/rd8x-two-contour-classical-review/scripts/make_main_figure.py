"""Rebuild the image and boundary-speed comparison from packaged data."""

import argparse
import bisect
import csv
from pathlib import Path

import pypdfium2 as pdfium
from reportlab.lib.colors import HexColor, white
from reportlab.pdfgen.canvas import Canvas


ROOT = Path(__file__).resolve().parents[1]
W, H = 768, 608
INK, GRAY, RING = "#142732", "#4C6068", "#4A5255"
MODELS = [("baryons", "Baryons only", "#704C89", "square"),
          ("nfw", "Baryons + fixed NFW halo", "#AE521B", "triangle"),
          ("set", "SET", "#007865", "diamond")]
ISOPHOTES = {"25.5": ("#986209", []), "26.5": ("#007F96", [3, 2])}


def label(c, x, y, value, size=9, color=INK, bold=False, center=False, right=False):
    c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
    c.setFillColor(HexColor(color))
    if center:
        c.drawCentredString(x, y, value)
    elif right:
        c.drawRightString(x, y, value)
    else:
        c.drawString(x, y, value)


def line(c, x1, y1, x2, y2, color, width=0.7, dash=()):
    c.setStrokeColor(HexColor(color))
    c.setLineWidth(width)
    c.setDash(list(dash))
    c.line(x1, y1, x2, y2)
    c.setDash([])


def mark(c, x, y, color, shape, size=4):
    c.setFillColor(HexColor(color))
    c.setStrokeColor(white)
    c.setLineWidth(0.8)
    if shape == "square":
        c.rect(x-size, y-size, size*2, size*2, stroke=1, fill=1)
        return
    vertices = [(0, 1.3), (1.15, -0.85), (-1.15, -0.85)] if shape == "triangle" else [
        (0, 1.4), (1.1, 0), (0, -1.4), (-1.1, 0)]
    path = c.beginPath()
    for i, (dx, dy) in enumerate(vertices):
        if i == 0:
            path.moveTo(x+dx*size, y+dy*size)
        else:
            path.lineTo(x+dx*size, y+dy*size)
    path.close()
    c.drawPath(path, fill=1, stroke=1)


def read_rows(data, target):
    lines = (data / (target + "_rotmod.dat")).read_text().splitlines()
    return [tuple(map(float, s.split()[:3])) for s in lines if s and not s.startswith("#")]


def curve_panel(c, points, predictions, bottom, xlimit, ylimits, xticks, yticks):
    left, right, top = 276, 743, bottom+151
    X = lambda radius: left+(right-left)*radius/xlimit
    Y = lambda speed: bottom+151*(speed-ylimits[0])/(ylimits[1]-ylimits[0])

    for tick in yticks:
        line(c, left, Y(tick), right, Y(tick), "#DCE1E2", 0.45)
        label(c, left-6, Y(tick)-3, str(tick), 8.3, GRAY, right=True)
    line(c, left, bottom, right, bottom, "#7B898C")
    line(c, left, bottom, left, top, "#7B898C")
    for tick in xticks:
        line(c, X(tick), bottom-3, X(tick), bottom, "#7B898C")
        label(c, X(tick), bottom-13, str(tick), 8.3, GRAY, center=True)
    label(c, (left+right)/2, bottom-28, "Radius (kpc)", 9.5, center=True)
    c.saveState()
    c.translate(left-32, (bottom+top)/2)
    c.rotate(90)
    label(c, 0, 0, "Circular speed (km/s)", 9.5, center=True)
    c.restoreState()

    for row in predictions:
        radius, mu = float(row["radius_kpc"]), row["mu"]
        color, dash = ISOPHOTES[mu]
        line(c, X(radius), bottom, X(radius), top+3, color, 0.75, dash)
        label(c, X(radius), top+7, mu, 8.4, color, bold=True, center=True)

    path = c.beginPath()
    for i, (radius, speed, error) in enumerate(points):
        assert 0 <= radius <= xlimit and ylimits[0] <= speed-error and speed+error <= ylimits[1]
        if i == 0:
            path.moveTo(X(radius), Y(speed))
        else:
            path.lineTo(X(radius), Y(speed))
    c.setStrokeColor(HexColor("#748084"))
    c.setLineWidth(0.65)
    c.drawPath(path)
    for radius, speed, error in points:
        x, y = X(radius), Y(speed)
        lo, hi = Y(speed-error), Y(speed+error)
        line(c, x, lo, x, hi, "#778185", 0.55)
        for end in (lo, hi):
            line(c, x-1.35, end, x+1.35, end, "#778185", 0.55)
        c.setFillColor(HexColor(RING))
        c.circle(x, y, 1.55, fill=1, stroke=0)
    for row in predictions:
        radius = float(row["radius_kpc"])
        # The interpolated speed identifies the corresponding point on the data line.
        j = bisect.bisect_left([r for r, v, e in points], radius)
        r0, v0, _ = points[j-1]
        r1, v1, _ = points[j]
        assert abs(v0+(v1-v0)*(radius-r0)/(r1-r0)-float(row["observed_kms"])) < 1e-7
        for key, _, color, symbol in MODELS:
            mark(c, X(radius), Y(float(row[key+"_median"])), color, symbol, 4.6)


def build(data, out):
    out.mkdir(parents=True, exist_ok=True)
    base = out / "01-two-galaxy-comparison"
    pdfpath = base.with_suffix(".pdf")
    c = Canvas(str(pdfpath), pagesize=(W, H), invariant=1, pageCompression=1)
    c.setTitle("Galaxy rotation at two stellar boundaries")
    label(c, 24, 574, "Galaxy rotation at two stellar boundaries", 24, bold=True)
    label(c, 25, 553, "Two galaxies measured at the same pair of 3.6 µm surface-brightness levels", 12, GRAY)
    line(c, 24, 539, 744, 539, "#D3DBDC", 0.65)
    label(c, 25, 519, "Spitzer stellar contours", 10, bold=True)
    line(c, 25, 504, 40, 504, ISOPHOTES["25.5"][0], 1.3)
    label(c, 45, 501, "25.5", 9)
    line(c, 76, 504, 91, 504, ISOPHOTES["26.5"][0], 1.3, (3, 2))
    label(c, 96, 501, "26.5 mag/arcsec²", 9)
    label(c, 250, 519, "Rotation measurements and boundary predictions", 10, bold=True)
    line(c, 250, 504, 269, 504, RING, .7)
    line(c, 259.5, 501.1, 259.5, 506.9, RING, .7)
    c.setFillColor(HexColor(RING))
    c.circle(259.5, 504, 1.7, fill=1, stroke=0)
    label(c, 273, 501, "Observed", 9)
    for x, (_, text, color, shape) in zip((337, 431, 589), MODELS):
        mark(c, x, 504, color, shape, 3.25)
        label(c, x+9, 501, text, 9)

    with (data / "predictions.csv").open() as f:
        predictions = list(csv.DictReader(f))
    configs = [
        ("UGC05721", "UGC 5721 (NGC 3274)", 299, 7, (0, 110), range(8), range(0, 101, 20)),
        ("NGC3198", "NGC 3198", 72, 46, (-15, 185), range(0, 46, 5), range(0, 176, 25))]
    for g, name, y, xmax, ylim, xticks, yticks in configs:
        pairs = [row for row in predictions if row["galaxy"] == g]
        assert [row["mu"] for row in pairs] == ["25.5", "26.5"]
        label(c, 25, y+172, name, 15, bold=True)
        radii = " and ".join(f"{float(row['radius_kpc']):.2f}" for row in pairs)
        label(c, 276, y+172, "Contour radii  "+radii+" kpc", 10, GRAY)
        c.drawImage(str(data / (g+"-contours.png")), 25, y-17, 177, 177)
        curve_panel(c, read_rows(data, g), pairs, y-1, xmax, ylim, xticks, yticks)
    line(c, 24, 262, 744, 262, "#DBE2E3", .6)
    line(c, 24, 34, 744, 34, "#D3DBDC", .65)
    label(c, 25, 18, "Bars show published SPARC ring uncertainties. Model markers give median predictions at the two contour radii.", 8.9, GRAY)
    c.showPage()
    c.save()
    document = pdfium.PdfDocument(str(pdfpath))
    page = document[0]
    bitmap = page.render(scale=3)
    bitmap.to_pil().save(base.with_suffix(".png"), dpi=(216, 216))
    bitmap.close()
    page.close()
    document.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT/"data"/"main_figure")
    parser.add_argument("--out", type=Path, default=ROOT/"figures")
    args = parser.parse_args()
    build(args.data, args.out)
