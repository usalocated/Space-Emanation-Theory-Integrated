"""Reproduce the follow-up draw, boundary measurements, model checks and comparison table."""
import argparse
import bisect
import csv
import hashlib
import json
import math
import os
import random
import statistics
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / 'inputs' / 'work'
MODELS = ('set', 'uniform', 'gr', 'klypin_all', 'klypin_relaxed', 'dutton_maccio')
SOURCES = {
    '25.5': ('new40_model/final', 'new40_frame/forecast_inputs.csv',
             'new40_gas/annuli.csv', 'new40_frame/flux_sigma.csv'),
    '26.5': ('improved40_boundary/forecasts26', 'improved40_boundary/model_input26.csv',
             'improved40_boundary/extended_gas.csv', 'improved40_boundary/extended_flux_sigma.csv')
}
sys.dont_write_bytecode = True
sys.path.insert(0, str(WORK))
import forty_halo as halo
sys.path.insert(0, str(WORK / "new40_frame"))
from build_frame import census


def read(path):
    with path.open(newline='') as stream:
        return list(csv.DictReader(stream))


def indexed(path):
    rows = read(path)
    out = {r['galaxy']: r for r in rows}
    assert len(out) == len(rows), path
    return out


def forecasts(path):
    rows = read(path / 'forecasts.csv')
    out = {(r['galaxy'], r['gas_model'], r['model']): r for r in rows}
    assert len(out) == len(rows), path
    return out


def close(actual, target, title):
    if not math.isclose(actual, float(target), rel_tol=3e-11, abs_tol=1e-9):
        raise ValueError(f'{title}: calculated {actual}, archive {target}')


def verify_source_files():
    for name, key in (('new40_frame/freeze.json', 'hashes'), ('new40_model/final/forecast_lock.json', 'sha256')):
        for file, expected in json.loads((WORK / name).read_text())[key].items():
            if hashlib.sha256((WORK / file).read_bytes()).hexdigest() != expected:
                raise ValueError(f'Input differs from original source freeze: {file}')


def controls():
    parent = indexed(WORK / 'forty_sample/sampling_frame.csv')
    previous = indexed(WORK / 'forty_sample/sample40.csv')
    pool = sorted(g for g, x in parent.items() if x['has_catalog_vflat'] == '1'
                  and int(x['quality']) <= 2 and float(x['inclination_deg']) >= 30 and g not in previous)
    draw = random.Random(20261119).sample(pool, 40)
    assert len(parent) == 175 and len(previous) == 40 and len(pool) == 83
    assert pool == list(indexed(WORK / 'new40_frame/historical_pool.csv'))
    assert draw == list(indexed(WORK / 'new40_frame/historical_draw.csv'))
    return pool, {g: i for i, g in enumerate(draw, 1)}


def contour(row, catalog, gas, level):
    suffix = level.replace('.', 'p')
    photo = catalog.get(row['s4g_name'], {})
    radius_arcsec, ellip = photo.get('sma1_' + suffix), photo.get('ellip1_' + suffix)
    if not radius_arcsec or not ellip:
        return None, 'missing isophote'
    p = 1 - float(ellip)
    inc = math.radians(float(row['inclination_deg']))
    q2 = (p**2 - math.cos(inc)**2) / math.sin(inc)**2
    radius = float(radius_arcsec) * math.pi / 648000 * 1000 * float(row['distance_mpc'])
    if not (0 < p <= 1 and 0 < q2 <= 1):
        return radius, 'incompatible oblate deprojection'
    if not float(row['min_kinematic_radius_kpc']) <= radius <= float(row['max_kinematic_radius_kpc']):
        return radius, 'outside measured curve'
    return radius, 'scored' if row['galaxy'] in gas else 'missing measured gas profile'


def measure(raw, galaxy, radius):
    rows = [list(map(float, v.split()[:6])) for v in raw.read(galaxy + '_rotmod.dat').decode().splitlines()
            if v.strip() and not v.lstrip().startswith('#')]
    radii = [r[0] for r in rows]
    hi = bisect.bisect_left(radii, radius)
    if hi < len(radii) and abs(radii[hi] - radius) < 1e-8:
        lo = hi
    elif hi > 0 and abs(radii[hi - 1] - radius) < 1e-8:
        lo = hi = hi - 1
    else:
        lo = hi - 1
    assert 0 <= lo <= hi < len(radii)
    x, y = rows[lo], rows[hi]
    t = (radius - x[0]) / (y[0] - x[0]) if lo != hi else 0.
    def interp(x1, x2):
        return (1 - t) * x1 + t * x2
    baryon_v2 = interp(halo.baryonic_v2(*x[3:6]), halo.baryonic_v2(*y[3:6]))
    return x[0], y[0], t, interp(x[1], y[1]), interp(x[2], y[2]), baryon_v2


def compare(rows, audit, model, raw, galaxy, radius):
    lo, hi, w, observed, err, baryon_v2 = measure(raw, galaxy, radius)
    r = audit[galaxy]
    close(radius, r['R_kpc'], galaxy)
    close(w, r['weight_hi'], galaxy)
    gm_sun, kpc_m = 1.3271244e20, 3.085677581491367e19
    mstar = float(r['m_disk']) + float(r['m_bulge'])
    mtot = mstar + float(r['m_gas'])
    q = 4 * math.pi * math.sqrt(2 * gm_sun * mtot * (kpc_m * radius)**3)
    effective, geom = (float(r['measured_' + k]) for k in ('A_eff_m2', 'A_geom_m2'))
    close(q, r['measured_Qref_m3s'], 'source normalization')
    assert effective > 0 and effective <= geom * (1 + 1e-12)
    close(q / effective / 1000., r['measured_Seff_kms'], 'escape burden')
    checks = dict(set=q / effective / math.sqrt(2) / 1000.,
                  uniform=q / geom / math.sqrt(2) / 1000., gr=math.sqrt(baryon_v2))
    halos = [halo.population_halo(mstar), halo.population_halo(mstar, True), halo.dutton_maccio_halo(mstar)]
    for name, h in zip(MODELS[3:], halos):
        checks[name] = math.sqrt(baryon_v2 + h.v2(radius))
    rows.update(lower_ring_kpc=lo, upper_ring_kpc=hi, upper_weight=w, observed_kms=observed,
                obs_ring_error_kms=err, disk_plus_bulge_msun=mstar, gas_msun=float(r['m_gas']),
                Qref_m3s=q, A_geom_m2=geom, A_eff_m2=effective)
    for name in MODELS:
        item = model[galaxy, 'measured', name]
        close(checks[name], item['nominal'], galaxy + ' ' + name)
        value = float(item['median'])
        rows[name + '_nominal_kms'] = checks[name]
        rows[name + '_kms'] = value
        for quantile in ('p025', 'p16', 'p84', 'p975'):
            rows[name + '_' + quantile + '_kms'] = float(item[quantile])
        residual = 100 * (value / observed - 1)
        rows[name + '_signed_error_pct'] = residual
        rows[name + '_absolute_error_pct'] = abs(residual)


def make_table(out):
    pool, rank = controls()
    frame = indexed(WORK / 'new40_frame/frame.csv')
    independent_frame = {row['galaxy']: row for row in census()}
    assert set(frame) == set(independent_frame)
    for g in frame:
        check = independent_frame[g]
        for key in ('scoreable_geometry', 'original40', 'original_catalog_gate', 'has_outline'):
            assert str(check[key]) == frame[g][key], (g, key)
        for key in ('distance_mpc', 'min_kinematic_radius_kpc', 'max_kinematic_radius_kpc'):
            close(check[key], frame[g][key], g)
    photos = {r['object']: r for r in read(WORK / 'shape_geometry/s4g_catalog_excerpt.csv')}
    old = indexed(WORK / 'audit8/flat_curve_audit_all18.csv')
    later = indexed(WORK / 'improved40_boundary/measured26.csv')
    coverage = {}
    predictions = {}
    for level, (location, _, annuli, _) in SOURCES.items():
        measured_gas = {r['galaxy'] for r in read(WORK / annuli)}
        coverage[level] = {g: contour(frame[g], photos, measured_gas, level) for g in pool}
        predictions[level] = indexed(WORK / location / 'model_audit.csv'), forecasts(WORK / location)
    faint = indexed(WORK / SOURCES['26.5'][1])
    assert set(faint) == {g for g, (_, status) in coverage['26.5'].items() if status == 'scored'}
    for g, source in faint.items():
        shape = photos[frame[g]['s4g_name']]
        close(float(source['a25_arcsec']), shape['sma1_26p5'], g + ' faint semimajor axis')
        close(float(source['p25']), 1 - float(shape['ellip1_26p5']), g + ' faint axis ratio')
    primary = {g for g, x in coverage['25.5'].items() if x[1] == 'scored'}
    second = {g for g, x in coverage['26.5'].items() if x[1] == 'scored'}
    assert len(primary) == 18 and primary == set(old)
    assert second == set(later) and second - primary == {'UGC06930'}
    assert primary - second == {'NGC0247', 'UGC04278'} and len(primary & rank.keys()) == 10
    reasons = Counter(coverage['25.5'][g][1] for g in rank)
    assert reasons == {'missing isophote': 22, 'incompatible oblate deprojection': 5,
                       'outside measured curve': 3, 'scored': 10}
    ledger = []
    with ZipFile(WORK / 'forty_sample/raw/Rotmod_LTG.zip') as raw:
        for galaxy in sorted(primary):
            for level in SOURCES:
                radius, status = coverage[level][galaxy]
                rec = dict(galaxy=galaxy, contour_ab_mag_arcsec2=level, primary_draw_rank=rank.get(galaxy, ''),
                           status=status, paired=int(galaxy in second), R_kpc=radius,
                           max_measured_radius_kpc=float(frame[galaxy]['max_kinematic_radius_kpc']))
                if status == 'scored':
                    compare(rec, *predictions[level], raw, galaxy, radius)
                    reference = (old if level == '25.5' else later)[galaxy]
                    close(rec['observed_kms'], reference['observed_kms'], galaxy)
                    for name in MODELS if level == '25.5' else ('set', *MODELS[3:]):
                        close(rec[name + '_kms'], reference[name + ('_kms' if level == '25.5' else '_speed')], galaxy)
                ledger.append(rec)
    out.parent.mkdir(exist_ok=True, parents=True)
    with out.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(dict.fromkeys(k for r in ledger for k in r)),
                                lineterminator='\n')
        writer.writeheader()
        writer.writerows(ledger)
    print('Second draw recovered: 40/83; 10 scored, plus 8 other covered galaxies. 34 speeds at 36 planned readings.')
    print('Faint-contour additional galaxy outside the 18: UGC06930. Noncovered faint radii: NGC0247, UGC04278.')
    print('Subset                                      ' + ' '.join(f'{m:>14s}' for m in MODELS))
    for level, paired in [('25.5', False), ('25.5', True), ('26.5', True)]:
        group = [r for r in ledger if r['contour_ab_mag_arcsec2'] == level and r['status'] == 'scored'
                 and (not paired or r['paired'])]
        name = f'{level}, ' + ('common galaxies' if paired else 'all primary') + f' (n={len(group)})'
        print(f'{name:44s}' + ' '.join(f'{statistics.median(r[m + "_absolute_error_pct"] for r in group):14.3f}'
                                       for m in MODELS))
    return ledger


def verify_figure_inputs(rows):
    by_boundary = {(r['galaxy'], r['contour_ab_mag_arcsec2']): r for r in rows}
    figure = ROOT / 'data/main_figure'
    with ZipFile(WORK / 'forty_sample/raw/Rotmod_LTG.zip') as rot:
        for panel in read(figure / 'predictions.csv'):
            g = panel['galaxy']
            r = by_boundary[g, panel['mu']]
            assert (figure / (g + '_rotmod.dat')).read_bytes() == rot.read(g + '_rotmod.dat')
            for column in ('observed_kms', 'observed_error_kms', 'radius_kpc'):
                target = {'radius_kpc':'R_kpc', 'observed_error_kms':'obs_ring_error_kms'}.get(column, column)
                close(float(panel[column]), r[target], g + ' main figure')
            for label, model in [('set', 'set'), ('nfw', 'klypin_all'), ('baryons', 'gr')]:
                for quantile in ('median', 'p16', 'p84'):
                    suffix = '' if quantile == 'median' else '_' + quantile
                    close(float(panel[label + '_' + quantile]), r[model + suffix + '_kms'], g + ' main figure')
    changes = read(ROOT / 'data/paired-changes.csv')
    assert len(changes) == 16
    for item in changes:
        g = item['galaxy']
        a, b = by_boundary[g, '25.5'], by_boundary[g, '26.5']
        names = {'observed':'observed', 'baryons':'gr', 'set':'set', 'nfw_primary':'klypin_all',
                 'nfw_relaxed':'klypin_relaxed', 'nfw_dutton_maccio':'dutton_maccio'}
        for label, model in names.items():
            delta = b[model + '_kms'] - a[model + '_kms']
            close(delta, item[label + '_change_kms'], g + ' change figure')


def replay_all():
    with tempfile.TemporaryDirectory() as tmp:
        for level, (path, input_file, gas, flux) in SOURCES.items():
            out = Path(tmp) / level
            subprocess.run([sys.executable, str(WORK / 'new40_model/predict.py'),
                            '--inputs', str(WORK / input_file), '--annuli', str(WORK / gas),
                            '--inclinations', str(WORK / 'new40_model/combined_inclinations.csv'),
                            '--flux', str(WORK / flux), '--out', str(out)], check=True,
                           env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, stdout=subprocess.DEVNULL)
            expected, test = forecasts(WORK / path), forecasts(out)
            assert test.keys() == expected.keys()
            diff = max(abs(float(r[k]) - float(expected[g][k])) for g, r in test.items()
                       for k in ('nominal', 'p025', 'p16', 'median', 'p84', 'p975'))
            assert diff < .001, (level, diff)
            print(f'Full {level} physical replay: {len(test)} model rows, max speed difference {diff:.9g} km/s.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true', help='Regenerate the 32,768-draw forecasts with NumPy.')
    parser.add_argument('--output', type=Path, default=ROOT / 'data/boundary-comparisons.csv')
    args = parser.parse_args()
    verify_source_files()
    rows = make_table(args.output)
    verify_figure_inputs(rows)
    if args.full:
        replay_all()


if __name__ == '__main__':
    main()
