# Two infrared boundaries in eighteen galaxies

This companion places SET, a uniform-loading control, Newtonian gravity from the resolved baryons and three population-calibrated NFW halo forecasts at the same published stellar contours. The observed speed at each contour comes from the galaxy’s measured rotation curve. The input catalogues, numerical source profiles, forecasts and scoring code are included for an offline replay.

## Start here

Run these commands from the extracted companion directory.

```sh
python3 scripts/reproduce.py
python3 scripts/reproduce.py --full
```

The first command uses Python’s standard library. It recovers the follow-up draw, reconstructs the survey coverage, interpolates the SPARC rotation measurements, recalculates all six nominal speeds and scores the archived prediction medians. It writes `data/boundary-comparisons.csv` and checks the plotted observations, predicted speeds and paired changes against these results. The second command requires NumPy. It additionally repeats the three-dimensional source-moment integrals and 32,768 nuisance draws for both contour releases, including every forecast family in the archives. The verification compares the nominal result, median and four quantiles for every archived forecast with a tolerance of 0.001 km/s. Forecasts are recomputed in a temporary directory. Use `--output path.csv` for a separate scoring table.

## Follow the sample

The follow-up begins with all 175 SPARC IDs. The historical catalogue gate requires a published flat speed, quality 1 or 2, and inclination of at least 30 degrees. Removing the 40 IDs from the first RD8x draw leaves 83 eligible IDs. The availability flag for the flat speed enters the gate. The boundary speed measured later is read from individual rotation rings. The follow-up samples 40 IDs without replacement from the ASCII-sorted list with CPython’s `random.Random(20261119).sample(pool, 40)`.

At the 25.5 AB mag arcsec⁻² contour, 10 of this second draw have scores. The other 30 comprise 22 without the released isophote, five with an incompatible oblate deprojection, and three with the contour outside the measured rotation curve, applying those reasons in that order. Extending the identical checks to the 43 undrawn IDs adds eight covered galaxies. This gives 18 total at 25.5. The original RD8x draw, the follow-up draw, and the eight additional covered galaxies have distinct membership records. Some follow-up objects also appeared in earlier worked examples. The original selection, the frozen protocol and historical inclusion flags are in `inputs/work/forty_sample`, `inputs/work/new40_frame` and `inputs/work/new40_study/protocol.txt`.

At 26.5 AB mag arcsec⁻², 16 of the 18 have a second comparison. For NGC 247 and UGC 4278 the respective contour radii are 15.49 and 7.03 kpc, beyond the last observed rings at 14.54 and 6.69 kpc. The CSV retains these two entries with a coverage status and blank speed columns. There are 36 planned readings, 34 measured and scored, on 18 distinct galaxies. In the entire residual pool there is one further faint-contour comparison, UGC 6930. Its inferred squared oblate axis ratio is negative at 25.5 and positive at 26.5. Its faint-only forecast and observation are in the full archive. It is outside the 18-object primary-contour cohort.

## The calculation

1. Read the semimajor axis and ellipticity at the 3.6 μm S⁴G isophote and convert the semimajor axis to kpc with the adopted SPARC distance. Read the same contour for every model. Use the measured inclination and apparent ellipticity for the oblate deprojection.
2. For the SET forecast, take the fixed disk and bulge mass-to-light ratios 0.5 and 0.7 in solar units and a factor of 1.33 on atomic H I mass. Build the adopted three-dimensional shell distribution from the stellar profiles and measured or observer-reconstructed H I annuli. The total adopted source mass normalizes `Q = 4π√(2GMR³)`. For the loading `s` on the surface, `A_eff = (∫s dA)² / ∫s² dA`. The benchmark orbit prescription is `V_SET = Q / (√2 A_eff)`. Its uniform-loading control replaces the effective area with the geometric surface area. The kernel, deprojection and orbit prescription specify the response family being tested.
3. For the baryons-only Newtonian circular speed, form `V_g|V_g| + 0.5 V_d|V_d| + 0.7 V_b|V_b|` from SPARC’s signed gas, disk and bulge templates. Interpolate this signed sum in squared-speed units between the bracketing rings before taking the square root. The weak-field baryons-only calculation uses the resolved disk geometry.
4. For each fixed halo, add its squared NFW circular speed to the same baryonic sum. The Moster stellar-to-halo relation fixes the halo mass. The concentration prescriptions are Klypin all halos, Klypin relaxed halos, and Dutton–Macciò. `inputs/work/forty_halo.py` contains the constants, mass convention, dark fractions, and original references. The population recipes use no galaxy-specific halo fit to the observed velocities.
5. For the observation, interpolate the measured speed between the two surrounding SPARC rings directly in km/s. The tabulated uncertainty uses the weighted linear sum of the two quoted errors, the fully positively correlated endpoint convention. A measured covariance matrix across these interpolated radii is unavailable here. The archived model medians use the same nuisance draws with distance, luminosity, H I flux, and inclination uncertainties as specified in the scripts. Model and observational uncertainties are tabulated separately. The error scored is `100 |V_median / V_obs − 1|`.

The `_nominal_kms` and `_kms` model columns distinguish the central-input calculation from the median of the common source draws. The p025, p16, p84 and p975 columns report the corresponding forecast quantiles. Each galaxy contributes one value to a given contour median. The two readings within an object are paired.

## Reproduce the figures

```sh
python3 scripts/build_paired_changes.py inputs/work
python3 scripts/make_main_figure.py
python3 scripts/make_delta_figure.py
```

The first figure uses ReportLab, pypdfium2 and Pillow. The second uses Matplotlib. The paired table builder uses the standard library. The figure inputs include the original SPARC rings for both pictured galaxies, the measured contour overlays, the plotted numbers and their provenance. The paired comparison includes all 16 common galaxies, with all three halo recipes available in the CSV.

## Numerical inputs and provenance

- `inputs/work/new40_study/sources.txt` and `inputs/work/new40_gas/gas_source_index.csv` identify the survey releases and galaxy-specific gas data. The annuli and stellar profiles needed by the forecasts are shipped. The numerical replay starts at these source measurements. Re-extracting gas profiles from every original telescope image or published figure requires the corresponding original maps or articles.
- `inputs/work/new40_model/final` stores the full 25.5 forecasts. `inputs/work/improved40_boundary/forecasts26` stores the full 26.5 forecasts. The latter includes UGC 6930. In the fainter-model input file the legacy column names `a25_arcsec` and `p25` hold the 26.5 measurements. The fast script checks them directly against the 26.5 catalogue columns.
- `inputs/work/forty_sample/raw/Rotmod_LTG.zip` contains the full SPARC rotation tables, including the observed speeds and the independently tabulated baryonic force contributions. `inputs/work/shape_sparc/BulgeDiskDec_LTG.zip` contains the stellar profile inputs.
- `inputs/SHA256SUMS.txt` records all numerical source-tree file hashes. The original primary-contour draw and forecast locks are also supplied. The fainter-contour comparison is a subsequent sensitivity study.
