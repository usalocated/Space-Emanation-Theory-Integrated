"""All measured gas profiles share one optical boundary, full gas mass, and one field normalization."""
import argparse
import collections
import csv
import io
import math
import sys
from pathlib import Path
from zipfile import ZipFile

import numpy as np

D = Path(__file__).resolve().parent
W = D.parent
sys.path.insert(0, str(W/'uncertainty_cauchy'))
sys.path.insert(0, str(W/'uncertainty_speeds'))
import moments as fm
import iorio_profiles
import things_field

PREFERRED = {
    'NGC2903':('THINGS','luminous_contour'),
    'NGC2976':('THINGS','luminous_contour'),
    'NGC3521':('THINGS','luminous_contour'),
    'NGC5055':('THINGS','luminous_contour'),
    'NGC5585':('Hua','published_profile'),
    'DDO168':('Iorio','half_ring'),
    'UGCA444':('Iorio','half_ring'),
}
FAMILIES=('isotropic','homothetic')
FIELDS=('draft_surface_kms','field_surface_kms','local_circular_kms')

def read(p):
    with p.open() as f:return list(csv.DictReader(f))
def write(p,v):
    with p.open('w',newline='') as f:
        writer=csv.DictWriter(f,v[0].keys(),lineterminator='\n')
        writer.writeheader();writer.writerows(v)

def measured_profiles(root):
    sources={r['galaxy']:r for r in read(root/'shape_law/source_chain.csv')}
    radio=collections.defaultdict(list)
    for r in read(root/'uncertainty_gas/observed_gas_annuli.csv'):
        radio[r['galaxy'],r['radial_assignment']].append(r)
    iorio=read(root/'uncertainty_speeds/iorio_gas_rings.csv')
    hua=read(root/'uncertainty_speeds/hua_figure1_data.csv')
    with ZipFile(root/'shape_sparc/BulgeDiskDec_LTG.zip') as z:
        for g in PREFERRED:
            x=sources[g]
            R,rl,q=map(float,[x['Rb_kpc'],x['Rlast_kpc'],x['eta']]);t=rl/R
            dims=(R,rl,q)
            masses=np.array([float(x[k]) for k in ('Mstar_disk_Msun','Mstar_bulge_Msun','MHI_times_1p33_Msun')])
            total=masses.sum();fg=masses[2]/total
            dens=np.loadtxt(io.BytesIO(z.read(g+'.dens')))
            for variant in ['luminous_contour','aligned_thin_gas_disk']:
                if (g,variant) in radio:
                    a,stars,_=fm.shell_mass(dens,R,rl,float(x['RHI_1Msun_per_pc2_kpc']),*masses,12)
                    b,gas=things_field.observed_shells(radio[g,variant],t,12)
                    yield g,'THINGS',variant,dims,total,np.r_[a,b],np.r_[stars,np.zeros(len(b))],np.r_[np.zeros(len(a)),fg*gas]
            records=[r for r in iorio if r['galaxy']==g]
            if records:
                h=np.array([[float(r[k]) for k in ('r_arcsec','HI_Msun_per_pc2','e_HI_Msun_per_pc2')] for r in records])
                for edge in ('half_ring','last_center'):
                    a,s,gas,*_=iorio_profiles.measured_templates(dens,h,x,edge)
                    yield g,'Iorio',edge,dims,total,a,s,gas
            records=[r for r in hua if r['galaxy']==g and r['kind']=='surface_density']
            if records:
                rs,sd,sb=dens.T;rg,sg=np.array([[float(r['kpc']),float(r['value'])] for r in records]).T
                a,da=fm.grid_weights(np.unique(np.r_[rs,rg,0,R,rl]),12)
                v=np.zeros((3,len(a)))
                for j,(r0,s) in enumerate(((rs,sd),(rs,sb),(rg,sg))):
                    if masses[j]>0:
                        v[j]=a*da*np.interp(a,r0,s,right=0);v[j]*=masses[j]/(total*v[j].sum())
                yield g,'Hua','published_profile',dims,total,a/R,v[0]+v[1],v[2]

def source_predictions(root):
    u,w=np.polynomial.legendre.leggauss(96);u,w=(u+1)/2,w/2
    rows=[]
    for g,src,variant,(R,rl,q),total,a,stars,gas in measured_profiles(root):
        t=rl/R; mass=stars+gas
        assert abs(mass.sum()-1)<1e-10
        keep=mass>0;a,stars,gas,mass=a[keep],stars[keep],gas[keep],mass[keep]
        for family in FAMILIES:
            ref=fm.evaluate(a,mass,q,t,family,1.,w,u,R*fm.KPC,total)
            amp=float(ref['lambda_amplitude']);v_ref=ref['Seff_div_sqrt2_kms']
            for role,rad in [('image',1.),('last',t)]:
                now=ref if rad==1 else fm.evaluate(a/rad,mass,q,1.,family,1.,w,u,rad*R*fm.KPC,total)
                f=math.sqrt(amp/now['lambda_amplitude'])
                surface=now['Seff_div_sqrt2_kms']*f;local=now['equatorial_vc_kms']*f
                expected=ref['equatorial_vc_kms' if role=='image' else 'last_equatorial_vc_kms']
                assert abs(local-expected)<1e-9
                assert abs(now['A_geom_over_A_eff']-1-now['CV_squared'])<1e-10
                assert abs(now['current_flux_over_4piGMenc']-1)<1e-9
                draft=v_ref/math.sqrt(rad)
                rows.append(dict(galaxy=g,source=src,radial_assignment=variant,preferred_gas=int(PREFERRED[g]==(src,variant)),tensor=family,
                    role=role,radius_kpc=rad*R,boundary_kpc=R,adopted_total_gas_Msun=total*gas.sum(),
                    gas_fraction_inside=gas[a<rad].sum()/gas.sum(),baryonic_fraction_inside=mass[a<rad].sum(),
                    boundary_gas_fraction_inside=gas[a<1].sum()/gas.sum(),Cauchy_concentration=now['A_geom_over_A_eff'],
                    boundary_Cauchy_concentration=ref['A_geom_over_A_eff'],boundary_Seff_kms=v_ref*math.sqrt(2),
                    boundary_Seff_div_sqrt2_kms=v_ref,boundary_normalization=amp,draft_surface_kms=draft,
                    field_surface_kms=surface,local_circular_kms=local))
    assert len(rows)==56
    return rows

def compare_earlier(root,rows):
    old=[('THINGS',r['galaxy'],r['radial_assignment'],r['response_family'],r['role'],float(r['Seff_div_sqrt2_kms']),float(r['local_circular_v_kms'])) for r in read(root/'uncertainty_cauchy/things_field_predictions.csv') if r['radial_assignment']!='generic_RHI_template']
    for src,filename,surfkey in [('Iorio','iorio_field_predictions.csv','Seff_div_sqrt2_kms'),('Hua','hua_field_predictions.csv','predicted_image_Seff_div_sqrt2_kms')]:
        for r in read(root/'uncertainty_speeds'/filename):
            if r['case']!='full_baryons_global_Q':continue
            for role in ('image','last'):
                old.append((src,r['galaxy'],r.get('last_ring_extent','published_profile'),r['response_family'],role,float(r[surfkey]) if role=='image' else None,float(r['predicted_'+role+'_local_kms'])))
    lookup={(r['source'],r['galaxy'],r['radial_assignment'],r['tensor'],r['role']):r for r in rows}
    errs=[]
    for s,g,v,f,role,surf,local in old:
        r=lookup[s,g,v,f,role]
        errs.append(abs(local-r['local_circular_kms']))
        if surf is not None:errs.append(abs(surf-r['field_surface_kms']))
    assert len(old)==len(rows) and max(errs)<1e-7,max(errs)
    return max(errs)

def summarize(root,rows):
    targets={r['galaxy']:r for r in read(root/'forty_results/galaxy_results.csv')}
    details=[];main=[];sources=[]
    for g in PREFERRED:
        for role in ('image','last'):
            rr=[r for r in rows if r['galaxy']==g and r['role']==role]
            obs=float(targets[g][role+'_obs_kms']); err=float(targets[g][role+'_obs_error_kms'])
            base=dict(galaxy=g,role=role,radius_kpc=rr[0]['radius_kpc'],observed_kms=obs,obs_err_kms=err)
            for r in rr:
                h=dict(**r,observed_kms=obs,obs_err_kms=err)
                for k in FIELDS:h[k.replace('_kms','_APE_pct')]=100*abs(r[k]/obs-1)
                details.append(h)
            selected=[r for r in rr if r['preferred_gas'] and r['tensor']=='isotropic'][0]
            s=dict(**base,preferred_source=selected['source'],preferred_radial_assignment=selected['radial_assignment'],preferred_tensor='isotropic',
                   preferred_gas_fraction_inside=selected['gas_fraction_inside'],preferred_boundary_Seff_kms=selected['boundary_Seff_kms'],
                   preferred_boundary_Seff_div_sqrt2_kms=selected['boundary_Seff_div_sqrt2_kms'],
                   min_gas_fraction_inside=min(r['gas_fraction_inside'] for r in rr),max_gas_fraction_inside=max(r['gas_fraction_inside'] for r in rr))
            for k in FIELDS:
                s['preferred_'+k]=selected[k];s['scenario_min_'+k]=min(r[k] for r in rr);s['scenario_max_'+k]=max(r[k] for r in rr)
                s['preferred_'+k.replace('_kms','_APE_pct')]=100*abs(selected[k]/obs-1)
            main.append(s)
            for src in sorted(set(r['source'] for r in rr)):
                fitted=[r for r in rr if r['source']==src]
                z=dict(**base,source=src)
                for k in FIELDS:
                    z['min_'+k]=min(r[k] for r in fitted);z['max_'+k]=max(r[k] for r in fitted)
                sources.append(z)
    return details,main,sources

if __name__=='__main__':
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument('--work',type=Path,default=W);arg.add_argument('--out',type=Path,default=D)
    a=arg.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    f=source_predictions(a.work)
    write(a.out/'forecasts.csv',f)
    print('Worst difference vs previous matching per-object predictions',compare_earlier(a.work,f))
    rows,main,src=summarize(a.work,f)
    for name,data in [('scores.csv',rows),('per_galaxy.csv',main),('per_source.csv',src)]:write(a.out/name,data)
