"""Compare measured THINGS gas annuli with the original gas template at fixed stellar profile and global mass."""
import argparse
from collections import defaultdict
import io
from pathlib import Path
from zipfile import ZipFile
import numpy as np
from numpy.polynomial.legendre import leggauss
from moments import GMSUN,KPC,evaluate,grid_weights,load_csv,save_csv,shell_mass

HERE=Path(__file__).resolve().parent
def observed_shells(rows,t,order):
    radial=[]; values=[]
    for r in rows:
        low,high,frac=map(float,(r['rlo_ratio'],r['rhi_ratio'],r['gas_mass_fraction']))
        assert high>low>=0 and frac>=0
        # Uniform surface density within each narrow observed annulus; split both test radii exactly.
        cuts=np.unique(np.r_[low, [a for a in [1.,t] if low<a<high], high])
        a,da=grid_weights(cuts,order)
        weight=2*a*da*frac/(high**2-low**2)
        assert abs(sum(weight)-frac)<1.e-12
        radial.append(a);values.append(weight)
    a,m=np.concatenate(radial),np.concatenate(values)
    assert abs(m.sum()-1)<1.e-10
    return a,m

def forecast(root,order=12,angle=96):
    shell_rows=defaultdict(list)
    for row in load_csv(root/'uncertainty_gas/observed_gas_annuli.csv'):
        shell_rows[(row['galaxy'],row['radial_assignment'])].append(row)
    sources={r['galaxy']:r for r in load_csv(root/'shape_law/source_chain.csv')}
    names=sorted(set(n for n,model in shell_rows))
    assert names==['NGC2903','NGC2976','NGC3521','NGC5055']
    out=[]
    x,w=leggauss(angle);u,w=(1+x)/2,w/2
    with ZipFile(root/'shape_sparc/BulgeDiskDec_LTG.zip') as z:
        for g in names:
            s=sources[g];q=float(s['eta']);R=float(s['Rb_kpc']);t=float(s['Rlast_kpc'])/R
            masses=np.array([float(s[k]) for k in ('Mstar_disk_Msun','Mstar_bulge_Msun','MHI_times_1p33_Msun')])
            mt=masses.sum();fg=masses[2]/mt
            dens=np.loadtxt(io.BytesIO(z.read(g+'.dens')))
            ast,star,gas0=shell_mass(dens,R,R*t,float(s['RHI_1Msun_per_pc2_kpc']),*masses,order)
            srcs={'generic_RHI_template':(ast,gas0)}
            for label in ('luminous_contour','aligned_thin_gas_disk'):
                aobs,fobs=observed_shells(shell_rows[g,label],t,order)
                srcs[label]=(aobs,fg*fobs)
            for label,(ag,mg) in srcs.items():
                a=np.r_[ast,ag];m=np.r_[star,mg];ok=m>0
                a,m=a[ok],m[ok]
                assert abs(m.sum()-1)<1.e-12
                for family in ('isotropic','homothetic'):
                    # Evaluate uncalibrated field at both homothetic surfaces. At the last
                    # use the amplitude selected at the luminous boundary, not a new Q calibration.
                    at_boundary=evaluate(a,m,q,t,family,1.,w,u,R*KPC,mt)
                    amp=at_boundary['lambda_amplitude']
                    for role,r in [('image',1.),('last',t)]:
                        v=at_boundary if role=='image' else evaluate(a/r,m,q,1.,family,1.,w,u,R*KPC*r,mt)
                        av=amp/v['lambda_amplitude'];factor=np.sqrt(av)
                        row=dict(galaxy=g,radial_assignment=label,response_family=family,role=role,
                                 radius_kpc=R*r,gas_fraction_inside=mg[ag<r].sum()/fg,
                                 all_mass_fraction_inside=m[a<r].sum(),lambda_held_fixed=amp,
                                 Q_surf_m3s=v['Qsurf_m3s']*factor,I_surf_m4s2=v['Isurf_m4s2']*av,
                                 Q_ratio_to_global_reference_at_this_radius=factor,
                                 A_geom_m2=v['A_geom_m2'],A_eff_m2=v['A_eff_m2'],A_geom_over_A_eff=v['A_geom_over_A_eff'],
                                 source_flux_over_4piGM_inside=v['current_flux_over_4piGMenc'],
                                 Seff_div_sqrt2_kms=v['Seff_div_sqrt2_kms']*factor,
                                 local_S_kms=v['equatorial_local_S_kms']*factor,k_equator=v['k_equator'],
                                 local_circular_v_kms=v['equatorial_vc_kms']*factor)
                        assert abs(row['Q_surf_m3s']**2/row['I_surf_m4s2']/row['A_eff_m2']-1)<1.e-12
                        assert abs(row['source_flux_over_4piGM_inside']-1)<1.e-9
                        if role=='last':
                            assert abs(row['local_circular_v_kms']-at_boundary['last_equatorial_vc_kms'])<1.e-9
                        out.append(row)
    return out

def score(root,rows):
    obs={r['galaxy']:r for r in load_csv(root/'forty_results/galaxy_results.csv')}
    groups=defaultdict(list);joined=[]
    for r in rows:
        target=float(obs[r['galaxy']][r['role']+'_obs_kms'])
        for field in ('local_circular_v_kms','Seff_div_sqrt2_kms'):
            delta=r[field]-target
            joined.append(dict(galaxy=r['galaxy'],radial_assignment=r['radial_assignment'],response_family=r['response_family'],
                               role=r['role'],field=field,predicted_kms=r[field],observed_kms=target,residual_kms=delta,ape_pct=100*abs(delta/target)))
            groups[(r['radial_assignment'],r['response_family'],r['role'],field)].append((delta,delta/target))
    summary=[]
    for (g,f,role,field),e in groups.items():
        v=np.array(e)
        summary.append(dict(radial_assignment=g,response_family=f,role=role,field=field,n=len(e),
                            rmse_kms=np.sqrt(np.mean(v[:,0]**2)),median_ape_pct=100*np.median(abs(v[:,1]))))
    return joined,summary

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--work',type=Path,default=HERE.parent)
    ap.add_argument('--out',type=Path,default=HERE)
    args=ap.parse_args()
    rows=forecast(args.work)
    assert len(rows)==48
    save_csv(args.out/'things_field_predictions.csv',rows)
    scored,summary=score(args.work,rows)
    save_csv(args.out/'things_field_residuals.csv',scored)
    save_csv(args.out/'things_field_scores.csv',summary)
