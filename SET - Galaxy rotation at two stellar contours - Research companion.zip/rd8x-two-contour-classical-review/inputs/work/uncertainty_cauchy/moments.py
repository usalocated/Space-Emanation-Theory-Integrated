"""Finite-source SET surface-moment and local-gradient sensitivity. No measured speeds are read."""
import argparse
import csv
import io
import math
from pathlib import Path
from zipfile import ZipFile
import numpy as np
from numpy.polynomial.legendre import leggauss

GMSUN = 1.3271244e20
KPC = 3.085677581491367e19
PI = math.pi
HERE = Path(__file__).resolve().parent

def load_csv(path):
    with path.open() as f:
        return list(csv.DictReader(f))

def save_csv(path, values):
    with path.open("w",newline="") as f:
        out=csv.DictWriter(f, list(values[0]))
        out.writeheader()
        out.writerows(values)

def grid_weights(edges, order):
    x, w = leggauss(order)
    lo, hi = edges[:-1,None], edges[1:,None]
    return ((lo+hi+(hi-lo)*x)/2).ravel(), ((hi-lo)*w/2).ravel()

def shell_mass(profile, r_boundary, r_last, r_hi, m_disk, m_bulge, m_gas, radial_order, gas_extent=1.):
    # Each integral is split exactly at the two test radii. Surface densities are
    # tabulated on-sky light; assigning an annulus's light to a same-radius
    # 3D homoeoid is an explicit geometric model (not an Abel inversion).
    rad,disk,bulge=profile.T
    assert np.all(np.diff(rad)>0) and np.all(disk>=0) and np.all(bulge>=0)
    rgas=gas_extent*r_hi
    edges=np.unique(np.r_[0,rad,r_boundary,r_last,rgas])
    a,d_a=grid_weights(edges,radial_order)
    scale=m_disk+m_bulge+m_gas
    star=np.zeros_like(a)
    for surface,mass in ((disk,m_disk),(bulge,m_bulge)):
        if mass==0: continue
        light=a*d_a*np.interp(a,rad,surface,right=0)
        assert light.sum()>0
        star+=light*(mass/scale/light.sum())
    gas=2*a*d_a/rgas**2*(a<rgas)*(m_gas/scale)
    assert abs(gas.sum()+star.sum()-1)<1.e-11
    return a/r_boundary,star,gas

def oblate_kernel(a,m,q,u,w):
    # Each shell is a uniform infinitesimal homoeoid (between similar ellipsoids).
    # The shell potential inside is constant. Outside, tau is the positive root
    # of R_cyl²/(a²+tau)+z²/(q² a²+tau)=1. Write T=a²+tau and k²=a²(1-q²).
    a=a[:,None]; m=m[:,None]; inside=a<1
    k2=a*a*(1-q*q)
    cyl=np.sqrt(1-u*u); z=q*u
    r2=cyl*cyl+z*z
    T=.5*(r2+k2+np.sqrt((r2-k2)**2+4*z*z*k2))
    T=np.maximum(T,a*a)
    B=T-k2
    h=np.sqrt(q*q+(1-q*q)*u*u)
    if q==1:
        potential=1/np.sqrt(B)
    else:
        k=np.sqrt(k2)
        potential=np.arctan2(k,np.sqrt(B))/k
    # Outward J=-grad(Psi) for C0=I. Interior shells have zero gradient.
    lR=cyl/T; lz=z/B
    nR=q*cyl/h; nz=u/h
    jnormal=(lR*nR+lz*nz)/((lR*lR+lz*lz)*T*np.sqrt(B))
    phi=np.sum(m*potential,axis=0)
    flux=np.sum(m*inside*jnormal,axis=0)
    return phi,float(w@(h*flux))

def equator(a,m,q,t,family):
    interior = a<t
    if family=="homothetic":
        return np.sum(m/np.maximum(a,t))/q, np.sum(m[interior])/(q*t)
    k=a*math.sqrt(1-q*q)
    T=np.maximum(a,t)**2
    if q==1:
        potential=1/np.sqrt(T)
    else:
        potential=np.arctan2(k,np.sqrt(T-k*k))/k
    return np.sum(m*potential),np.sum(m[interior]/np.sqrt(t*t-k[interior]**2))

def evaluate(a,m,q,t_last,family,mass_Q,w,u,r_m,m_total):
    h=np.sqrt(q*q+(1-q*q)*u*u)
    enclosed=m[a<1].sum()
    phi_eq,force=equator(a,m,q,1.,family)
    if family=="homothetic":
        phi=np.full_like(u,phi_eq)
        # C0=diag(1,1,q²), psi0=M(<1)/q plus outer-shell constants.
        # Dot the transformed radial current with the physical normal.
        cyl=np.sqrt(1-u*u); z=q*u
        nR=q*cyl/h; nz=u/h
        flux0=float(w@(h*(enclosed/q)*(cyl*nR+z*nz)))
    else:
        phi,flux0=oblate_kernel(a,m,q,u,w)
    assert np.all(phi>0)
    area=w@h; moment1=w@(np.sqrt(phi)*h); moment2=w@(phi*h)
    # Dimensionless moments use scale S0 = sqrt(2GMtotal/R), area unit 4piR².
    amp=mass_Q/moment1**2
    qref=4*PI*math.sqrt(2*GMSUN*m_total*mass_Q*r_m**3)
    s0=math.sqrt(2*GMSUN*m_total/r_m)
    second=4*PI*r_m*r_m*s0*s0*amp*moment2
    qactual=4*PI*r_m*r_m*s0*math.sqrt(amp)*moment1
    area_eff=4*PI*r_m*r_m*moment1**2/moment2
    seff=second/qactual
    local_eq=s0*math.sqrt(amp*phi_eq)
    _,last_force=equator(a,m,q,t_last,family)
    eps=2.e-6
    phip,_=equator(a,m,q,1+eps,family)
    phim,_=equator(a,m,q,1-eps,family)
    numerical_force=-(phip-phim)/(2*eps)
    e=math.sqrt(1-q*q)
    geometric_ratio=.5*(1+q*q*math.atanh(e)/e) if e else 1.
    v_unit=s0/math.sqrt(2)*math.sqrt(amp)/1.e3
    correction=area*moment2/moment1**2
    variance=float(w@(h*(np.sqrt(phi)-moment1/area)**2)/area)
    return dict(source_fraction_interior=enclosed,Qref_mass_fraction=mass_Q,physical_mass_all_supplied_Msun=m_total*m.sum(),
                physical_mass_inside_Msun=m_total*enclosed,Qref_m3s=qref,Qsurf_m3s=qactual,Isurf_m4s2=second,
                A_geom_m2=4*PI*r_m*r_m*area,A_eff_m2=area_eff,A_geom_over_A_eff=correction,
                A_eff_over_A_geom=1/correction,CV_squared=variance/(moment1/area)**2,
                lambda_amplitude=amp,Seff_kms=seff/1.e3,equatorial_local_S_kms=local_eq/1.e3,
                k_equator=force/phi_eq,Seff_div_sqrt2_kms=seff/1.e3/math.sqrt(2),
                equatorial_vc_kms=v_unit*math.sqrt(force),last_equatorial_vc_kms=v_unit*math.sqrt(last_force),
                current_flux_over_4piGMenc=flux0/enclosed,Qsurf_over_Qref=qactual/qref,
                relative_area_quadrature_error=area/geometric_ratio-1,
                derivative_relative_error=numerical_force/force-1,
                relative_moment_identity_error=correction-1-variance/(moment1/area)**2)

def model(root,folder,radial_order,angular_order):
    src=load_csv(root/"shape_law/source_chain.csv")
    rows=[]
    nodes,weights=leggauss(angular_order)
    u,w=(nodes+1)/2,weights/2
    source_zip=root/"shape_sparc/BulgeDiskDec_LTG.zip"
    with ZipFile(source_zip) as z:
        for row in src:
            g=row["galaxy"]
            R=float(row["Rb_kpc"]); tlast=float(row["Rlast_kpc"])/R
            q=float(row["eta"]); masses=np.array([float(row[k]) for k in ("Mstar_disk_Msun","Mstar_bulge_Msun","MHI_times_1p33_Msun")])
            mt=masses.sum(); rhi=float(row["RHI_1Msun_per_pc2_kpc"])
            dens=np.loadtxt(io.BytesIO(z.read(g+".dens")))
            for gext in [1.,1.5]:
                a,star,gas=shell_mass(dens,R,tlast*R,rhi,*masses,radial_order,gext)
                enclosed=a<1
                cases={"stars_inside":(star*enclosed,star[enclosed].sum()),
                       "baryons_inside":((star+gas)*enclosed,(star+gas)[enclosed].sum()),
                       "full_baryons_global_Q":(star+gas,1.),
                       "full_baryons_enclosed_Q":(star+gas,(star+gas)[enclosed].sum())}
                if gext!=1.:
                    cases={"wide_gas_full_global_Q":(star+gas,1.)}
                for case,(m,mQ) in cases.items():
                    for family in ["isotropic","homothetic"]:
                        flag=m>0
                        out=evaluate(a[flag],m[flag],q,tlast,family,mQ,w,u,R*KPC,mt)
                        rows.append(dict(galaxy=g,case=case,response_family=family,
                                         boundary_kpc=R,last_radius_kpc=R*tlast,eta=q,gas_outer_radius_model_kpc=gext*rhi,
                                         disk_profile_last_kpc=dens[-1,0],
                                         model_stellar_mass_fraction_within_R=star[enclosed].sum()/star.sum(),
                                         model_gas_mass_fraction_within_R=gas[enclosed].sum()/gas.sum(),
                                         uniform_global_baseline_kms=float(row["vorb_Seff_div_sqrt2_kms"]),**out))
    assert len(rows)==400
    assert max(abs(r["Qsurf_over_Qref"]-1) for r in rows)<2.e-13
    assert max(abs(r["current_flux_over_4piGMenc"]-1) for r in rows)<2.e-7
    assert max(abs(r["relative_moment_identity_error"]) for r in rows)<2.e-12
    assert min(r["A_geom_over_A_eff"] for r in rows)>1-2.e-13
    assert max(abs(r["relative_area_quadrature_error"]) for r in rows)<2.e-11
    assert max(abs(r["derivative_relative_error"]) for r in rows)<3.e-6
    uniform=[r for r in rows if r["response_family"]=="homothetic" and r["case"]=="baryons_inside"]
    assert max(abs(r["k_equator"]-1) for r in uniform)<1.e-12
    assert max(abs(r["equatorial_vc_kms"]/r["Seff_div_sqrt2_kms"]-1) for r in uniform)<1.e-12
    test=evaluate(np.array([.2,.55,1.55]),np.array([.25,.35,.4]),1.,1.5,"isotropic",1.,w,u,1.e20,1.e10)
    assert abs(test["k_equator"]-.6/(.6+.4/1.55))<1.e-12
    assert abs(test["A_eff_over_A_geom"]-1)<1.e-12
    folder.mkdir(exist_ok=True,parents=True)
    save_csv(folder/"source_predictions.csv",rows)
    return rows

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--work",type=Path,default=HERE.parent)
    ap.add_argument("--out",type=Path,default=HERE)
    ap.add_argument("--radial",type=int,default=12)
    ap.add_argument("--angular",type=int,default=96)
    args=ap.parse_args()
    results=model(args.work,args.out,args.radial,args.angular)
    print("Rows",len(results))
