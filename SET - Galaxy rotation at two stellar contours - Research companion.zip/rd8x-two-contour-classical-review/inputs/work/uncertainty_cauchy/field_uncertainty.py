"""Earlier audit's identical nuisance streams propagated through the full/global-Q finite-source fields."""
import argparse
import io
import json
import math
from pathlib import Path
import sys
from zipfile import ZipFile
import numpy as np
from numpy.polynomial.legendre import leggauss

from moments import KPC, GMSUN, shell_mass, equator, load_csv, save_csv
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'uncertainty_speeds'))
import predict_intervals as mc

MODELS=['isotropic_gradient','homothetic_gradient','isotropic_surface','uniform_area','gr','halo']
P=[.025,.16,.5,.84,.975]
QS=['p025','p16','median','p84','p975']

def recover_axis(f):
    # The existing sampler returns f=A/(pi R²), a strictly monotone function of q.
    lo=np.zeros_like(f); hi=np.ones_like(f)
    for _ in range(41):
        q=(lo+hi)/2
        e=np.sqrt(1-q*q)
        fq=2*(1+q*q*np.arcsinh(e/q)/e)
        lo=np.where(fq<f,q,lo); hi=np.where(fq>=f,q,hi)
    return (lo+hi)/2

def basis(q,a,stars,gas,u,t):
    # Solve the same physical isotropic shell kernel as moments.py. Vectorization gives
    # separate linear potentials for the stars and gas on the angular integration nodes.
    aa=a[:,None]; k=aa*math.sqrt(1-q*q); z=q*u
    r2=1-u*u+z*z
    T=.5*(r2+k*k+np.sqrt((r2-k*k)**2+4*k*k*z*z))
    B=np.maximum(T,aa*aa)-k*k
    C=(np.arctan2(k,np.sqrt(B))/k if q<1 else 1/np.sqrt(B))
    # C here is the Green function on the nodes, not the physical response tensor.
    U=np.stack([stars,gas])@C
    forces=np.array([[equator(a,m,q,r,'isotropic')[1] for r in (1.,t)] for m in (stars,gas)])
    return U,forces

def interp(tab,grid,x):
    i=np.searchsorted(grid,x,side='right')-1
    i=np.clip(i,0,len(grid)-2)
    blend=(x-grid[i])/(grid[i+1]-grid[i])
    return tab[i]*(1-blend)[:,None,None]+tab[i+1]*blend[:,None,None]

def fields(q,a,stars,gas,t,ds,fl,fg,u,w,Vs,grid,tab,force,points=None):
    # Tabulated kernels depend on q; masses and projected nuisance scalings are exact.
    if points is None:
        values=interp(tab,grid,np.log(q)); F=interp(force,grid,np.log(q))
    else:
        pairs=[basis(v,a,stars,gas,u,t) for v in q]
        values=np.array([v[0] for v in pairs]);F=np.array([v[1] for v in pairs])
    rw=w[None,:]*np.sqrt(q[:,None]**2+(1-q[:,None]**2)*u[None,:]**2)
    area=rw.sum(axis=1)
    ph=values[:,0,:]*fl[:,None]+values[:,1,:]*fg[:,None]
    q0=np.sum(rw*np.sqrt(ph),axis=1)
    mt=stars.sum()*fl+gas.sum()*fg
    amp=mt/q0**2
    sf=F[:,0,:]*fl[:,None]+F[:,1,:]*fg[:,None]
    vo=Vs*np.sqrt(ds[:,None]*amp[:,None]*sf)
    ci=area*(rw*ph).sum(axis=1)/q0**2
    surface=Vs*np.sqrt(ds*mt)*ci/area
    # ψ0 and v² kernels for C0=diag(1,1,q²) share 1/q, which cancels after calibration.
    pstar=np.sum(stars/np.maximum(a,1.))
    pgas=np.sum(gas/np.maximum(a,1.))
    phh=fl*pstar+fg*pgas
    fh=np.array([(fl*stars[a<r].sum()+fg*gas[a<r].sum())/r for r in [1.,t]]).T
    vh=Vs*np.sqrt(ds[:,None]*mt[:,None]*fh/phh[:,None])/area[:,None]
    return vo,vh,surface,ci

def forecast(root,n,gsize):
    inputs=mc.source_inputs(root); cats,geos,radii,draw,supp=inputs
    source={r['galaxy']:r for r in load_csv(root/'shape_law/source_chain.csv')}
    comps={case:mc.realize(inputs,n,case)[0] for case in ('quoted','source_rings')}
    result={c:np.empty((40,2,len(MODELS),n)) for c in comps}
    checks=[];cats_out=[];concentration=[]
    x,w=leggauss(72);u,w=(x+1)/2,w/2
    with ZipFile(root/'shape_sparc/BulgeDiskDec_LTG.zip') as z:
        for j,resultrow in enumerate(draw):
            g=resultrow['galaxy'];s=source[g]; geo=geos[g];cat=cats[g];info=supp.get(g,{})
            R=float(s['Rb_kpc']);t=float(s['Rlast_kpc'])/R
            m=np.array([float(s[k]) for k in ('Mstar_disk_Msun','Mstar_bulge_Msun','MHI_times_1p33_Msun')])
            vs=math.sqrt(GMSUN*m.sum()/(KPC*R))/1000
            a,star,gas=shell_mass(np.loadtxt(io.BytesIO(z.read(g+'.dens'))),R,R*t,float(s['RHI_1Msun_per_pc2_kpc']),*m,12)
            inc=float(cat['inclination_deg']); ei=float(cat['e_inc_deg'])
            f,ang,acc=mc.shape_and_angle(mc.stream(j+1,0,n),n,float(geo['p']),float(geo['ep']),inc,ei,0.)
            q=recover_axis(f)
            grid=np.linspace(math.log(min(q.min()*.999,.01)),0.,gsize)
            pairs=[basis(float(v),a,star,gas,u,t) for v in np.exp(grid)]
            tab=np.array([v[0] for v in pairs]);frc=np.array([v[1] for v in pairs])
            d=float(cat['d_mpc']);sd=float(cat['e_d_mpc']); meth=int(cat['distance_method'])
            sc=.9/d if meth==4 else .07 if meth==1 else 0.
            common=mc.stream(0,1 if meth==4 else 2,n).standard_normal(n)
            ds=mc.positive_normal(mc.stream(j+1,2,n),1+sc*common,math.sqrt(max(0,(sd/d)**2-sc**2)))
            fl=mc.positive_normal(mc.stream(j+1,3,n),np.ones(n),float(cat['e_L36_1e9_Lsun'])/float(cat['L36_1e9_Lsun']))
            for case,cb in comps.items():
                sg=0.
                if case=='source_rings' and info.get('eFHI_Jy_kms') and info['flux_treatment'].startswith('same'):
                    sg=float(info['eFHI_Jy_kms'])/float(info['FHI_Jy_kms'])
                fg=mc.positive_normal(mc.stream(j+1,4,n),np.ones(n),sg)
                params=(a,star,gas,t,ds,fl,fg,u,w,vs,grid,tab,frc)
                vo,vh,surf,conc=fields(q,*params)
                # Include actual extrema and quantiles of q, not just typical orientations.
                selection=np.argsort(q)[np.linspace(0,n-1,13).astype(int)]
                ref=fields(q[selection],a,star,gas,t,ds[selection],fl[selection],fg[selection],u,w,vs,grid,tab,frc,True)
                checks.append(max(np.max(np.abs(vo[selection]-ref[0])),np.max(np.abs(surf[selection]-ref[2]))))
                for k,role in enumerate(('image','last')):
                    ring0=float(info.get('ring_i_'+role+'_deg','') or inc) if case=='source_rings' else inc
                    projection=np.abs(np.sin(np.deg2rad(ring0+ang-inc)))/math.sin(math.radians(ring0))
                    block=result[case][j,k]
                    block[0]=vo[:,k]*projection;block[1]=vh[:,k]*projection
                    block[2]=surf*projection if k==0 else np.nan
                    block[3:]=cb[j,k,[1,0,2]]
                    if k==0:
                        spherical=vs*np.sqrt(ds*(star.sum()*fl+gas.sum()*fg))*4/f*projection
                        assert np.max(np.abs(spherical/cb[j,k,1]-1))<3e-7
                    for mid,key in enumerate(MODELS):
                        if mid==2 and k==1: continue
                        rr=dict(galaxy=g,case=case,model=key,role=role,R_kpc=R if k==0 else R*t)
                        rr.update(dict(zip(QS,map(float,np.quantile(block[mid],P)))))
                        cats_out.append(rr)
                concentration.append(dict(galaxy=g,case=case,**dict(zip(QS,map(float,np.quantile(conc,P))))))
    assert max(checks)<.06,('Interpolation km/s',max(checks))
    return result,cats_out,concentration,max(checks)

def assess(root,blocks,n):
    obs={r['galaxy']:r for r in load_csv(root/'forty_results/galaxy_results.csv')}
    names=[r['galaxy'] for r in load_csv(root/'forty_sample/sample40.csv')]
    out=[]
    for case,b in blocks.items():
        for k,role in enumerate(('image','last')):
            v=np.array([float(obs[g][role+'_obs_kms']) for g in names])
            sig=np.array([float(obs[g][role+'_obs_error_kms']) for g in names])
            noise=np.stack([mc.stream(j+1,10+(k if (obs[g]['R_image_kpc']!=obs[g]['R_last_kpc']) else 0),n).normal(size=n)*sig[j] for j,g in enumerate(names)])
            med=np.median(b[:,k,-1,:],axis=1); haloe=100*np.abs(med/v-1)
            for m,mod in enumerate(MODELS):
                if mod=='isotropic_surface' and k==1: continue
                d=b[:,k,m,:];mid=np.median(d,axis=1);e=100*np.abs(mid/v-1)
                q=np.quantile(d,P,axis=1);joint=np.quantile(d+noise,P,axis=1)
                drawgap=np.median(100*np.abs(d/v[:,None]-1),axis=0)-np.median(100*np.abs(b[:,k,-1,:]/v[:,None]-1),axis=0)
                stats={'n':len(v),'median_forecast_ape_median_pct':float(np.median(e)),'mean_abs_pct':float(np.mean(e)),
                       'rmse_kms':float(np.sqrt(np.mean((mid-v)**2))),'n_source_68':int(np.sum((q[1]<=v)&(v<=q[3]))),
                       'n_source_95':int(np.sum((q[0]<=v)&(v<=q[-1]))),'n_combined_68':int(np.sum((joint[1]<=v)&(v<=joint[3]))),
                       'n_combined_95':int(np.sum((joint[0]<=v)&(v<=joint[-1]))),'point_median_ape_minus_halo_pp':float(np.median(e)-np.median(haloe)),
                       'pairs_point_better_than_halo':int(np.sum(e<haloe))}
                stats.update(dict(zip(['draw_gap_pp_p025','draw_gap_pp_median','draw_gap_pp_p975'],map(float,np.quantile(drawgap,[.025,.5,.975])))))
                out.append(dict(case=case,model=mod,role=role,**stats))
    return out
if __name__=='__main__':
    pp=argparse.ArgumentParser()
    pp.add_argument('--work',type=Path,default=HERE.parent)
    pp.add_argument('--out',type=Path,default=HERE)
    pp.add_argument('--draws',type=int,default=8192)
    pp.add_argument('--grid',type=int,default=201)
    args=pp.parse_args()
    blocks,forecasts,conc,err=forecast(args.work,args.draws,args.grid)
    save_csv(args.out/'field_forecasts.csv',forecasts)
    save_csv(args.out/'field_area_concentration.csv',conc)
    save_csv(args.out/'field_scores.csv',assess(args.work,blocks,args.draws))
    (args.out/'field_uncertainty_checks.json').write_text(json.dumps(dict(draws=args.draws,axis_grid=args.grid,
           angular_order=72,radial_order=12,max_checked_interpolation_speed_error_kms=err),indent=2)+'\n')
    print('Maximum interpolation discrepancy',err,'km/s')
