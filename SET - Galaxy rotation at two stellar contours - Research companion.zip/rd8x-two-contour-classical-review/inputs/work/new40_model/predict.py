"""Predict at the 3.6-micron 25.5 AB isophote. Do not parse target amplitudes."""
import argparse
import csv
from collections import defaultdict
import hashlib
import io
import json
import math
from pathlib import Path
import sys
from zipfile import ZipFile

import numpy as np

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
for rel in ('', 'consensus_photometric', 'uncertainty_cauchy', 'uncertainty_speeds'):
    sys.path.insert(0, str(WORK / rel))
import contour_uncertainty as cu
import field_uncertainty as fu
import forty_halo as halo
from forty_native_mc import halo_arrays
import moments as fm
from photometric_radii import bracket
import predict_intervals as mc
import things_field

RAW = WORK / 'forty_sample/raw'
ARCSEC = math.pi / (180 * 3600)
MODELS = ('set','klypin_all','klypin_relaxed','dutton_maccio','gr','uniform','gradient')
QS = ('p025','p16','median','p84','p975')


def read(path):
    with path.open() as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fields, lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)


def catalogue():
    # Read model inputs explicitly by column; the two catalog flat-speed fields
    # are excluded. Fractions are applied to luminosities in units of solar L36.
    lines = (RAW / 'SPARC_Lelli2016c.mrt').read_text().rsplit('-'*80,1)[1].splitlines()
    bulge = dict(s.split() for s in (RAW / 'Bulges.mrt').read_text().splitlines()
                 if s.strip() and not s.startswith('#'))
    rows = {}
    for s in lines:
        if not s.strip():
            continue
        f = s.split()
        d, ed, method, inc, ei, lum, elum, hi, rhi = [float(f[k]) for k in (2,3,4,5,6,7,8,13,14)]
        lb = float(bulge[f[0]])
        rows[f[0]] = dict(d=d,ed=ed,method=int(method),inc=inc,ei=ei,L=lum,eL=elum,rhi=rhi,
                         masses=np.array([.5*(lum-lb),.7*lb,1.33*hi])*1e9)
    return rows


def component_rings(archive, g):
    data = []
    for line in archive.read(g+'_rotmod.dat').decode().splitlines():
        if line.strip() and not line.startswith('#'):
            f = line.split()
            data.append([float(f[k]) for k in (0,3,4,5)])
    rad = np.array(data)
    assert np.all(np.diff(rad[:,0])>0)
    return rad


def flux_sigmas(path):
    sig = {}
    for r in read(WORK/'uncertainty_speeds/observer_inputs.csv'):
        if r['flux_treatment'].startswith('same') and r['eFHI_Jy_kms']:
            sig[r['galaxy']] = float(r['eFHI_Jy_kms'])/float(r['FHI_Jy_kms'])
    if path and path.exists():
        sig.update({r['galaxy']:float(r['fractional_sigma']) for r in read(path)})
    return sig


def ring_inclinations(path):
    db = defaultdict(list)
    with (WORK/'uncertainty_lit_b/VS01_ring_data.csv').open() as f:
        for row in csv.DictReader(f):
            db[row['galaxy']].append((float(row['r_arcsec']),float(row['i_deg']),'matched VS01 ring'))
    if path and path.exists():
        for r in read(path):
            db[r['galaxy']].append((float(r['r_arcsec']),float(r['i_deg']),r.get('source') or 'matched source ring'))
    constants = {'NGC5033':66.4,'NGC5585':51.5,'NGC6503':73.8}
    def lookup(g,r_arc,inc):
        if g in db:
            x = min(db[g],key=lambda d:abs(d[0]-r_arc))
            if abs(x[0]-r_arc)<=1.25:
                return x[1],x[2]
        return (constants[g],'source adopted constant') if g in constants else (inc,'SPARC global')
    return lookup


def shell_components(dens, R, rhi, masses, angle, annuli):
    # Replacement gas shells leave the per-component observed light normalization
    # intact. A dummy stellar integration knot at R is harmless if R_HI is absent.
    if rhi<=0 and masses[2]>0 and not annuli:
        return None
    nodes,st,gas = fm.shell_mass(dens,R,R,rhi if rhi>0 else R,*masses,12)
    if annuli:
        scaled = [dict(rlo_ratio=float(r['lo_arcsec'])/angle,rhi_ratio=float(r['hi_arcsec'])/angle,
                       gas_mass_fraction=float(r['mass_fraction'])) for r in annuli]
        ag,mg = things_field.observed_shells(scaled,1.,12)
        nodes,st,gas = np.r_[nodes,ag],np.r_[st,np.zeros_like(ag)],np.r_[np.zeros_like(gas),mg*masses[2]/masses.sum()]
    ok = st+gas>0
    assert abs(st.sum()+gas.sum()-1)<1e-10
    return nodes[ok],st[ok],gas[ok]


def halo_draws(stellar, radii, baryon_v2, projection):
    mass, r200, call = halo_arrays(stellar)
    x = .700*mass/1e12
    recipes = [(r200,call,halo.DM_FRACTION),
               (r200,6.90*x**-.090*(1+(x/5.5e5)**.4),halo.DM_FRACTION),
               ((halo.G*mass/(100*.0671**2))**(1/3),10**.905*(.671*mass/1e12)**-.101,1-.049/.3175)]
    result = []
    for rr,cc,frac in recipes:
        xx = cc*radii/rr
        dm = halo.G*frac*mass/radii * (np.log1p(xx)-xx/(1+xx))/(np.log1p(cc)-cc/(1+cc))
        result.append(np.sqrt(baryon_v2+dm)*projection)
    return result


def predict_one(row, cat, rings, profiles, gas, lookup_i, sigma_g, draws, grid):
    g = row['galaxy']
    rank = int(row['draw_rank'])
    r = cat[g]
    d,inc,di,rhi = (r[k] for k in ('d','inc','ei','rhi'))
    M = r['masses']
    mass = M.sum()
    rec = dict(galaxy=g,draw_rank=rank)
    angle = row.get('a25_arcsec','') or row.get('semi_major_arcsec','')
    p = row.get('p25','') or row.get('projected_axis_ratio','')
    if not angle or not p:
        return dict(rec,status='missing_catalog_contour'),[]
    angle,p = float(angle),float(p)
    R = angle*ARCSEC*d*1000
    q2 = (p*p-math.cos(math.radians(inc))**2)/math.sin(math.radians(inc))**2
    rad = component_rings(rings,g)
    br = bracket(rad[:,0],R)
    rec.update(a25_arcsec=angle,p25=p,R_kpc=R,q2=q2,d_Mpc=d,inc_deg=inc,e_inc_deg=di,
               rhi_kpc=rhi,r_min_kpc=rad[0,0],r_max_kpc=rad[-1,0],within_support=int(br is not None),
               m_disk=M[0],m_bulge=M[1],m_gas=M[2])
    if not 0<p<=1 or not 0<q2<=1:
        return dict(rec,status='incompatible_nominal_oblate'),[]
    if g+'.dens' not in profiles.namelist():
        return dict(rec,status='stellar_radial_profile_missing'),[]
    q0 = math.sqrt(q2)
    levels=[]
    if br is not None:
        lo,hi,t = br
        levels = [(lo,1-t),(hi,t)]
        rec.update(lo_kpc=rad[lo,0],hi_kpc=rad[hi,0],weight_hi=t)
    gas_force = star_force = 0.
    tilts = []
    for i,w0 in levels:
        rg,vg,vd,vb = rad[i]
        gas_force += w0*vg*abs(vg)
        star_force += w0*(.5*vd*abs(vd)+.7*vb*abs(vb))
        tilts.append(lookup_i(g,rg/(d*1000*ARCSEC),inc))
    if br is not None and star_force+gas_force<=0:
        return dict(rec,status='noninward_baryon_force'),[]
    if br is None:
        tilts=[(inc,'SPARC global')]*2
    rec.update(gas_force_kms2=gas_force if br else None,star_force_kms2=star_force if br else None,tilt_lo_deg=tilts[0][0],tilt_hi_deg=tilts[1][0],
               tilt_source=' | '.join(sorted(set(tt[1] for tt in tilts))),sigma_HI_fraction=sigma_g)
    f,angles,acc = mc.shape_and_angle(mc.stream(rank,0,draws),draws,p,0.,inc,di,0.)
    q = fu.recover_axis(f)
    shared = .9/d if r['method']==4 else .07 if r['method']==1 else 0.
    ds = mc.positive_normal(mc.stream(rank,2,draws),1+mc.stream(0,1 if r['method']==4 else 2,draws).standard_normal(draws)*shared,
                            math.sqrt(max(0.,(r['ed']/d)**2-shared**2)))
    fl = mc.positive_normal(mc.stream(rank,3,draws),np.ones(draws),r['eL']/r['L'])
    fg = mc.positive_normal(mc.stream(rank,4,draws),np.ones(draws),sigma_g)
    projection = sum(w0*np.abs(np.sin(np.deg2rad(tt[0]+angles-inc)))/math.sin(math.radians(tt[0]))
                     for (_,w0),tt in zip(levels,tilts))
    vb2 = ds*(star_force*fl+gas_force*fg)
    if br is None:
        projection=np.abs(np.sin(np.deg2rad(angles)))/math.sin(math.radians(inc))
    else:
        assert np.all(vb2>0)
    stellar = M[:2].sum()
    halos = halo_draws(stellar*fl*ds**2,R*ds,vb2,projection)
    halos_nom = [math.sqrt(star_force+gas_force+h.v2(R)) for h in
                 (halo.population_halo(stellar),halo.population_halo(stellar,True),halo.dutton_maccio_halo(stellar))]
    dens = np.loadtxt(io.BytesIO(profiles.read(g+'.dens')))
    vs = math.sqrt(fm.GMSUN*mass/(fm.KPC*R))/1000
    def nodes(n):
        u,w = np.polynomial.legendre.leggauss(n)
        return (u+1)/2,w/2
    u,w = nodes(72)
    un,wn = nodes(96)
    records = []
    variants = [('RHI template',None)]
    if gas:
        variants.append((gas[0]['source'],gas))
    for label,ann in variants:
        shell = shell_components(dens,R,rhi,M,angle,ann)
        if shell is None:
            continue
        a,st,mg = shell
        nom = fm.evaluate(a,st+mg,q0,1.,'isotropic',1.,wn,un,R*fm.KPC,mass)
        table = cu.kernel_tables([q,np.array([q0])],a,st,mg,u,grid)
        vu,vsurf,vg = cu.calc(q,fl,fg,ds,vs,a,st,mg,w,u,table)
        one = np.ones(1)
        chk = cu.calc(np.array([q0]),one,one,one,vs,a,st,mg,w,u,table)[1][0]
        delta = float(abs(chk-nom['Seff_div_sqrt2_kms']))
        assert delta<.04,(g,delta)
        assert abs(1-nom['Qsurf_over_Qref'])<1e-9 and nom['A_geom_over_A_eff']>=1-1e-10
        v_matrix = [vsurf*projection,*halos,np.sqrt(vb2)*projection,vu*projection,vg*projection]
        uniform = vs*4*math.pi*(R*fm.KPC)**2/nom['A_geom_m2']
        central = [nom['Seff_div_sqrt2_kms'],*halos_nom,math.sqrt(gas_force+star_force),uniform,nom['equatorial_vc_kms']]
        qvalues = np.quantile(v_matrix,[.025,.16,.5,.84,.975],axis=1).T
        for model,value,quant in zip(MODELS,central,qvalues):
            if br is None and model not in ('set','uniform','gradient'):
                continue
            records.append(dict(galaxy=g,draw_rank=rank,gas_model='measured' if ann else 'template',gas_source=label,
                                model=model,nominal=value,**dict(zip(QS,quant)),n=draws))
        prefix = 'measured_' if ann else 'template_'
        for key in ('Qref_m3s','A_geom_m2','A_eff_m2','A_geom_over_A_eff','Seff_kms','source_fraction_interior'):
            rec[prefix+key] = nom[key]
        rec[prefix+'numerical_delta_kms'] = delta
    status=('contour_outside_rotation_coverage' if br is None else 'forecast') if records else 'missing_gas_radial_information'
    rec.update(status=status,draw_acceptance=acc,
               measured_gas=int(bool(gas)),measured_gas_source=gas[0]['source'] if gas else '')
    return rec,records


def run(inputs,annuli,out,n,grid,incfile=None,fluxfile=None):
    out.mkdir(parents=True,exist_ok=True)
    gas=defaultdict(list)
    if annuli:
        for r in read(annuli):
            gas[r['galaxy']].append(r)
    cat=catalogue()
    lookup=ring_inclinations(incfile)
    sig=flux_sigmas(fluxfile)
    input_rows=read(inputs)
    assert len({r['galaxy'] for r in input_rows})==len(input_rows)
    # The two draws overlap. One deterministic stream per galaxy makes identical
    # objects carry the same forecast in every summary. The old benchmark passes
    # its archived ranks explicitly, preserving its original nuisance streams.
    canonical={g:i+1 for i,g in enumerate(sorted(cat))}
    for row in input_rows:
        row.setdefault('draw_rank',str(canonical[row['galaxy']]))
    checks=[]
    pred=[]
    with ZipFile(RAW/'Rotmod_LTG.zip') as rot, ZipFile(WORK/'shape_sparc/BulgeDiskDec_LTG.zip') as dens:
        for row in input_rows:
            g=row['galaxy']
            audit,res=predict_one(row,cat,rot,dens,gas[g],lookup,sig.get(g,0.),n,grid)
            checks.append(audit)
            pred.extend(res)
            print(g,audit['status'],len(res),flush=True)
    write(out/'model_audit.csv',checks)
    write(out/'forecasts.csv',pred)
    return pred


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--inputs',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--annuli',type=Path)
    parser.add_argument('--inclinations',type=Path)
    parser.add_argument('--flux',type=Path)
    parser.add_argument('--draws',type=int,default=32768)
    parser.add_argument('--grid',type=int,default=121)
    args=parser.parse_args()
    run(args.inputs,args.annuli,args.out,args.draws,args.grid,args.inclinations,args.flux)
