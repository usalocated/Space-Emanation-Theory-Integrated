"""Recompute SET on the star-defined surface with the full baryonic inventory at both endpoints."""
import argparse
import csv
import hashlib
import io
import json
import math
import sys
from collections import defaultdict
from pathlib import Path
from zipfile import ZipFile

import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
for subdir in ('uncertainty_cauchy','uncertainty_speeds','consensus_gas'):
    sys.path.insert(0,str(ROOT/subdir))
import moments as fm
import field_uncertainty as fu
import measured_fields as profiles
import things_field
import predict_intervals as errors

MODELS=['uniform','SET_surface','SET_local','SET_shape_matched_local','GR_baryons','halo']
QUANTILES=[.025,.16,.5,.84,.975]
LABELS=['p025','p16','median','p84','p975']

def read(p):
    with p.open() as f:return list(csv.DictReader(f))
def save(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
def qdict(a):
    return dict(zip(LABELS,map(float,np.quantile(a,QUANTILES))))
def get_extra(folder,filename):
    file=folder/filename
    return read(file) if file.exists() else []

def assemble(root):
    src={r['galaxy']:r for r in read(root/'shape_law/source_chain.csv')}
    base={}
    with ZipFile(root/'shape_sparc/BulgeDiskDec_LTG.zip') as zz:
        for g,s in src.items():
            r,rl,rhi=map(float,(s['Rb_kpc'],s['Rlast_kpc'],s['RHI_1Msun_per_pc2_kpc']))
            m=[float(s[k]) for k in ('Mstar_disk_Msun','Mstar_bulge_Msun','MHI_times_1p33_Msun')]
            a,st,ga=fm.shell_mass(np.loadtxt(io.BytesIO(zz.read(g+'.dens'))),r,rl,rhi,*m,12)
            base[g]=('RHI template',a,st,ga)
    current=dict(base)
    for g,s,choice,d,total,a,st,ga in profiles.measured_profiles(root):
        if profiles.PREFERRED[g]==(s,choice):
            current[g]=(s,a,st,ga)
    for folder,label,filename in [('consensus_whisp','WHISP','observed_gas_annuli.csv'),('consensus_uma','UMa','observed_gas_annuli.csv'),('consensus_extra','Observed HI','accepted_annuli.csv'),('consensus_legacy','Observer HI','accepted_annuli.csv')]:
        groups=defaultdict(list)
        for row in get_extra(root/folder,filename):
            groups[row['galaxy']].append(row)
        for g,items in groups.items():
            assert current[g][0]=='RHI template',g
            _,a,st,ga=base[g];t=float(src[g]['Rlast_kpc'])/float(src[g]['Rb_kpc'])
            b,h=things_field.observed_shells(items,t,12)
            current[g]=(items[0].get('gas_survey') or label,np.r_[a,b],np.r_[st,np.zeros_like(b)],np.r_[np.zeros_like(a),ga.sum()*h])
    return src,current

def source_run(root,out,n,grid_size):
    sources,radials=assemble(root)
    inputs=errors.source_inputs(root);cats,geos,radii,draw,supp=inputs
    comparison,_,_=errors.realize(inputs,n,'source_rings')
    allv=np.empty((len(draw),2,len(MODELS),n))
    xi,wi=np.polynomial.legendre.leggauss(72);u,w=(xi+1)/2,wi/2
    uc,wc=np.polynomial.legendre.leggauss(128);uc,wc=(uc+1)/2,wc/2
    records=[];moment_records=[];errors_checked=[]
    for j,entry in enumerate(draw):
        g=entry['galaxy']; src=sources[g];cat=cats[g];geo=geos[g];info=supp.get(g,{})
        label,a,stars,gas=radials[g]
        nonzero=(stars+gas)>0;a,stars,gas=a[nonzero],stars[nonzero],gas[nonzero]
        assert abs(stars.sum()+gas.sum()-1)<2e-11
        R=float(src['Rb_kpc']);t=float(src['Rlast_kpc'])/R
        mass=float(src['Mbar_global_Msun']);vs=math.sqrt(fm.GMSUN*mass/(fm.KPC*R))/1000
        nominal=fm.evaluate(a,stars+gas,float(src['eta']),t,'isotropic',1.,wc,uc,R*fm.KPC,mass)
        assert abs(nominal['Qsurf_over_Qref']-1)<1e-12
        assert abs(nominal['relative_moment_identity_error'])<1e-10
        assert abs(nominal['current_flux_over_4piGMenc']-1)<1e-6
        inc,ei=float(cat['inclination_deg']),float(cat['e_inc_deg'])
        f,angle,accept=errors.shape_and_angle(errors.stream(j+1,0,n),n,float(geo['p']),float(geo['ep']),inc,ei,0.)
        q=fu.recover_axis(f)
        grid=np.linspace(math.log(min(q.min()*.999,.01)),0,grid_size)
        kern=[fu.basis(qi,a,stars,gas,u,t) for qi in np.exp(grid)]
        pot=np.array([v[0] for v in kern]);force=np.array([v[1] for v in kern])
        d,sd,meth=float(cat['d_mpc']),float(cat['e_d_mpc']),int(cat['distance_method'])
        share=.9/d if meth==4 else .07 if meth==1 else 0.
        common=errors.stream(0,1 if meth==4 else 2,n).standard_normal(n)
        ds=errors.positive_normal(errors.stream(j+1,2,n),1+share*common,math.sqrt(max(0,(sd/d)**2-share**2)))
        fl=errors.positive_normal(errors.stream(j+1,3,n),np.ones(n),float(cat['e_L36_1e9_Lsun'])/float(cat['L36_1e9_Lsun']))
        esig=float(info['eFHI_Jy_kms'])/float(info['FHI_Jy_kms']) if info.get('eFHI_Jy_kms') and info['flux_treatment'].startswith('same') else 0.
        fg=errors.positive_normal(errors.stream(j+1,4,n),np.ones(n),esig)
        def get_field(idx,direct=False):
            return fu.fields(q[idx],a,stars,gas,t,ds[idx],fl[idx],fg[idx],u,w,vs,grid,pot,force,True if direct else None)
        vv,vh,vb,boost=[np.concatenate(parts) for parts in zip(*(get_field(slice(lo,min(lo+4096,n))) for lo in range(0,n,4096)))]
        checks=np.argsort(q)[np.linspace(0,n-1,13).astype(int)]
        independent=get_field(checks,True)
        err=max(np.max(abs(vv[checks]-independent[0])),np.max(abs(vb[checks]-independent[2])))
        errors_checked.append(float(err))
        assert err<.07 and np.min(boost)>=1-1e-12
        for ir,role in enumerate(('image','last')):
            rr=float(info.get('ring_i_'+role+'_deg','') or inc)
            proj=np.abs(np.sin(np.deg2rad(rr+angle-inc)))/math.sin(math.radians(rr))
            block=allv[j,ir]
            block[0]=comparison[j,ir,1,:]
            block[1]=(vb if ir==0 else vb/math.sqrt(t))*proj
            block[2]=vv[:,ir]*proj
            block[3]=vh[:,ir]*proj
            block[4]=comparison[j,ir,0,:];block[5]=comparison[j,ir,2,:]
            assert np.max(np.abs(block[1]/(block[0]*boost)-1))<4e-7
            for name,values in zip(MODELS,block):
                records.append(dict(galaxy=g,gas_profile=label,endpoint=role,model=name,**qdict(values)))
        moment_records.append(dict(galaxy=g,gas_profile=label,gas_mass_fraction=float(gas.sum()),
            frac_gas_inside=float(gas[a<1].sum()/gas.sum()),frac_all_mass_inside=float((stars[a<1]+gas[a<1]).sum()),
            R_kpc=R,Rlast_kpc=R*t,RHI_kpc=float(src['RHI_1Msun_per_pc2_kpc']),
            eta=float(src['eta']),enclosing_area_m2=nominal['A_geom_m2'],effective_area_m2=nominal['A_eff_m2'],
            retained_Q_m3s=nominal['Qref_m3s'],I_m4s2=nominal['Isurf_m4s2'],
            nominal_Aeff_over_Astar=nominal['A_eff_over_A_geom'],nominal_CV2=nominal['CV_squared'],
            nominal_Seff_kms=nominal['Seff_kms'],nominal_surface_speed_kms=nominal['Seff_div_sqrt2_kms'],
            nominal_local_gradient_kms=nominal['equatorial_vc_kms'],nominal_last_gradient_kms=nominal['last_equatorial_vc_kms'],
            nominal_last_surface_continuation_kms=nominal['Seff_div_sqrt2_kms']/math.sqrt(t),
            input_acceptance=accept,**{'physical_Seff_'+k:v for k,v in qdict(vb*math.sqrt(2)).items()},
            **{'Aeff_over_Astar_'+k:v for k,v in qdict(1/boost).items()}))
    save(out/'source_forecasts.csv',records);save(out/'boundary_moments.csv',moment_records)
    digest=hashlib.sha256((out/'source_forecasts.csv').read_bytes()).hexdigest()
    (out/'forecast_lock.json').write_text(json.dumps(dict(sha256=digest,draws=n,grid=grid_size,max_point_interpolation_error_kms=max(errors_checked),galaxies=len(draw)),indent=2)+'\n')
    return [r['galaxy'] for r in draw],allv,moment_records

def score(root,out,gals,allv,moments):
    obs={r['galaxy']:r for r in read(root/'forty_results/galaxy_results.csv')}
    pub={r['galaxy']:r['displayed_8e']=='1' for r in read(root/'forty_sample/publication_overlap.csv')}
    N=len(gals);n=allv.shape[-1];rng=np.random.default_rng(140674)
    groupnames=['all','distinct','published','not_displayed','measured_gas','template']
    comparisons=[];per=[];src={s['galaxy']:s for s in moments}
    for k,role in enumerate(('image','last')):
        targ=np.array([float(obs[g][role+'_obs_kms']) for g in gals]);sig=np.array([float(obs[g][role+'_obs_error_kms']) for g in gals])
        data=allv[:,k];med=np.median(data,axis=-1);ape=100*abs(med/targ[:,None]-1)
        groups=[np.ones(N,dtype=bool),[src[g]['Rlast_kpc']>src[g]['R_kpc']*(1+1e-10) for g in gals],
            [pub[g] for g in gals],[not pub[g] for g in gals],[src[g]['gas_profile']!='RHI template' for g in gals],[src[g]['gas_profile']=='RHI template' for g in gals]]
        std=np.stack([errors.stream(j+1,10+(k if obs[g]['R_image_kpc']!=obs[g]['R_last_kpc'] else 0),n).standard_normal(n) for j,g in enumerate(gals)])
        q_joint=np.quantile(data+sig[:,None,None]*std[:,None,:],[.025,.975],axis=2)
        q_sources=np.quantile(data,[.025,.975],axis=2)
        # Signed central residual is positive when the model over-predicts.
        for j,g in enumerate(gals):
            x=med[j,1];o=targ[j];low,high=q_joint[:,j,1]
            row=dict(galaxy=g,endpoint=role,gas_profile=src[g]['gas_profile'],observed_kms=o,obs_err_kms=sig[j],
                **{mod+'_kms':med[j,i] for i,mod in enumerate(MODELS)},
                source95_low_kms=q_sources[0,j,1],source95_high_kms=q_sources[1,j,1],
                combined95_low_kms=low,combined95_high_kms=high,signed_surface_error_pct=100*(x/o-1),
                source_change_vs_uniform_kms=x-med[j,0],compatible95=int(low<=o<=high))
            per.append(row)
        for name,selector in zip(groupnames,groups):
            if role=='image' and name=='distinct':continue
            idx=np.flatnonzero(selector); nn=len(idx)
            if not nn:continue
            boot=idx[rng.integers(0,nn,size=(20000,nn))]
            median_errors=np.median(ape[idx],axis=0)
            bmed=np.median(ape[boot],axis=1)
            for i,model in enumerate(MODELS):
                halo_ci=np.quantile(bmed[:,i]-bmed[:,5],[.025,.975])
                unif_ci=np.quantile(bmed[:,i]-bmed[:,0],[.025,.975])
                comparisons.append(dict(endpoint=role,group=name,model=model,n=nn,
                    median_ape_pct=median_errors[i],mean_ape_pct=np.mean(ape[idx,i]),
                    rmse_kms=np.sqrt(np.mean((med[idx,i]-targ[idx])**2)),under=int(sum(med[idx,i]<targ[idx])),
                    within5=int(sum(ape[idx,i]<=5)),within10=int(sum(ape[idx,i]<=10)),within20=int(sum(ape[idx,i]<=20)),
                    within_combined95=int(sum((q_joint[0,idx,i]<=targ[idx])&(targ[idx]<=q_joint[1,idx,i]))),
                    beats_uniform=int(sum(ape[idx,i]<ape[idx,0])),beats_halo=int(sum(ape[idx,i]<ape[idx,5])),
                    halo_gap_pp=median_errors[i]-median_errors[5],halo_gap_p025=halo_ci[0],halo_gap_p975=halo_ci[1],
                    uniform_gap_pp=median_errors[i]-median_errors[0],uniform_gap_p025=unif_ci[0],uniform_gap_p975=unif_ci[1]))
    save(out/'scores_by_galaxy.csv',per);save(out/'group_scores.csv',comparisons)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=ROOT);ap.add_argument('--out',type=Path,default=HERE)
    ap.add_argument('--draws',type=int,default=32768);ap.add_argument('--grid',type=int,default=217)
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    ids,draws,m=source_run(args.root,args.out,args.draws,args.grid)
    score(args.root,args.out,ids,draws,m)
