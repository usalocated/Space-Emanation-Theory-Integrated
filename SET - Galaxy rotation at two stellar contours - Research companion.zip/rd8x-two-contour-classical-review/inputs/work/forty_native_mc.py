"""Paired, conditional calibration sensitivity of the native-radius and outer tests.
Requires NumPy. Run after forty_run.py score. Uses only released marginal errors and
the published fixed-population halo prescription. M/L shifts are sensitivity choices.
"""
import argparse
import csv
import json
from math import sqrt
from pathlib import Path

import numpy as np
import forty_halo as halo

ROOT=Path(__file__).resolve().parent
G_SET=6.67430e-11 * 1.988409870698051e30 / 3.085677581491367e19 / 1e6
MODEL_NAMES=('gr','set','halo')
SEED=2026111891

def read_csv(path):
    with path.open() as f:
        return list(csv.DictReader(f))

def quant(a):
    return [float(x) for x in np.quantile(a,[.025,.5,.975])]

def positive_normal(rng, mean, sd):
    out=mean+sd*rng.standard_normal(len(mean))
    bad=out<=0
    while bad.any():
        out[bad]=mean[bad]+sd*rng.standard_normal(int(bad.sum()))
        bad=out<=0
    return out

def geometry_errors(rng,n,p,ep,inc_deg,einc,rho):
    """Apply the physical shape cut to every draw before three-model scoring."""
    parts_p=[];parts_i=[];accepted=0;attempted=0
    while accepted<n:
        k=max(1024,n-accepted)
        z=rng.standard_normal(k)
        noisy_p=p+ep*z
        incl=np.deg2rad(inc_deg+einc*(rho*z+sqrt(1-rho**2)*rng.standard_normal(k)))
        sin_i=np.abs(np.sin(incl))
        ratio=(noisy_p**2 - np.cos(incl)**2)/sin_i**2
        good=(sin_i>0)&(noisy_p>0)&(noisy_p<=1)&(ratio>=0)&(ratio<=1)
        parts_i.append(sin_i[good]); parts_p.append(ratio[good])
        attempted+=k;accepted+=int(good.sum())
    si=np.concatenate(parts_i)[:n]
    q2=np.concatenate(parts_p)[:n]
    e=np.sqrt(1-q2)
    quotient=np.divide(np.arcsinh(np.divide(e,np.sqrt(q2),out=np.zeros_like(e),where=q2>0)),e,
                       out=np.ones_like(e),where=e>0)
    return 2*(1+q2*quotient), si, accepted/attempted

def halo_arrays(mstar):
    # Independent vector inversion of the identical Moster relation on the same mass bracket.
    lo=np.full_like(mstar,6.);hi=np.full_like(mstar,18.)
    for _ in range(45):
        mid=(hi+lo)/2;trial=10**mid;ratio=trial/10**11.590
        stars=2*.0351*trial/(ratio**-1.376+ratio**.608)
        left=stars<mstar
        lo=np.where(left,mid,lo);hi=np.where(left,hi,mid)
    m=10**((lo+hi)/2.)
    r200=(halo.G*m/(100*halo.H0**2))**(1/3)
    x=.700*m/1e12
    c=6.60*x**-.110*(1+(x/2e6)**.4)
    return m,r200,c

def score_sensitivity(matrices, mask):
    errors=[]
    summaries={}
    for key in MODEL_NAMES:
        centered=matrices[key][:,mask]
        mape=100*np.median(np.abs(centered),axis=1)
        errors.append(mape)
        summaries[key]={'median_ape_p025_p50_p975':quant(mape)}
    stack=np.array(errors)
    for j,key in enumerate(MODEL_NAMES):
        summaries[key]['lowest_median_ape_draw_fraction']=float(np.mean(np.argmin(stack,axis=0)==j))
    summaries['set_minus_halo_median_ape_pp_p025_p50_p975']=quant(errors[1]-errors[2])
    return summaries

def central_ml_scores(records, geometry, rings):
    """Deterministic checks at the reported calibration and two common stellar zero points."""
    scores={}
    max_difference=0.
    for shift in (-.1,0.,.1):
        scale=10**shift
        err={k:{m:[] for m in MODEL_NAMES} for k in ('image','last')}
        for item in records:
            gal=item['galaxy']; g=geometry[gal]
            stars=float(g['Mstar_Msun'])*scale
            mb=stars+1.33e9*float(g['MHI_1e9_Msun'])
            population=halo.population_halo(stars)
            for key,rkey in (('image','R_image_kpc'),('last','R_last_kpc')):
                radius=float(item[rkey]); row=rings[gal,radius]
                vgas,vd,vb=(float(row[x]) for x in ('vgas_kms','vdisk_unit_kms','vbul_unit_kms'))
                b2=vgas*abs(vgas)+scale*(.5*vd*abs(vd)+.7*vb*abs(vb))
                pred={'gr':sqrt(b2),'set':4/float(g['f_image'])*sqrt(G_SET*mb/radius),
                      'halo':sqrt(b2+population.v2(radius))}
                for model,v in pred.items():
                    if shift==0:
                        max_difference=max(max_difference,abs(v-float(item[f'{key}_{model}_kms'])))
                    err[key][model].append(abs(v/float(item[f'{key}_obs_kms'])-1)*100)
        scores[str(shift)]={k:{m:float(np.median(vals)) for m,vals in e.items()} for k,e in err.items()}
    assert max_difference<1e-6, "central sensitivity and primary forecaster disagree"
    return scores,max_difference

def main(n):
    out=ROOT/'forty_results'
    blob=read_csv(out/'galaxy_results.csv')
    geom={r['name']:r for r in read_csv(ROOT/'forty_native/geometry.csv')}
    cat={r['galaxy']:r for r in read_csv(ROOT/'forty_sample/inference_catalog.csv')}
    rings={(r['galaxy'],float(r['r_kpc'])):r for r in read_csv(ROOT/'forty_sample/inference_radii.csv')}
    distinct=np.array([float(r['R_last_kpc'])>float(r['R_image_kpc']) for r in blob])
    draws={}
    fractions=[]
    cases=[('reported',0.,0.),('stellar_ml_minus_0p1dex',-.1,0.),('stellar_ml_plus_0p1dex',.1,0.),
           ('shape_incl_rho_minus_0p5',0.,-.5),('shape_incl_rho_plus_0p5',0.,.5)]
    for case,log_ml,rho in cases:
        g_rng=np.random.default_rng(SEED+1)
        rng=np.random.default_rng(SEED+2)
        dev_cluster=rng.standard_normal(n)
        dev_flow=rng.standard_normal(n)
        ml=10**log_ml
        sample={'image':{k:np.empty((n,len(blob))) for k in MODEL_NAMES},
                'last':{k:np.empty((n,len(blob))) for k in MODEL_NAMES}}
        for j,record in enumerate(blob):
            gal=record['galaxy'];r=geom[gal];m=cat[gal]
            d,ed,inc,einc,L,eL,p,ep=map(float,(r['D_Mpc'],r['eD_Mpc'],r['inclination_deg'],
                         r['einclination_deg'],r['L_1e9_Lsun'],r['eL_1e9_Lsun'],r['p'],r['ep']))
            f,si,fraction=geometry_errors(g_rng,n,p,ep,inc,einc,rho)
            if case=='reported': fractions.append((gal,fraction))
            method=int(m['distance_method'])
            shared=(.9/d if method==4 else .07 if method==1 else 0.)
            assert shared<=ed/d
            base=np.ones(n)+shared*(dev_cluster if method==4 else dev_flow)
            dscale=positive_normal(rng,base,sqrt((ed/d)**2-shared**2))
            light=positive_normal(rng,np.ones(n),eL/L)
            stars=ml*float(r['Mstar_Msun'])*dscale**2*light
            mass=stars+1.33e9*float(r['MHI_1e9_Msun'])*dscale**2
            m200,r200,c=halo_arrays(stars)
            f_c=np.log1p(c)-c/(1+c)
            # Shared calibration draws at both endpoints. Bin-level observed errors are not resampled.
            for role,Rkey in [('image','R_image_kpc'),('last','R_last_kpc')]:
                R0=float(record[Rkey]);radius=R0*dscale;row=rings[gal,R0]
                gas,disk,bul=(float(row[k]) for k in ('vgas_kms','vdisk_unit_kms','vbul_unit_kms'))
                vb2=dscale*(gas*abs(gas)+light*ml*(.5*disk*abs(disk)+.7*bul*abs(bul)))
                if np.any(vb2<=0): raise ValueError(f'Outward total force: {gal}')
                u=c*radius/r200
                vh2=halo.G*halo.DM_FRACTION*m200*(np.log1p(u)-u/(1+u))/(f_c*radius)
                obs=float(record[f'{role}_obs_kms'])*np.sin(np.deg2rad(inc))/si
                sample[role]['set'][:,j]=4*np.sqrt(G_SET*mass/radius)/(f*obs)-1
                sample[role]['gr'][:,j]=np.sqrt(vb2)/obs-1
                sample[role]['halo'][:,j]=np.sqrt(vb2+vh2)/obs-1
                if role=='last' and not distinct[j]:
                    assert all(np.array_equal(sample['last'][k][:,j],sample['image'][k][:,j]) for k in MODEL_NAMES)
        used=np.ones(len(blob),dtype=bool)
        means={label:score_sensitivity(sample[which],mask) for label,which,mask in
               [('image','image',used),('last','last',used),('last_distinct','last',distinct)]}
        # Broad source error moves both endpoints of the same galaxy and both model differences together.
        # Pearson correlation across the simulation's paired rank-metric differences.
        deltas={e:np.median(abs(sample[e]['set']),axis=1)-np.median(abs(sample[e]['halo']),axis=1)
                for e in ('image','last')}
        means['corr_set_minus_halo_median_ape_image_last']=float(np.corrcoef(deltas['image'],deltas['last'])[0,1])
        means['corr_model_median_ape_image_last']={
            k:float(np.corrcoef(np.median(abs(sample['image'][k]),axis=1),
                                np.median(abs(sample['last'][k]),axis=1))[0,1])
            for k in MODEL_NAMES}
        draws[case]=means
    deterministic,max_diff=central_ml_scores(blob,geom,rings)
    outinfo={'seed':SEED,'accepted_draws_per_object':n,'n_objects':len(blob),'n_last_distinct':int(distinct.sum()),
             'method':'Fixed sample. Joint Gaussian photometry, distance, p, i sensitivity with physically valid draws. A distance draw scales all masses as D^2 and physical radii as D. Photometry scales both stellar templates together, preserving bulge fraction. GR gas/stars force-template squares scale as D, stellar templates also scale with luminosity and M/L. Measured rotation speeds are redeprojected at both endpoints using the same inclination draw. RC templates are not re-extracted from maps. HI flux, bulge fraction, population means and M/L are fixed except stated variants. No velocity noise resampled. No posterior model probabilities.',
             'cross_object_distance_sensitivity':'Following the original calibration sensitivity, Ursa Major method 4 has a 0.9 Mpc common Gaussian offset; flow method 1 shares a 7% scale. Remaining distance variance independent. Listed errors otherwise independent apart from named rho tests.',
             'ml_cases':'Fixed illustrative common zero-point shifts of -0.1/+0.1 dex to both 0.5 disk and 0.7 bulge M/L. Test if ranks depend on stellar zero point. No target fitting or probability attached to shifts.',
             'deterministic_ml_shift_dex_endpoint_median_ape_pct':deterministic,
             'max_abs_recomputed_vs_primary_central_speed_kms':max_diff,
             'geometry_acceptance_central_rho':{k:v for k,v in fractions},'cases':draws}
    (out/'calibration_sensitivity.json').write_text(json.dumps(outinfo,indent=2)+'\n')
    for k,v in draws.items():
        print(k,[(role,{m:np.round(v[role][m]['median_ape_p025_p50_p975'],2).tolist() for m in MODEL_NAMES},round(v[role]['set']['lowest_median_ape_draw_fraction'],4)) for role in ('image','last','last_distinct')])
    print('geometry acceptance',min(x[1] for x in fractions),np.median([x[1] for x in fractions]))
if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--draws',type=int,default=8192);args=a.parse_args()
    main(args.draws)
