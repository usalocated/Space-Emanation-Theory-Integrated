"""Weak-field baryonic GR and a population-predicted z=0 ΛCDM halo baseline.

All inputs are intrinsic luminosities, radii, and baryonic mass-model components.
There is deliberately no observed-speed parameter. Solar masses, kpc, and km/s
are used throughout. Model calibration is independent of target rotation curves.

Sources:
  https://astroweb.cwru.edu/SPARC/  (Lelli et al. 2016, signed force components)
  https://arxiv.org/pdf/1205.5807   (Moster et al., §2.1, Eq. 2, Table 1)
  https://arxiv.org/pdf/1411.4001   (Klypin et al., Eq. 24, Table A5)
  https://arxiv.org/pdf/1402.7073   (Dutton & Macciò, Table 1 and Eq. 8)

The deterministic central-galaxy point estimate inverts the central relation.
It is not a posterior mean of halo mass conditional on the observed stellar mass.
No halo contraction, tidal truncation, or galaxy-specific feedback prescription
is included. Signed component squares preserve outward disk or gas contributions.
"""

from dataclasses import dataclass
from math import isfinite, log1p, sqrt


G = 4.30091e-6  # kpc (km/s)^2 per solar mass
H0 = 0.0704  # Moster WMAP7, km/s/kpc
OMEGA_M = 0.272
OMEGA_B = 0.0455
DM_FRACTION = 1 - OMEGA_B / OMEGA_M


def stellar_mass(luminosity_total, luminosity_bulge):
    """SET Eq. 225, using SPARC total and bulge luminosities in solar L_3.6."""
    if not 0 <= luminosity_bulge <= luminosity_total:
        raise ValueError("bulge and total luminosities must satisfy 0 <= bulge <= total")
    return 0.5 * (luminosity_total - luminosity_bulge) + 0.7 * luminosity_bulge


def baryonic_v2(vgas, vdisk, vbulge):
    """SET Eq. 232/SPARC: all three input force templates have units km/s."""
    return (vgas * abs(vgas) + 0.5 * vdisk * abs(vdisk)
            + 0.7 * vbulge * abs(vbulge))


def circular_speed(v2):
    """An outward total force has no real circular orbit at this radius."""
    return sqrt(v2) if v2 >= 0 else float("nan")


def moster_stellar_mass(m200):
    ratio = m200 / 10**11.590
    return 2 * 0.0351 * m200 / (ratio**-1.376 + ratio**0.608)


def infer_m200(mstar):
    if not isfinite(mstar) or mstar <= 0:
        raise ValueError("stellar mass must be finite and positive")
    low, high = 1e6, 1e18
    if not moster_stellar_mass(low) <= mstar <= moster_stellar_mass(high):
        raise ValueError("stellar mass outside numerical inversion bracket")
    for _ in range(72):
        trial = sqrt(low * high)
        if moster_stellar_mass(trial) < mstar:
            low = trial
        else:
            high = trial
    return sqrt(low * high)


def nfw_mass_function(x):
    return log1p(x) - x / (1 + x)


@dataclass(frozen=True)
class Halo:
    m200_msun: float
    r200_kpc: float
    concentration: float
    dark_fraction: float = DM_FRACTION

    def dark_mass_within(self, radius):
        if not isfinite(radius) or radius <= 0:
            raise ValueError("radius must be finite and positive")
        mass_fraction = (nfw_mass_function(self.concentration * radius / self.r200_kpc)
                         / nfw_mass_function(self.concentration))
        return self.dark_fraction * self.m200_msun * mass_fraction

    def v2(self, radius):
        return G * self.dark_mass_within(radius) / radius


def population_halo(mstar, relaxed=False):
    """Fixed WMAP7 external population recipe, with optional published sensitivity.

    M200c is the dark-matter-only simulation halo mass (total matter equivalent);
    R200c uses it before multiplying enclosed NFW mass by the cosmic DM fraction.
    The simulation used for Klypin's WMAP7 mass conversion adopts h=0.700.
    """
    m200 = infer_m200(mstar)
    r200 = (G * m200 / (100 * H0**2)) ** (1 / 3)
    scaled_mass = 0.700 * m200 / 1e12
    c0, slope, turnover = (6.90, 0.090, 5.5e5) if relaxed else (6.60, 0.110, 2e6)
    concentration = c0 * scaled_mass**-slope * (1 + (scaled_mass / turnover)**0.4)
    return Halo(m200, r200, concentration)


def dutton_maccio_halo(mstar):
    """Sensitivity with Planck c(M), radius, and cosmic dark fraction.

    Keep the identical Moster estimate of M200c; no target-speed fitting or
    recalibration of the stellar-to-halo relation for the Planck cosmology.
    This is a cross-calibration sensitivity, not an independent new fit.
    """
    m200 = infer_m200(mstar)
    r200 = (G * m200 / (100 * 0.0671**2)) ** (1 / 3)
    concentration = 10**0.905 * (0.671 * m200 / 1e12)**-0.101
    return Halo(m200, r200, concentration, 1 - 0.0490 / 0.3175)


def predict(mstar, radius, vgas, vdisk, vbulge):
    """Return resolved baryon-only and resolved-baryons-plus-NFW speeds."""
    vb2 = baryonic_v2(vgas, vdisk, vbulge)
    halo = population_halo(mstar)
    return circular_speed(vb2), circular_speed(vb2 + halo.v2(radius))


def run(sample_dir, output):
    """Calculate all radius-level predictions without opening any target files."""
    import csv

    with (sample_dir / "inference_catalog.csv").open() as handle:
        catalog = {row["galaxy"]: row for row in csv.DictReader(handle)}
    halo_by_name = {}
    for name, row in catalog.items():
        mstar = stellar_mass(1e9 * float(row["L36_1e9_Lsun"]),
                             1e9 * float(row["Lbulge_1e9_Lsun"]))
        halo_by_name[name] = (population_halo(mstar), population_halo(mstar, relaxed=True),
                              dutton_maccio_halo(mstar))

    with (sample_dir / "inference_radii.csv").open() as source, output.open("w", newline="") as stream:
        fields = ["galaxy", "r_kpc", "vbar2_kms2", "vbar_kms", "vnfw_kms", "vgr_nfw_kms",
                  "vgr_nfw_relaxed_kms", "vgr_nfw_dutton_kms", "m200_msun",
                  "r200_kpc", "c200", "lambda_term_kms2"]
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        for row in csv.DictReader(source):
            main, relaxed, planck = halo_by_name[row["galaxy"]]
            radius = float(row["r_kpc"])
            vb2 = baryonic_v2(float(row["vgas_kms"]), float(row["vdisk_unit_kms"]),
                              float(row["vbul_unit_kms"]))
            vh2 = main.v2(radius)
            writer.writerow(dict(galaxy=row["galaxy"], r_kpc=radius, vbar2_kms2=vb2,
                vbar_kms=circular_speed(vb2), vnfw_kms=circular_speed(vh2),
                vgr_nfw_kms=circular_speed(vb2 + vh2),
                vgr_nfw_relaxed_kms=circular_speed(vb2 + relaxed.v2(radius)),
                vgr_nfw_dutton_kms=circular_speed(vb2 + planck.v2(radius)),
                m200_msun=main.m200_msun, r200_kpc=main.r200_kpc, c200=main.concentration,
                lambda_term_kms2=-(1 - OMEGA_M) * (H0 * radius)**2))


if __name__ == "__main__":
    import argparse
    from pathlib import Path
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("sample_dir", type=Path, help="directory with inference_catalog.csv and inference_radii.csv")
    parser.add_argument("output", type=Path, help="output CSV file")
    args = parser.parse_args()
    run(args.sample_dir, args.output)
