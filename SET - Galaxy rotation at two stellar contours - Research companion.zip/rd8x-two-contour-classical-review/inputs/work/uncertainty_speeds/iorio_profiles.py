"""Use the native angular HI profiles of Iorio et al. at fixed SPARC flux and geometry."""
import csv
import io
import math
import sys
from pathlib import Path
from zipfile import ZipFile
import numpy as np

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
sys.path.insert(0,str(WORK/'uncertainty_cauchy'))
import moments as fm

def read(path):
    with path.open(newline='') as f:return list(csv.DictReader(f))
def put(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,rows[0].keys(),lineterminator='\n');w.writeheader();w.writerows(rows)

def extract(zipname):
    rows=[]
    for g,file in [('DDO168','ddo168'),('UGCA444','wlm')]:
        with ZipFile(zipname) as a:
            content=a.read('finalrot/'+file+'_onlinetab.txt')
        # Extract only angular radii and the released density/error columns.
        data=np.loadtxt(io.BytesIO(content),usecols=(0,10,11))
        for rad,s,e in data:
            rows.append(dict(galaxy=g,r_arcsec=rad,HI_Msun_per_pc2=s,e_HI_Msun_per_pc2=e))
    return rows

def measured_templates(dens,gas_profile,row,edge):
    rb,rl,d=[float(row[k]) for k in ('Rb_kpc','Rlast_kpc','D_Mpc')]
    m=np.array([float(row[k]) for k in ('Mstar_disk_Msun','Mstar_bulge_Msun','MHI_times_1p33_Msun')])
    gas_r=gas_profile[:,0]*math.pi/(180*3600)*d*1000
    edges=np.r_[0.,.5*(gas_r[1:]+gas_r[:-1]),gas_r[-1]+.5*(gas_r[-1]-gas_r[-2]) if edge=='half_ring' else gas_r[-1]]
    rad,disk,bulge=dens.T
    a,da=fm.grid_weights(np.unique(np.r_[rad,edges,rb,rl,0]),12)
    mass=m.sum()
    stars=np.zeros_like(a)
    for i,profile in enumerate((disk,bulge)):
        if m[i]:
            light=a*da*np.interp(a,rad,profile,right=0)
            stars+=m[i]/mass*light/light.sum()
    coeff=np.zeros((len(gas_r),len(a)))
    for j in range(len(gas_r)):
        coeff[j]=a*da*((a>edges[j])&(a<edges[j+1]))
    raw=gas_profile[:,1]@coeff
    gas=(m[2]/mass)*raw/raw.sum()
    assert abs(gas.sum()+stars.sum()-1)<1e-10
    # Independent comparison of fraction inside the image using analytic annulus area.
    rawcheck=(edges[1:]**2-edges[:-1]**2)*gas_profile[:,1]
    within=np.maximum(0,np.minimum(edges[1:],rb)**2-edges[:-1]**2)*gas_profile[:,1]
    cent=gas[:][a<rb].sum()/gas.sum()
    assert abs(cent-within.sum()/rawcheck.sum())<1e-10
    return a/rb,stars,gas,cent,math.pi*1e6*rawcheck.sum(),edges[-1]

def predict(sheet):
    src={r['galaxy']:r for r in read(WORK/'shape_law/source_chain.csv')}
    rowset=[]
    raw=np.polynomial.legendre.leggauss(96);u,w=(raw[0]+1)/2,raw[1]/2
    with ZipFile(WORK/'shape_sparc/BulgeDiskDec_LTG.zip') as z:
        for g in ('DDO168','UGCA444'):
            gas_profile=np.array([[float(r[k]) for k in ('r_arcsec','HI_Msun_per_pc2','e_HI_Msun_per_pc2')] for r in sheet if r['galaxy']==g])
            x=src[g]; dens=np.loadtxt(io.BytesIO(z.read(g+'.dens')))
            m=float(x['Mbar_global_Msun']);q=float(x['eta']);rb=float(x['Rb_kpc']);rl=float(x['Rlast_kpc'])
            for edge in ('half_ring','last_center'):
                a,star,gas,frac,mhi_implied,rout=measured_templates(dens,gas_profile,x,edge)
                mt=star+gas;i=a<1; mqin=mt[i].sum()
                for case,mv,mq in [('full_baryons_global_Q',mt,1.),('full_baryons_enclosed_Q',mt,mqin),('baryons_inside',np.where(i,mt,0),mqin)]:
                    for family in ('isotropic','homothetic'):
                        nz=mv>0;d=fm.evaluate(a[nz],mv[nz],q,rl/rb,family,mq,w,u,rb*fm.KPC,m)
                        rowset.append(dict(galaxy=g,case=case,response_family=family,last_ring_extent=edge,n_gas_centers=len(gas_profile),
                            boundary_kpc=rb,outer_gas_edge_kpc=rout,estimated_HI_profile_mass_Msun=mhi_implied,
                            catalog_MHI_Msun=float(x['MHI_times_1p33_Msun'])/1.33,
                            measured_gas_fraction_inside=frac,uniform_gas_fraction_inside=min(1,(rb/float(x['RHI_1Msun_per_pc2_kpc']))**2),
                            baryon_fraction_inside=mqin,A_eff_over_Ageom=d['A_eff_over_A_geom'],Seff_div_sqrt2_kms=d['Seff_div_sqrt2_kms'],
                            predicted_image_local_kms=d['equatorial_vc_kms'],predicted_last_local_kms=d['last_equatorial_vc_kms']))
    return rowset

if __name__=='__main__':
    sheet=extract(HERE/'iorio_finalrot.zip')
    put(HERE/'iorio_gas_rings.csv',sheet)
    preds=predict(sheet);put(HERE/'iorio_field_predictions.csv',preds)
    t={r['galaxy']:r for r in read(WORK/'forty_results/galaxy_results.csv')}
    bas={(r['galaxy'],r['response_family'],r['case']):r for r in read(WORK/'uncertainty_cauchy/source_predictions.csv')}
    for r in preds:
        b=bas[r['galaxy'],r['response_family'],r['case']]
        r.update(baseline_image_local_kms=b['equatorial_vc_kms'],baseline_last_local_kms=b['last_equatorial_vc_kms'],
            observed_image_kms=t[r['galaxy']]['image_obs_kms'],observed_last_kms=t[r['galaxy']]['last_obs_kms'])
    put(HERE/'iorio_field_checks.csv',preds)
