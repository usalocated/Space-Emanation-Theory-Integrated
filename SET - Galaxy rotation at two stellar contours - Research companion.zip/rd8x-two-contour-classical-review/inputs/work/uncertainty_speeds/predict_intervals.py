"""Predict, then score the uncertainty-marginalized speeds in the 40-object study."""
import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import forty_halo as halo
from forty_native_mc import halo_arrays, positive_normal

MODELS = ('gr', 'set', 'halo')
ROLES = ('image', 'last')
Q = [.025,.16,.5,.84,.975]
SEED = 202611180833
GSET=6.67430e-11*1.988409870698051e30/3.085677581491367e19/1e6
# Each variant has the same number of draws per galaxy; inputs are shared between models.
CASES = {'quoted':{},'ml_minus':{'ml':-.1},'ml_plus':{'ml':.1},
         'rho_minus':{'rho':-.5},'rho_plus':{'rho':.5},
         'independent_tilt':{'independent_tilt':True}, 'unconditioned_benchmarks':{'unconditioned_benchmarks':True},
         'catalog_HI10':{'global_gas_scatter':.10},
         'published_extra_gas_errors':{'use_measured_gas':True},
         'source_rings':{'source_ring':True, 'use_measured_gas':True},
         'source_rings_local_stars':{'source_ring':True,'local_stars':True, 'use_measured_gas':True},
         'source_rings_alt_flux':{'source_ring':True, 'use_measured_gas':True, 'replace_flux':True},
         'local_stars_alt_flux':{'source_ring':True,'local_stars':True,'use_measured_gas':True,'replace_flux':True}}

def read(path):
    with path.open(newline='') as f:return list(csv.DictReader(f))
def put(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,list(rows[0]),lineterminator='\n')
        w.writeheader();w.writerows(rows)

def source_inputs(root):
    cat={r['galaxy']:r for r in read(root/'forty_sample'/'inference_catalog.csv')}
    approx={r['name']:r for r in read(root/'forty_native'/'geometry.csv')}
    rings={(r['galaxy'],float(r['r_kpc'])):r for r in read(root/'forty_sample'/'inference_radii.csv')}
    draw=read(root/'forty_sample'/'sample40.csv')
    extra_path=root/'uncertainty_speeds'/'observer_inputs.csv'
    gas={r['galaxy']:r for r in read(extra_path)} if extra_path.exists() else {}
    assert len(draw)==40
    return cat,approx,rings,draw,gas

def stream(rank,which,n):
    return np.random.default_rng(np.random.SeedSequence([SEED,rank,which]))

def shape_and_angle(rng,n,p,ep,i0,ei,rho):
    # This implements the original physical-domain rejection while retaining signed tilt offsets.
    thickness=[];angles=[];total=0;tried=0
    while total<n:
        count=max(1024,n-total)
        z=rng.standard_normal(count)
        pp=p+ep*z
        ang=i0+ei*(rho*z+math.sqrt(1-rho*rho)*rng.standard_normal(count))
        ii=np.deg2rad(ang);si=np.sin(ii);q2=(pp**2-np.cos(ii)**2)/si**2
        valid=(pp>0)&(pp<=1)&(q2>=0)&(q2<=1)&(abs(si)>0)
        thickness.append(q2[valid]);angles.append(ang[valid])
        total+=int(valid.sum());tried+=count
    q2=np.concatenate(thickness)[:n];e=np.sqrt(1-q2)
    ratio=np.divide(np.arcsinh(np.divide(e,np.sqrt(q2),out=np.zeros_like(e),where=q2>0)),e,
                    out=np.ones_like(e),where=e>0)
    return 2*(1+q2*ratio), np.concatenate(angles)[:n],total/tried

def realize(inputs,n,case):
    """Forecast in the reported-catalog speed convention. No observed speed is an input."""
    cat,approx,rings,draw,supplement=inputs
    config=CASES[case]
    ml=10**config.get('ml',0.); rho=config.get('rho',0.)
    all_c=stream(0,1,n).standard_normal(n)
    all_h=stream(0,2,n).standard_normal(n)
    blocks=np.empty((len(draw),2,3,n))
    circular_medians=np.empty((len(draw),2,3))
    sigma_rows=[]
    for j,drow in enumerate(draw):
        g=drow['galaxy']; row=cat[g]; geo=approx[g]
        d,sd,inc,ei,L,sL,p,ep=map(float,(row['d_mpc'],row['e_d_mpc'],row['inclination_deg'],row['e_inc_deg'],
                         row['L36_1e9_Lsun'],row['e_L36_1e9_Lsun'],geo['p'],geo['ep']))
        paper=supplement.get(g,{})
        ring_i=[float(paper.get(key,'') or inc) if config.get('source_ring') else inc for key in ['ring_i_image_deg','ring_i_last_deg']]
        image_i=ring_i[0] if config.get('local_stars') else inc
        f,angle,acc=shape_and_angle(stream(j+1,0,n),n,p,ep,image_i,ei,rho)
        nominal_eta2=(p*p-math.cos(math.radians(image_i))**2)/math.sin(math.radians(image_i))**2
        signed_tilt_error=angle-image_i
        free_tilt_error=ei*stream(j+1,1,n).standard_normal(n)
        sin0=math.sin(math.radians(inc))
        sini_free=np.abs(np.sin(np.deg2rad(inc+free_tilt_error)))
        free_benchmark=config.get('unconditioned_benchmarks',False)
        method=int(row['distance_method'])
        sd_common=(.9/d if method==4 else .07 if method==1 else 0.)
        assert sd_common<=sd/d+1e-10
        mean=1+sd_common*(all_c if method==4 else all_h)
        ds=positive_normal(stream(j+1,2,n),mean,math.sqrt(max(0,(sd/d)**2-sd_common**2)))
        light=positive_normal(stream(j+1,3,n),np.ones(n),sL/L)
        sig_gas=0.
        if config.get('use_measured_gas') and paper.get('eFHI_Jy_kms'):
            if paper['flux_treatment'].startswith('same') or config.get('replace_flux'):
                sig_gas=float(paper['eFHI_Jy_kms'])/float(paper['FHI_Jy_kms'])
        if config.get('global_gas_scatter'):
            sig_gas=config['global_gas_scatter']
        gas_center=1.
        if config.get('replace_flux') and paper.get('FHI_Jy_kms') and not paper['flux_treatment'].startswith('same'):
            gas_center=float(paper['FHI_Jy_kms'])/float(paper['sparc_implied_FHI'])
        gas=gas_center*positive_normal(stream(j+1,4,n),np.ones(n),sig_gas)
        stars=ml*float(geo['Mstar_Msun'])*ds**2*light
        baryons=stars+1.33e9*float(row['MHI_1e9_Msun'])*ds**2*gas
        m200,r200,c=halo_arrays(stars)
        fc=np.log1p(c)-c/(1+c)
        rs=list(map(float,[geo['Rcmp_kpc'],geo['Rlast_kpc']]))
        assert rs[1]>=rs[0]
        budget={}
        for ir,r in enumerate(rs):
            rc=rings[g,r]; rad=r*ds
            # Compare to each source's already deprojected tabulation. Its central speed
            # stays untouched; only a draw's relative change from the native ring tilt enters.
            ring0=ring_i[ir]
            eps=free_tilt_error if config.get('independent_tilt') else signed_tilt_error
            projection=abs(np.sin(np.deg2rad(ring0+eps)))/math.sin(math.radians(ring0))

            vg,vd,vb=[float(rc[key]) for key in ('vgas_kms','vdisk_unit_kms','vbul_unit_kms')]
            b2=ds*(gas*vg*abs(vg)+light*ml*(.5*vd*abs(vd)+.7*vb*abs(vb)))
            assert np.all(b2>0)
            u=c*rad/r200
            vh2=halo.G*halo.DM_FRACTION*m200*(np.log1p(u)-u/(1+u))/(rad*fc)
            speeds=np.array([np.sqrt(b2),4*np.sqrt(GSET*baryons/rad)/f,np.sqrt(b2+vh2)])
            circular_medians[j,ir]=np.median(speeds,axis=1)
            blocks[j,ir]=speeds*projection
            log_components=np.array([.5*np.log(ds),.5*np.log(baryons/ds**2),np.log(projection/f)])
            variances=log_components.var(axis=1)
            denom=variances.sum()
            frac=variances/denom if denom>0 else np.zeros(3)
            budget[ROLES[ir]]=dict(var_log_distance=variances[0],var_log_photometry_and_gas=variances[1],
                var_log_shape_inclination=variances[2],var_log_total=np.var(np.log(blocks[j,ir,1])),
                frac_distance=frac[0],frac_photometry_and_gas=frac[1],frac_shape_inclination=frac[2])
            if free_benchmark:
                blocks[j,ir,[0,2]]=speeds[[0,2]]*sini_free/sin0
        if rs[0]==rs[1]: assert np.array_equal(blocks[j,0],blocks[j,1])
        sigma_rows.append(dict(galaxy=g,r_image=rs[0],r_last=rs[1],p_geometry_pass=acc,sigma_gas_fraction=sig_gas,gas_center_scale=gas_center,image_i_used=image_i,published_i_shape=inc,ring_i_image=ring_i[0],ring_i_last=ring_i[1],nominal_oblate_valid=nominal_eta2>=0,has_VS_ring=paper.get('ring_match')=='yes',budget=budget))
    return blocks,circular_medians,sigma_rows

def summarize_forecasts(draws,circular,meta,case):
    # All published raw forecasts/column values are locked before obtaining the targets.
    forecast_rows=[]
    for j,info in enumerate(meta):
        for k,endpoint in enumerate(ROLES):
            for h,model in enumerate(MODELS):
                s=draws[j,k,h];qs=np.quantile(s,Q)
                row={'galaxy':info['galaxy'],'role':endpoint,'radius_kpc':info['r_'+endpoint],'model':model,'case':case}
                row.update({label:float(z) for label,z in zip(('p025','p16','median','p84','p975'),qs)})
                row.update(mean=float(np.mean(s)),median_intrinsic_circular=float(circular[j,k,h]),p_geometry_pass=info['p_geometry_pass'])
                forecast_rows.append(row)
    return forecast_rows

def bootstrap(x,y):
    rng=stream(0,9,len(x));ids=rng.integers(0,len(x),(12000,len(x)))
    d=np.median(x[ids],axis=1)-np.median(y[ids],axis=1)
    return np.quantile(d,[.025,.5,.975]).tolist()

def crps(d,obs):
    """Empirical ensemble CRPS, E|X-y| - 0.5 E|X-X'|, in km/s."""
    n=len(d); weights=2*np.arange(1,n+1)-n-1
    # Multiplying before mean avoids multi-threaded BLAS overhead on small arrays.
    return np.mean(np.abs(d-obs))-np.sum(np.sort(d)*weights)/(n*n)

def score(root,src,case,n):
    draws,circular,meta,fs=src
    measured={(r['galaxy'],float(r['r_kpc'])):r for r in read(root/'forty_sample/target_resolved.csv')}
    central={(r['galaxy'],float(r['r_kpc'])):r for r in read(root/'forty_results/forecasts.csv')}
    byrole={}
    records=[];full=case=='quoted' or case=='published_extra_gas_errors' or case.startswith('source_rings') or case=='local_stars_alt_flux'
    for k,role in enumerate(ROLES):
        mm=draws[:,k,:,:]
        obs=np.array([float(measured[x['galaxy'],x['r_'+role]]['vobs_kms']) for x in meta])
        err=np.array([float(measured[x['galaxy'],x['r_'+role]]['e_vobs_kms']) for x in meta])
        # Repeat the same error deviate for all models of a galaxy, and for shared endpoints.
        noise=np.array([stream(j+1,10+(0 if k==0 or x['r_image']==x['r_last'] else 1),n).normal(size=n)*e for j,(x,e) in enumerate(zip(meta,err))])
        ca=np.array([[float(central[x['galaxy'],x['r_'+role]][m+'_kms']) for m in MODELS] for x in meta])
        med=np.array([r['median'] for r in fs if r['role']==role]).reshape(len(meta),3)
        avg=np.array([r['mean'] for r in fs if r['role']==role]).reshape(len(meta),3)
        masks=[('all',np.ones(len(obs),bool))]
        if role=='last':masks.append(('strict',np.array([r['r_last']>r['r_image'] for r in meta])))
        if full:
            vs=np.array([r['has_VS_ring'] for r in meta])
            if vs.any():masks.append(('VS01',vs))
            phys=np.array([r['nominal_oblate_valid'] for r in meta])
            if not phys.all():masks.append(('valid',phys))
        for sub,mask in masks:
            label=role if sub=='all' else 'last_distinct' if sub=='strict' else role+'_'+sub
            x=obs[mask];dx=err[mask]
            source_ae=100*np.abs(mm[mask]/x[:,None,None]-1)
            sample_median_errors=np.median(source_ae,axis=0)
            # Measurement-side sensitivity to catalogue errors; repeated measurements differ from immutable reported centers.
            sampled_y=x[:,None]+noise[mask]
            noisy_ae=100*np.abs(mm[mask]/np.where(sampled_y>0,sampled_y,np.nan)[:,None,:]-1)
            noisy_median_errors=np.nanmedian(noisy_ae,axis=0)
            ape=100*np.abs(med[mask]/x[:,None]-1)
            central_ape=100*np.abs(ca[mask]/x[:,None]-1)
            pairdiff=sample_median_errors[1]-sample_median_errors[2]
            noisediff=noisy_median_errors[1]-noisy_median_errors[2]
            result={'n':int(mask.sum()),'models':{},'set_minus_halo_median_ape_pp':float(np.median(ape[:,1])-np.median(ape[:,2])),
                    'source_draw_difference_pp_p025_p50_p975':np.quantile(pairdiff,[.025,.5,.975]).tolist(),
                    'source_and_measurement_draw_difference_pp_p025_p50_p975':np.quantile(noisediff,[.025,.5,.975]).tolist(),
                    'set_smaller_sample_median_error_fraction_source_draws':float(np.mean(pairdiff<0)),
                    'set_smaller_sample_median_error_fraction_source_and_measurement_draws':float(np.mean(noisediff<0)),
                    'paired_bootstrap_point_median_set_minus_halo_pp':bootstrap(ape[:,1],ape[:,2]),
                    'set_ensemble_point_beats_gr':int(sum(ape[:,1]<ape[:,0])),'set_ensemble_point_beats_halo':int(sum(ape[:,1]<ape[:,2]))}
            for h,m in enumerate(MODELS):
                source=mm[mask,h,:]
                central_pred=ca[mask,h];point=med[mask,h]
                source_q=np.quantile(source,Q,axis=1)
                joined=source+noise[mask]
                joint_q=np.quantile(joined,Q,axis=1)
                def diag(lo,hi):
                    return int(sum((lo<=x)&(x<=hi)))
                model={'central_ape_median_pct':float(np.median(central_ape[:,h])),
                       'median_forecast_ape_median_pct':float(np.median(ape[:,h])),
                       'mean_forecast_ape_median_pct':float(np.median(100*np.abs(avg[mask,h]/x-1))),
                       'median_forecast_ape_mean_pct':float(np.mean(ape[:,h])),
                       'central_bias_median_pct':float(np.median(100*(central_pred/x-1))),
                       'median_forecast_bias_median_pct':float(np.median(100*(point/x-1))),
                       'prior_median_closer_than_nominal_count':int(sum(ape[:,h]<central_ape[:,h])),
                       'point_within_10pct':int(sum(ape[:,h]<=10)),
                       'point_within_20pct':int(sum(ape[:,h]<=20)),
                       'median_speed_change_pct':float(np.median(100*(point/central_pred-1))),
                       'median_abs_speed_change_pct':float(np.median(100*abs(point/central_pred-1))),
                       'source_only_inside68':diag(source_q[1],source_q[3]),
                       'source_only_inside95':diag(source_q[0],source_q[4]),
                       'paper_overlap68_vs_observed_1sigma':int(sum((source_q[1]<=x+dx)&(source_q[3]>=x-dx))),
                       'paper_overlap95_vs_observed_1sigma':int(sum((source_q[0]<=x+dx)&(source_q[4]>=x-dx))),
                       'joint_observable_inside68':diag(joint_q[1],joint_q[3]),
                       'joint_observable_inside95':diag(joint_q[0],joint_q[4]),
                       'joint_observable_median_68_full_width_pct_observed':float(np.median(100*(joint_q[3]-joint_q[1])/x)),
                       'joint_observable_median_95_full_width_kms':float(np.median(joint_q[4]-joint_q[0])),
                       'joint_observable_median_68_full_width_kms':float(np.median(joint_q[3]-joint_q[1])),
                       'joint_observable_median_95_full_width_pct_observed':float(np.median(100*(joint_q[4]-joint_q[0])/x)),
                       'prior_point_error_after_minus_before_paired_bootstrap95':bootstrap(ape[:,h],central_ape[:,h]),
                       'source_draw_median_ape_pct_quantiles':np.quantile(sample_median_errors[h],[.025,.5,.975]).tolist()}
                if full:
                    cr=np.array([crps(s,t) for s,t in zip(joined,x)])
                    model['joint_observable_mean_crps_kms']=float(np.mean(cr))
                    model['joint_observable_mean_crps_percent_of_observed']=float(np.mean(100*cr/x))
                result['models'][m]=model
                if sub=='all' and full:
                    for j,d in enumerate(meta):
                        sx,tx=source_q[:,j],joint_q[:,j]
                        records.append(dict(galaxy=d['galaxy'],role=role,radius_kpc=d['r_'+role],model=m,case=case,
                             measured_kms=x[j],reported_error_kms=dx[j],previous_nominal_kms=central_pred[j],median_forecast_kms=point[j],
                             median_forecast_intrinsic_circular_kms=circular[j,k,h],mean_forecast_kms=avg[j,h],
                             source68_lo=sx[1],source68_hi=sx[3],source95_lo=sx[0],source95_hi=sx[4],
                             obs68_lo=tx[1],obs68_hi=tx[3],obs95_lo=tx[0],obs95_hi=tx[4],
                             previous_ape_pct=central_ape[j,h],median_forecast_ape_pct=ape[j,h],
                             crps_observable_kms=cr[j],shape_acceptance=d['p_geometry_pass'],added_hi_flux_fractional_error=d['sigma_gas_fraction'],
                             gas_center_scale=d['gas_center_scale'],shape_i_center_deg=d['image_i_used'],
                             native_ring_i_center_deg=d['ring_i_'+role],valid_oblate_at_center=int(d['nominal_oblate_valid'])))
            byrole[label]=result
    return byrole,records

def main(root,out,n,cases):
    out.mkdir(exist_ok=True,parents=True)
    seeds=source_inputs(root)
    info={'seed':SEED,'n':n,'cases':{}}
    for case in cases:
        cubes,circ,meta=realize(seeds,n,case)
        f=summarize_forecasts(cubes,circ,meta,case)
        if case in ['quoted','source_rings','source_rings_alt_flux']:
            variance_rows=[dict(galaxy=m['galaxy'],role=e,case=case,**m['budget'][e]) for m in meta for e in ROLES]
            put(out/('variance_budget_'+case+'.csv'),variance_rows)
        p=out/('forecasts_'+case+'.csv');put(p,f)
        qs=hashlib.sha256(p.read_bytes()).hexdigest()
        s,records=score(root,(cubes,circ,meta,f),case,n)
        info['cases'][case]={'forecast_sha256':qs,'scores':s}
        if records:put(out/('scores_'+case+'.csv'),records)
        for r in ['image','last','last_distinct']:
            v=s[r];print(case,r,[(m,round(v['models'][m]['median_forecast_ape_median_pct'],3),v['models'][m]['joint_observable_inside95']) for m in MODELS],flush=True)
        del cubes
        (out/'summary.json').write_text(json.dumps(info,indent=2)+'\n')
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--draws',type=int,default=32768)
    p.add_argument('--cases',type=str,nargs='+',choices=CASES.keys(),default=list(CASES))
    a=p.parse_args();main(a.root,a.out,a.draws,a.cases)
