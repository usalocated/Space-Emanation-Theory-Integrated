"""Predict at catalog fixed-brightness stellar contours before interpolating measured velocities."""
import argparse
import bisect
import collections
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import sys
from zipfile import ZipFile
import numpy as np

D=Path(__file__).resolve().parent;W=D.parent
sys.path.insert(0,str(W));sys.path.insert(0,str(W/'uncertainty_cauchy'))
import forty_halo as halo
import moments as fm
LEVELS=('native','25.5','26.5')
MODELS=('gr','uniform','isotropic_surface','halo','isotropic_gradient')

def read(path):
    with path.open() as f:return list(csv.DictReader(f))
def write(path,r):
    with path.open('w',newline='') as f:
        headers=list(dict.fromkeys(k for x in r for k in x))
        w=csv.DictWriter(f,headers,lineterminator='\n');w.writeheader();w.writerows(r)
def freeze(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def collect(root,out):
    name_map={r['name']:r['S4G_name'] for r in read(root/'forty_native/geometry.csv')}
    trimmed={r['object']:r for r in read(root/'shape_geometry/s4g_catalog_excerpt.csv')}
    fixed={r['galaxy']:r for r in read(root/'shape_geometry/per_galaxy_geometry.csv')}
    sample=read(root/'forty_sample/sample40.csv');shapes=[];n=len(sample)
    assert n==40 and len(fixed)==n
    for r in sample:
        g=r['galaxy'];i=name_map[g];s=trimmed[i]
        # Confirm the reduction against the exact per_galaxy_geometry.csv columns used in the old audit.
        for level,tag in [('25.5','25p5'),('26.5','26p5')]:
            p=1-float(s['ellip1_'+tag]) if s['ellip1_'+tag] else None
            a=float(s['sma1_'+tag]) if s['sma1_'+tag] else None
            assert (a is None or a==float(fixed[g]['r'+tag+'mag_arcsec']))
            assert (p is None or p==float(fixed[g]['p_s4g_'+tag+'mag']))
            shapes.append(dict(galaxy=g,s4g_name=i,level_ab_mag_arcsec2=level,semi_major_arcsec=a,projected_axis_ratio=p))
    write(out/'photometry_inputs.csv',shapes)

def bracket(radii,r):
    j=bisect.bisect_left(radii,r)
    if j<len(radii) and abs(radii[j]-r)<1e-8:return j,j,0.
    if j>0 and abs(radii[j-1]-r)<1e-8:return j-1,j-1,0.
    if j==0 or j==len(radii):return None
    return j-1,j,(r-radii[j-1])/(radii[j]-radii[j-1])

def source_forecast(root,out):
    photo={(r['galaxy'],r['level_ab_mag_arcsec2']):r for r in read(out/'photometry_inputs.csv')}
    source={r['galaxy']:r for r in read(root/'shape_law/source_chain.csv')}
    bygal=collections.defaultdict(list)
    for r in read(root/'forty_sample/inference_radii.csv'):bygal[r['galaxy']].append(r)
    forecasts=[];flags=[];u,w=np.polynomial.legendre.leggauss(96);u,w=(1+u)/2,w/2
    with ZipFile(root/'shape_sparc/BulgeDiskDec_LTG.zip') as z:
        for g,s in source.items():
            dens=np.loadtxt(io.BytesIO(z.read(g+'.dens')))
            M=np.array([float(s[k]) for k in ('Mstar_disk_Msun','Mstar_bulge_Msun','MHI_times_1p33_Msun')])
            total=M.sum();Rorig=float(s['Rb_kpc']);dist=float(s['D_Mpc']);inc=math.radians(float(s['inclination_deg']))
            rad=[float(v['r_kpc']) for v in bygal[g]]
            assert rad==sorted(rad) and len(rad)==len(set(rad))
            pop=halo.population_halo(M[0]+M[1])
            for lev in LEVELS:
                xx=(s['angular_boundary_arcsec'],s['p_axis_ratio']) if lev=='native' else (photo[g,lev]['semi_major_arcsec'],photo[g,lev]['projected_axis_ratio'])
                f=dict(galaxy=g,contour=lev,original_radius_kpc=Rorig,angle_arcsec=xx[0],projected_axis_ratio=xx[1],distance_mpc=dist,inclination_deg=math.degrees(inc),
                       min_kinematic_radius_kpc=min(rad),max_kinematic_radius_kpc=max(rad))
                if not xx[0] or not xx[1]:
                    f['status']='missing_catalog_contour';flags.append(f);continue
                a,p=map(float,xx)
                R=Rorig if lev=='native' else a*math.pi/(180*3600)*dist*1000
                q2=(p*p-math.cos(inc)**2)/math.sin(inc)**2
                br=bracket(rad,R)
                f.update(radius_kpc=R,q_squared=q2,radius_within_kinematic_support=int(br is not None),nominal_physical_oblate=int(0<p<=1 and 0<=q2<=1))
                if not f['nominal_physical_oblate']:
                    f['status']='unphysical_central_oblate';flags.append(f);continue
                q=math.sqrt(q2);rho=float(s['RHI_1Msun_per_pc2_kpc'])
                # The right integration boundary uses no kinematic radius.
                nodes,st,gas=fm.shell_mass(dens,R,R,rho,*M,12)
                ok=st+gas>0
                m=fm.evaluate(nodes[ok],(st+gas)[ok],q,1.,'isotropic',1.,w,u,R*fm.KPC,total)
                vu=math.sqrt(fm.GMSUN*total/(R*fm.KPC))*4*np.pi*(R*fm.KPC)**2/m['A_geom_m2']/1000
                assert abs(vu*m['A_geom_over_A_eff']-m['Seff_div_sqrt2_kms'])<2e-8
                assert abs(m['Qsurf_over_Qref']-1)<1e-10
                pred=dict(galaxy=g,contour=lev,radius_kpc=R,nominal_thickness=q,global_Q_m3_per_s=m['Qref_m3s'],boundary_Seff_kms=m['Seff_kms'],
                          uniform_kms=vu,isotropic_surface_kms=m['Seff_div_sqrt2_kms'],isotropic_gradient_kms=m['equatorial_vc_kms'],
                          A_geom_over_A_eff=m['A_geom_over_A_eff'],gas_fraction_inside=gas[nodes<1].sum()/gas.sum(),baryonic_fraction_inside=(st+gas)[nodes<1].sum())
                if br is None:
                    f['status']='outside_kinematic_range';flags.append(f);forecasts.append(pred);continue
                lo,hi,alpha=br;rl,rh=rad[lo],rad[hi]
                def v2(i):
                    return halo.baryonic_v2(*[float(bygal[g][i][k]) for k in ('vgas_kms','vdisk_unit_kms','vbul_unit_kms')])
                accum=(1-alpha)*v2(lo)+alpha*v2(hi)
                pred.update(gr_kms=math.sqrt(accum),halo_kms=math.sqrt(accum+pop.v2(R)),
                            bracket_lo_kpc=rl,bracket_hi_kpc=rh,interpolation_weight=alpha)
                f['status']='scored';flags.append(f);forecasts.append(pred)
    write(out/'forecasts.csv',forecasts);write(out/'eligibility.csv',flags)
    (out/'forecast.sha256').write_text(freeze(out/'forecasts.csv')+'\n')
    return forecasts,flags

def score(root,out,flags,forecasts):
    assert freeze(out/'forecasts.csv')==(out/'forecast.sha256').read_text().strip()
    tar={(r['galaxy'],float(r['r_kpc'])):r for r in read(root/'forty_sample/target_resolved.csv')}
    scored=[]
    for r in forecasts:
        if 'bracket_lo_kpc' not in r:continue
        g=r['galaxy'];alpha=r['interpolation_weight'];lo,hi=r['bracket_lo_kpc'],r['bracket_hi_kpc']
        ob,oh=[tar[g,v] for v in (lo,hi)]
        L,H=[float(v['vobs_kms']) for v in (ob,oh)]; dl,dh=[float(v['e_vobs_kms']) for v in (ob,oh)]
        target=(1-alpha)*L+alpha*H
        y=dict(**r,observed_interp_kms=target,observed_nearest_kms=L if alpha<=.5 else H,observed_lo_kms=L,observed_hi_kms=H,
               error_if_bins_independent_kms=math.hypot((1-alpha)*dl,alpha*dh),
               error_if_bins_shared_kms=(1-alpha)*dl+alpha*dh)
        for model in MODELS:y[model+'_ape']=100*abs(y[model+'_kms']/target-1)
        scored.append(y)
    write(out/'scores.csv',scored)
    ids={k:{r['galaxy'] for r in scored if r['contour']==k} for k in LEVELS}
    lookup={(r['galaxy'],r['contour']):r for r in scored}
    agg=[];stats={}
    for tag,gs in [('25.5',ids['25.5']),('26.5',ids['26.5']),('common',ids['25.5']&ids['26.5'])]:
        sub=['native',tag] if tag!='common' else list(LEVELS)
        for lev in sub:
            rows=[lookup[g,lev] for g in sorted(gs)]
            for model in MODELS:
                ae=np.array([r[model+'_ape'] for r in rows])
                v=np.array([r[model+'_kms'] for r in rows]);obs=np.array([r['observed_interp_kms'] for r in rows])
                agg.append(dict(selection=tag,contour=lev,model=model,n=len(ae),median_APE_pct=np.median(ae),mean_APE_pct=np.mean(ae),
                    median_signed_error_pct=100*np.median(v/obs-1),rmse_kms=np.mean((v-obs)**2)**.5,
                    within10=(ae<=10).sum(),within20=(ae<=20).sum(),
                    median_APE_nearest_target_pct=np.median([100*abs(r[model+'_kms']/r['observed_nearest_kms']-1) for r in rows])))
            R=np.array([r['radius_kpc']/lookup[r['galaxy'],'native']['radius_kpc'] for r in rows])
            gap=np.array([(r['bracket_hi_kpc']-r['bracket_lo_kpc'])/r['radius_kpc'] for r in rows])
            old=np.array([lookup[r['galaxy'],'native']['isotropic_surface_ape'] for r in rows]); new=np.array([r['isotropic_surface_ape'] for r in rows])
            stats[tag+'_'+lev]=dict(n=len(R),radius_ratio_median=np.median(R),r_smaller=int((R<1).sum()),r_larger=int((R>1).sum()),median_relative_bracket_width=np.median(gap),max_relative_bracket_width=max(gap),isotropic_closer_count=int((new<old).sum()))
    write(out/'summary.csv',agg)
    count={k:dict(collections.Counter(r['status'] for r in flags if r['contour']==k)) for k in LEVELS}
    (out/'checks.json').write_text(json.dumps(dict(forecast_sha256=freeze(out/'forecasts.csv'),eligibility=count,selections=stats),indent=2)+'\n')
    return agg
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,default=W);ap.add_argument('--out',type=Path,default=D)
    args=ap.parse_args();args.out.mkdir(exist_ok=True,parents=True)
    collect(args.work,args.out);f,flags=source_forecast(args.work,args.out);result=score(args.work,args.out,flags,f)
    for r in result:
        if r['selection']!='common':print(r['selection'],r['contour'],r['model'],r['n'],round(r['median_APE_pct'],3))
