"""Conditional optical-contour surface, gradient, baryon, and population halo forecasts."""
import argparse,collections,io,math,sys
from zipfile import ZipFile
from pathlib import Path
import numpy as np
from photometric_radii import W,D,read,write,bracket,freeze,MODELS,fm,halo
for path in ('uncertainty_speeds','uncertainty_cauchy','consensus_gas','consensus_review'):
    sys.path.insert(0,str(W/path))
import field_uncertainty as fu
import predict_intervals as mc
from forty_native_mc import halo_arrays
import revisit
from preferred_shells import GasProfiles

def kernel_tables(qs,a,st,gas,u,gridsize):
    qmin=min(float(q.min()) for q in qs)
    grid=np.linspace(math.log(min(qmin*.99,.004)),0.,gridsize)
    pairs=[fu.basis(float(q),a,st,gas,u,1.) for q in np.exp(grid)]
    return grid,np.array([r[0] for r in pairs]),np.array([r[1] for r in pairs])

def calc(q,fl,fg,ds,vs,a,st,gas,w,u,table):
    ans=np.zeros((3,len(q)))
    for lo in range(0,len(q),2048):
        ii=slice(lo,lo+2048); qi=q[ii];V,F=fu.interp(table[1],table[0],np.log(qi)),fu.interp(table[2],table[0],np.log(qi))
        h=w*np.sqrt(qi[:,None]**2+(1-qi[:,None]**2)*u**2)
        ph=V[:,0]*fl[ii,None]+V[:,1]*fg[ii,None]
        J=(h*np.sqrt(ph)).sum(axis=1);I=(h*ph).sum(axis=1)
        F=F[:,0,0]*fl[ii]+F[:,1,0]*fg[ii]
        mt=st.sum()*fl[ii]+gas.sum()*fg[ii]
        amp=np.sqrt(ds[ii]*mt)*vs
        ans[:,ii]=[amp/h.sum(axis=1),amp*I/J**2,amp*np.sqrt(F)/J]
    return ans

def tilted_ring_centers(root,s):
    db=collections.defaultdict(list)
    for r in read(root/'uncertainty_lit_b/VS01_ring_data.csv'):
        db[r['galaxy']].append((float(r['r_arcsec']),float(r['i_deg'])))
    def get(g,R,inc,dist):
        angle=R/(dist*1000)*(180*3600)/math.pi
        if g in db:
            z=min(db[g],key=lambda x:abs(x[0]-angle))
            if abs(z[0]-angle)<=1.25:return z[1],'matched VS01 ring'
        if g in ('NGC5033','NGC5585','NGC6503'):
            return float(s[g]['ring_i_image_deg']),'source adopted constant'
        return inc,'catalog global proxy'
    return get

def data_generator(root,out,n,gridsize,preferred=True,forecast_rows=None):
    inputs=mc.source_inputs(root);cat,geo,rot,sample,supp=inputs
    sources,radials=revisit.assemble(root)
    gas_record=GasProfiles(root)
    prefrows=read(out/'forecasts.csv') if forecast_rows is None else forecast_rows;fixed=read(out/'eligibility.csv');R_lookup={(r['galaxy'],r['contour']):r for r in fixed}
    proxy={(r['galaxy'],r['level_ab_mag_arcsec2']):r for r in read(out/'contour_fit_error_proxies.csv')}
    get_i=tilted_ring_centers(root,supp)
    ix={g['galaxy']:j+1 for j,g in enumerate(sample)}
    u,w=np.polynomial.legendre.leggauss(72);u,w=(1+u)/2,w/2
    zcal=0.;badkernel=0.
    for fr in prefrows:
        g,level=fr['galaxy'],fr['contour']
        if fr['bracket_lo_kpc']=='':continue
        rr=R_lookup[g,level];R=float(fr['radius_kpc']);j=ix[g];s=sources[g];c=cat[g]
        rad0=float(s['Rb_kpc']);masses=np.array([float(s[k]) for k in ('Mstar_disk_Msun','Mstar_bulge_Msun','MHI_times_1p33_Msun')])
        mt=masses.sum(); mstar=sum(masses[:2]);vs=math.sqrt(fm.GMSUN*mt/(fm.KPC*R))/1000
        with ZipFile(root/'shape_sparc/BulgeDiskDec_LTG.zip') as z:
            dens=np.loadtxt(io.BytesIO(z.read(g+'.dens')))
        source_label=radials[g][0] if preferred else 'RHI template'
        a,st,gas=gas_record.shells(s,source_label,dens,R,masses)
        assert abs(st.sum()+gas.sum()-1.)<1e-10
        nz=st+gas>0;a,st,gas=a[nz],st[nz],gas[nz]
        inc=float(c['inclination_deg']);di=float(c['e_inc_deg']);dist=float(c['d_mpc']);p=float(rr['projected_axis_ratio'])
        branch=[('fixed_contour',0.)]
        pe=geo[g]['ep'] if level=='native' else proxy[g,level]['p_error_proxy']
        if pe:branch.append(('local_p_proxy',float(pe)))
        e_archive=geo[g]['ep'] if level=='native' else proxy[g,level].get('archive_p_error_proxy')
        if e_archive:branch.append(('archive_p_proxy',float(e_archive)))
        # Nuisance variables are sampled without observed velocities.
        params=[]
        for label,dp in branch:
            f,angles,frac=mc.shape_and_angle(mc.stream(j,0,n),n,p,dp,inc,di,0.)
            params.append((label,fu.recover_axis(f),angles,frac))
        # For an alternative conditioned on an incompatible central shape, the
        # median feasible thickness serves only as a quadrature check.
        q0=float(fr['nominal_thickness']) if fr.get('nominal_thickness') else float(np.median(params[0][1]));nom=np.array([q0]);table=kernel_tables([r[1] for r in params]+[nom],a,st,gas,u,gridsize)
        erd=float(c['e_d_mpc']);meth=int(c['distance_method'])
        common=.9/dist if meth==4 else .07 if meth==1 else 0.
        ds=mc.positive_normal(mc.stream(j,2,n),1+mc.stream(0,1 if meth==4 else 2,n).standard_normal(n)*common,math.sqrt(max(0,(erd/dist)**2-common**2)))
        fl=mc.positive_normal(mc.stream(j,3,n),np.ones(n),float(c['e_L36_1e9_Lsun'])/float(c['L36_1e9_Lsun']))
        ex=supp.get(g,{});sigf=float(ex['eFHI_Jy_kms'])/float(ex['FHI_Jy_kms']) if ex.get('eFHI_Jy_kms') and ex.get('flux_treatment','').startswith('same') else 0.
        fg=mc.positive_normal(mc.stream(j,4,n),np.ones(n),sigf)
        hmass,hr,hc=halo_arrays(mstar*fl*ds**2)
        frac=float(fr['interpolation_weight']);rlo,rhi=map(float,(fr['bracket_lo_kpc'],fr['bracket_hi_kpc']))
        gas_force=stars_force=0.
        pincs=[]
        for r,w0 in [(rlo,1-frac),(rhi,frac)]:
            x=rot[g,r]
            vg,vd,vb=map(float,[x[k] for k in ('vgas_kms','vdisk_unit_kms','vbul_unit_kms')])
            gas_force+=w0*vg*abs(vg)
            stars_force+=w0*(.5*vd*abs(vd)+.7*vb*abs(vb))
            pincs.append(get_i(g,r,inc,dist))
        vb2=ds*(fg*gas_force+fl*stars_force)
        assert (vb2>0).all()
        xx=hc*R*ds/hr; vdark2=halo.G*halo.DM_FRACTION*hmass*(np.log1p(xx)-xx/(1+xx))/(R*ds*(np.log1p(hc)-hc/(1+hc)))
        K=1
        for label,q,angles,passed in params:
            projection=0
            for ((iref,_),w0) in zip(pincs,(1-frac,frac)):
                projection+=w0*np.abs(np.sin(np.deg2rad(iref+angles-inc)))/math.sin(math.radians(iref))
            su,sf,local=calc(q,fl,fg,ds,vs,a,st,gas,w,u,table)
            pred=np.array([np.sqrt(vb2),su,sf,np.sqrt(vb2+vdark2),local])*projection
            # Direct integration at the nominal input prevents the grid interpolation from
            # moving a contour forecast appreciably. Global Q and mass are fixed once per boundary.
            _,sw=np.polynomial.legendre.leggauss(96);sn=np.polynomial.legendre.leggauss(96)[0];v=(sn+1)/2;sw=sw/2
            direct=fm.evaluate(a,st+gas,q0,1.,'isotropic',1.,sw,v,R*fm.KPC,mt)
            nominal=calc(nom,np.ones(K),np.ones(K),np.ones(K),vs,a,st,gas,w,u,table)[:,0]
            badkernel=max(badkernel,abs(nominal[1]-direct['Seff_div_sqrt2_kms']))
            central=np.array([float(fr['gr_kms']),float(fr.get('uniform_kms') or np.nan),direct['Seff_div_sqrt2_kms'],float(fr['halo_kms']),direct['equatorial_vc_kms']])
            if not fr.get('nominal_thickness'):central[:]=np.nan
            if source_label=='RHI template':zcal=max(zcal,abs(central[2]-float(fr['isotropic_surface_kms'])))
            assert badkernel<.04 and zcal<1e-6,(g,badkernel,zcal)
            yield dict(galaxy=g,contour=level,case=label,gas_data=source_label,n=n,shape_pass=passed,gas_i_lo_deg=pincs[0][0],gas_i_hi_deg=pincs[1][0],gas_i_sources=' | '.join(sorted(set(k for _,k in pincs))),fit_error=({'fixed_contour':0.,'local_p_proxy':float(pe or 0),'archive_p_proxy':float(e_archive or 0)})[label]),pred,central

def main(root,out,n,gridsize,preferred=True):
    from photometric_radii import MODELS
    base='preferred' if preferred else 'template'
    # Collected predictions stay separate from quantities computed using observed amplitudes.
    packed=[];stored={}
    for info,x,central in data_generator(root,out,n,gridsize,preferred):
        key=(info['galaxy'],info['contour'],info['case'])
        stored[key]=x
        vals=np.quantile(x,[.025,.16,.5,.84,.975],axis=1)
        for m,k in enumerate(MODELS):
            packed.append(dict(**info,model=k,central=central[m],p025=vals[0,m],p16=vals[1,m],median=vals[2,m],p84=vals[3,m],p975=vals[4,m]))
    ff=out/('uncertainty_forecasts_'+base+'.csv');write(ff,packed)
    h=freeze(ff);(out/('uncertainty_forecasts_'+base+'.sha256')).write_text(h+'\n')
    keys={x['galaxy']:j+1 for j,x in enumerate(read(root/'forty_sample/sample40.csv'))}
    pub={x['galaxy']:int(x['displayed_8e']) for x in read(root/'forty_sample/publication_overlap.csv')}
    tar={(x['galaxy'],x['contour']):x for x in read(out/'scores.csv')}
    forecasts=collections.defaultdict(dict)
    for x in packed:forecasts[x['galaxy'],x['contour'],x['case']][x['model']]=x
    stats=[];every=[];boot=[]
    for lev in ('25.5','26.5'):
        for branch in ('fixed_contour','local_p_proxy','archive_p_proxy'):
            contributors=[g for g in keys if (g,lev,branch) in stored]
            for category in ['matched','common_levels','displayed','outside_draft']:
                nms=[g for g in contributors if category=='matched' or category=='common_levels' and all((g,k,branch) in stored for k in ('25.5','26.5')) or category=='displayed' and pub[g] or category=='outside_draft' and not pub[g]]
                if not nms:continue
                for query in ('native',lev):
                    xx=np.stack([stored[g,query,branch] for g in nms]); obs=np.array([float(tar[g,query]['observed_interp_kms']) for g in nms]); err=np.array([float(tar[g,query]['error_if_bins_shared_kms']) for g in nms])
                    ae=100*np.abs(np.median(xx,axis=-1)/obs[:,None]-1)
                    ae0=np.array([[100*abs(forecasts[g,query,branch][k]['central']/o-1) for k in MODELS] for g,o in zip(nms,obs)])
                    z=np.array([mc.stream(keys[g],10,n).standard_normal(n) for g in nms])*err[:,None]
                    for mid,k in enumerate(MODELS):
                        q=np.quantile(xx[:,mid,:]+z,[.025,.16,.84,.975],axis=1)
                        stats.append(dict(selection_contour=lev,scored_contour=query,case=branch,subset=category,n=len(nms),model=k,median_ape=float(np.median(ae[:,mid])),nominal_median_ape=float(np.median(ae0[:,mid])),combined_95=int(sum((q[0]<=obs)&(obs<=q[3]))),combined_68=int(sum((q[1]<=obs)&(obs<=q[2])))))
                        if category=='matched' and query==lev:
                            for i,g in enumerate(nms):
                                every.append(dict(**forecasts[g,query,branch][k],observed_kms=obs[i],ape=ae[i,mid],combined_lo95=q[0,i],combined_hi95=q[3,i]))
                    rng=np.random.default_rng(202611181650);ids=rng.integers(len(nms),size=(24000,len(nms)))
                    gap=np.median(ae[ids,2],axis=1)-np.median(ae[ids,3],axis=1)
                    boot.append(dict(selection_contour=lev,scored_contour=query,case=branch,subset=category,n=len(nms),gap_set_minus_halo=np.median(ae[:,2])-np.median(ae[:,3]),lo=np.quantile(gap,.025),hi=np.quantile(gap,.975),set_better=int(sum(ae[:,2]<ae[:,3]))))
    write(out/('uncertainty_scores_'+base+'.csv'),every);write(out/('uncertainty_summary_'+base+'.csv'),stats);write(out/('uncertainty_pairs_'+base+'.csv'),boot)
    assert freeze(ff)==h
    return h
if __name__=='__main__':
    ps=argparse.ArgumentParser();ps.add_argument('--work',type=Path,default=W);ps.add_argument('--out',type=Path,default=D);ps.add_argument('--draws',type=int,default=32768);ps.add_argument('--grid',type=int,default=121);ps.add_argument('--template-only',action='store_true')
    a=ps.parse_args();print(main(a.work,a.out,a.draws,a.grid,not a.template_only))
