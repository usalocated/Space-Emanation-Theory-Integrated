"""Reintegrate measured stellar and H I shells at each tested stellar boundary."""
from collections import defaultdict
import numpy as np
from photometric_radii import fm, read
import things_field
import iorio_profiles


class GasProfiles:
    def __init__(self, root):
        self.annuli = defaultdict(list)
        for folder, filename in (
            ('uncertainty_gas', 'observed_gas_annuli.csv'),
            ('consensus_whisp', 'observed_gas_annuli.csv'),
            ('consensus_uma', 'observed_gas_annuli.csv'),
            ('consensus_extra', 'accepted_annuli.csv'),
            ('consensus_legacy', 'accepted_annuli.csv'),
        ):
            path = root / folder / filename
            if path.exists():
                for record in read(path):
                    if folder == 'uncertainty_gas' and record['radial_assignment'] != 'luminous_contour':
                        continue
                    self.annuli[record['galaxy']].append(record)
        self.iorio = defaultdict(list)
        for row in read(root / 'uncertainty_speeds/iorio_gas_rings.csv'):
            self.iorio[row['galaxy']].append([float(row[k]) for k in ('r_arcsec', 'HI_Msun_per_pc2', 'e_HI_Msun_per_pc2')])
        self.hua = defaultdict(list)
        for row in read(root / 'uncertainty_speeds/hua_figure1_data.csv'):
            if row['kind'] == 'surface_density':
                self.hua[row['galaxy']].append([float(row[k]) for k in ('kpc', 'value')])

    def shells(self, source, label, dens, radius, masses):
        name = source['galaxy']
        gas_fraction = masses[2] / masses.sum()
        if label == 'Iorio':
            data = np.array(self.iorio[name])
            spec = dict(source, Rb_kpc=radius, Rlast_kpc=radius)
            return iorio_profiles.measured_templates(dens, data, spec, 'half_ring')[:3]
        if label == 'Hua':
            radii, disk, bulge = dens.T
            rg, density = np.array(self.hua[name]).T
            a, da = fm.grid_weights(np.unique(np.r_[radii, rg, 0., radius]), 12)
            components = []
            for (sample_r, surface), mass in zip(((radii, disk), (radii, bulge), (rg, density)), masses):
                light = a * da * np.interp(a, sample_r, surface, right=0.)
                components.append(light * (mass / masses.sum() / light.sum()) if mass > 0 else np.zeros_like(a))
            return a / radius, components[0] + components[1], components[2]
        a, stars, gas = fm.shell_mass(dens, radius, radius, float(source['RHI_1Msun_per_pc2_kpc']), *masses, 12)
        if label == 'RHI template':
            return a, stars, gas
        records = self.annuli[name]
        assert records, (name, label)
        factor = float(source['Rb_kpc']) / radius
        scaled = [dict(rec, rlo_ratio=float(rec['rlo_ratio'])*factor, rhi_ratio=float(rec['rhi_ratio'])*factor) for rec in records]
        hits, weights = things_field.observed_shells(scaled, 1., 12)
        return np.r_[a, hits], np.r_[stars, np.zeros_like(hits)], np.r_[np.zeros_like(a), gas_fraction*weights]
