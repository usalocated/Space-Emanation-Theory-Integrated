"""Census of published S4G infrared outlines and SPARC radial coverage, without speed values."""
import csv
import json
import hashlib
import random
import math
from pathlib import Path
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
WORK = HERE.parent

def index(path, key):
    with path.open() as stream:
        rows = list(csv.DictReader(stream))
    data = {row[key]: row for row in rows}
    assert len(data) == len(rows)
    return data

def write_table(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0], lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)

def census():
    prior = index(WORK / 'forty_sample/sampling_frame.csv', 'galaxy')
    original = index(WORK / 'forty_sample/sample40.csv', 'galaxy')
    identities = index(WORK / 'forty_sample/geometry_status.csv', 'galaxy')
    s4g = index(WORK / 'shape_geometry/s4g_catalog_excerpt.csv', 'object')
    assert len(s4g) == 2352
    assert len(prior) == 175 and len(original) == 40
    assert set(original) == {g for g, row in prior.items() if row['selected_rank']}
    # Only select SPARC galaxy identifiers and distances. The measured speeds in the
    # catalog are outside these byte fields and are never parsed.
    catalog = (WORK / 'forty_sample/raw/SPARC_Lelli2016c.mrt').read_text()
    distances = {line.split(None, 3)[0]: float(line.split(None, 3)[2])
                 for line in catalog.rsplit('-' * 80, 1)[1].strip('\n').splitlines()}
    assert set(distances) == set(prior) == set(identities)
    rowset = []
    with ZipFile(WORK / 'forty_sample/raw/Rotmod_LTG.zip') as rotation:
        for galaxy in sorted(prior):
            item = prior[galaxy]
            spitzer = identities[galaxy]['S4G_name']
            obj = s4g.get(spitzer)
            angle = float(obj['sma1_25p5']) if obj and obj['sma1_25p5'] else None
            ratio = 1 - float(obj['ellip1_25p5']) if obj and obj['ellip1_25p5'] else None
            has_outline = angle is not None and ratio is not None
            # The first, radius-only column suffices for checking coverage. Do not
            # parse any kinematic amplitude while forming this frame.
            radii = [float(line.split(None, 1)[0])
                     for line in rotation.read(galaxy+'_rotmod.dat').decode().splitlines()
                     if line.strip() and not line.lstrip().startswith('#')]
            assert all(left < right for left, right in zip(radii, radii[1:]))
            distance = distances[galaxy]
            inc_deg = float(item['inclination_deg'])
            inc = math.radians(inc_deg)
            radius = angle * math.pi / 648000 * 1000 * distance if angle is not None else None
            q2 = ((ratio ** 2 - math.cos(inc) ** 2) / math.sin(inc) ** 2
                  if ratio is not None else None)
            supported = radii[0] <= radius <= radii[-1] if radius is not None else None
            physical = 0 < ratio <= 1 and 0 <= q2 <= 1 if q2 is not None else None
            prior_gate = item['catalog_gate'] == 'eligible_before_photometry'
            qi_gate = int(item['quality']) <= 2 and inc_deg >= 30
            rowset.append(dict(galaxy=galaxy, original40=int(galaxy in original),
                displayed_8e=item['displayed_8e'],
                original_catalog_gate=int(prior_gate), has_catalog_vflat=item['has_catalog_vflat'],
                sp_quality=item['quality'], inclination_deg=inc_deg, distance_mpc=distance,
                quality_incl_gate=int(qi_gate), original_native_frame=int(item['eligible_geometry']=='1'),
                s4g_name=spitzer if obj else '', has_s4g_row=int(bool(obj)),
                has_outline=int(has_outline), a25_arcsec=angle, p25=ratio,
                frame_original_gate_25=int(prior_gate and has_outline),
                frame_quality_incl_25=int(qi_gate and has_outline),
                pa25_deg=float(obj['pa1_25p5']) if obj and obj['pa1_25p5'] else None,
                s4g_ra_deg=obj['ra'] if obj else None,s4g_dec_deg=obj['dec'] if obj else None,
                radius_kpc=radius,min_kinematic_radius_kpc=radii[0],max_kinematic_radius_kpc=radii[-1],
                radial_support=int(supported) if supported is not None else None,
                q_squared=q2,physical_oblate=int(physical) if physical is not None else None,
                scoreable_geometry=int(bool(has_outline and supported and physical))))
    return rowset

if __name__ == '__main__':
    rows = census()
    write_table(HERE/'frame.csv', rows)
    disjoint = [r for r in rows if not r['original40']]
    counts = {}
    for label, sample in [
        ('all_disjoint', disjoint),
        ('original_native_gate', [r for r in disjoint if r['original_native_frame']]),
        ('original_catalog_gate', [r for r in disjoint if r['original_catalog_gate']]),
        ('quality_inclination_gate', [r for r in disjoint if r['quality_incl_gate']])]:
        counts[label] = dict(galaxies=len(sample),irsa_row=sum(r['has_s4g_row'] for r in sample),
            contour=sum(r['has_outline'] for r in sample),
            physical=sum(r['physical_oblate']==1 for r in sample if r['has_outline']),
            radial_support=sum(r['radial_support']==1 for r in sample if r['has_outline']),
            physical_and_within_support=sum(r['scoreable_geometry'] for r in sample))
    (HERE/'counts.json').write_text(json.dumps(counts, indent=2)+'\n')
    sets = {}
    for label, flag in [('historical', 'original_catalog_gate'), ('infrared', 'frame_quality_incl_25')]:
        pool = sorted((r for r in disjoint if r[flag]), key=lambda r:r['galaxy'].encode('ascii'))
        assert len(pool) == {'historical':83,'infrared':57}[label]
        write_table(HERE/(label+'_pool.csv'),pool)
        draw = random.Random(20261119).sample(pool, 40)
        sets[label] = {r['galaxy'] for r in draw}
        write_table(HERE/(label+'_draw.csv'),
                    [dict(draw_rank=rank, **row) for rank,row in enumerate(draw,1)])
    included = [r for r in disjoint if r['galaxy'] in sets['historical'] or r['frame_quality_incl_25']]
    write_table(HERE/'forecast_inputs.csv', [dict(in_historical_draw=int(r['galaxy'] in sets['historical']),
        in_infrared_draw=int(r['galaxy'] in sets['infrared']),
        in_infrared_census=r['frame_quality_incl_25'], **r) for r in included])
    manifest = {}
    paths = [HERE / name for name in ['build_frame.py','frame.csv','counts.json','historical_pool.csv','historical_draw.csv','infrared_pool.csv','infrared_draw.csv','forecast_inputs.csv']]
    paths += [WORK/'shape_geometry/s4g_catalog_excerpt.csv', WORK/'forty_sample/geometry_status.csv',
              WORK/'forty_sample/sample40.csv',WORK/'forty_sample/sampling_frame.csv',
              WORK/'forty_sample/raw/SPARC_Lelli2016c.mrt',WORK/'forty_sample/raw/Rotmod_LTG.zip']
    for path in paths:
        manifest[str(path.relative_to(WORK))] = hashlib.sha256(path.read_bytes()).hexdigest()
    (HERE/'freeze.json').write_text(json.dumps(dict(seed=20261119,algorithm='independent CPython random.Random(seed).sample(pool,40) on ASCII-sorted SPARC IDs',hashes=manifest,overlap=len(sets['historical'] & sets['infrared'])),indent=2)+'\n')
    print(counts)
    print('draw overlap',len(sets['historical'] & sets['infrared']))
    for label in sets:
        sample = [r for r in disjoint if r['galaxy'] in sets[label]]
        print(label,len(sample),sum(r['has_outline'] for r in sample),sum(r['scoreable_geometry'] for r in sample))

