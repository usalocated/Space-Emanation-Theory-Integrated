"""Algebraic controls for the galaxy/static-energy reconciliation, 2026-11-01.

No observational fitting. Shape examples are geometry controls, not new galaxy fits.
The retained source radius, physical surface, and vacuum evaluation radius remain distinct.
"""
from pathlib import Path
import sys, json, math
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "outputs/set-invariant-library/vendor"))
import sympy as sp

checks = {}
eta, lam, g, k, gamma = sp.symbols("eta lambda g k gamma", positive=True)
Csim = sp.diag(1, 1, eta**2)/(eta*lam)
def local_gain(C, direction):
    n = sp.Matrix(direction)
    return sp.simplify(1/(sp.sqrt(C.det())*sp.sqrt((n.T*C.inv()*n)[0])))
checks["similar_C_equatorial_local_gain"] = sp.simplify(local_gain(Csim, [1,0,0])-lam)==0
checks["similar_C_axial_local_gain"] = sp.simplify(local_gain(Csim, [0,0,1])-eta*lam)==0
checks["isotropic_C_local_gain"] = sp.simplify(local_gain((g/lam)*sp.eye(3), [1,0,0])-lam/g)==0
checks["scalar_C_compensation"] = sp.simplify(gamma*local_gain(k*sp.eye(3), [1,0,0])-gamma/k)==0

# Direction independence of n.C^{-1}.n forces C scalar in its orthonormal eigenbasis.
c1,c2,c3 = sp.symbols("c1 c2 c3", positive=True)
Cd=sp.diag(c1,c2,c3)
checks["eigenaxis_gain1"] = sp.simplify(local_gain(Cd,[1,0,0])-1/sp.sqrt(c2*c3))==0
checks["eigenaxis_gain2"] = sp.simplify(local_gain(Cd,[0,1,0])-1/sp.sqrt(c1*c3))==0
checks["eigenaxis_gain3"] = sp.simplify(local_gain(Cd,[0,0,1])-1/sp.sqrt(c1*c2))==0

# Selected energy in clock/ruler logarithms a=ln alpha and l=ln(psi chi).
a,l = sp.symbols("a l", real=True)
da,dl = sp.symbols("da dl", real=True)
psi=sp.exp((l-a)/2); chi=sp.exp((l+a)/2)
dpsi=sp.diff(psi,a)*da+sp.diff(psi,l)*dl
dchi=sp.diff(chi,a)*da+sp.diff(chi,l)*dl
checks["clock_ruler_energy_split"] = sp.simplify(-dpsi*dchi-sp.exp(l)*(da**2-dl**2)/4)==0

# Full general principal matrix can hide a channel from the sourced clock projection.
# This is a scope diagnostic only: no such extension is adopted as SET here.
A,B,D = sp.symbols("A B D", nonzero=True)
P=sp.Matrix([[A+B**2/D,B],[B,D]])
checks["schur_clock_projection"] = sp.simplify(P.inv()[0,0]-1/A)==0

# Exact constant-boundary exterior algebra from selected H0.
u,p,A0,G,c = sp.symbols("u p A0 G c", positive=True)
E=2*c**4*p*u/G
N=(1-u)/(1+u)
Ab=A0*(1+u)**4
pb=p*(1+u)**2
Sb2=c**2*(1-N**2)
Vrequired=Ab**2/(12*sp.pi*pb)
checks["capacity_volume_exact_source_match"] = sp.simplify(Ab**2*Sb2-24*sp.pi*G*(E/c**2)*Vrequired)==0
checks["capacity_volume_weak_limit"] = sp.simplify(Vrequired.subs(u,0)-A0**2/(12*sp.pi*p))==0
r,f = sp.symbols("r f", positive=True)
checks["sphere_capacity_volume"] = sp.simplify((A0**2/(12*sp.pi*p)).subs({A0:4*sp.pi*r*r,p:r})-4*sp.pi*r**3/3)==0
Vob = (f*sp.pi*r*r)**2/(12*sp.pi*(r/g))
checks["oblate_capacity_volume"] = sp.simplify(Vob/(4*sp.pi*r**3/3)-g*f*f/16)==0

# Exact potential upper bound in selected H0 under epsilon>=0, 0<=Sigma<=s epsilon,
# alpha<=1, psi>=1. U=G/c^2 integral dM_proper/|x-y| uses reference coordinate radius.
U,s=sp.symbols("U s", positive=True)
au=U/2; bu=(1+2*s)*U/2
bound=sp.factor((1-((1-bu)/(1+au))**2)/(2*U))
checks["weak_stress_potential_bound"] = sp.simplify(bound-(1+s)*(1-s*U/2)/(1+U/2)**2)==0
checks["zero_stress_bound"] = sp.simplify(bound.subs(s,0)-1/(1+U/2)**2)==0

def shape(et):
    if et==1:
        ff=4.; gg=1.; up=1.; uf=1.
    else:
        e=math.sqrt(1-et*et); theta=math.acos(et)
        ff=2*(1+et*et*math.atanh(e)/e)
        gg=theta/e
        up=0.75*((1-2*et*et)*theta/e**3+et/e**2)
        uf=1.5*(theta-et*e)/e**3
    ll=16/(ff*ff)
    return dict(eta=et,area_coefficient_f=ff,boundary_lambda=ll,
        isotropic_equipotential_shape_g=gg,old_over_isotropic_burden2=ll/gg,
        required_source_volume_over_equatorial_reference=gg/ll,
        geometric_oblate_volume_over_equatorial_reference=et,
        local_G_equator_for_similar_C=ll,local_G_axis_for_similar_C=et*ll,
        local_G_for_isotropic_C=ll/gg,
        uniform_bulk_edge_potential_in_GM_over_a=up,
        uniform_bulk_edge_v2_in_GM_over_a=uf)

rows=[shape(et) for et in [1,.9,.75,.5,.25,.1,.01]]
speed_rows=[]
csi=299792458.
for v in [100,200,300,500]:
    ss=(v*1000/csi)**2
    speed_rows.append(dict(v_km_s=v,stress_ratio_bound=ss,
        potential_enhancement_upper_fraction=ss,
        enhancement_upper_percent=100*ss))

out=dict(checks=checks,all_passed=all(checks.values()),shape_controls=rows,
    nonrelativistic_stress_controls=speed_rows,
    notes=["No data fits or revised predictions were performed.",
           "The conformal selected energy is assumed valid across the considered static response domain.",
           "Uniform oblate bulk and equipotential shell are distinct source arrangements.",
           "The exact exterior compatibility does not establish a full nonspherical material-support existence theorem."])
Path(__file__).with_name("galaxy-source-universality-checks.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
