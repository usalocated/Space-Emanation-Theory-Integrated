"""Exact algebraic checks of the selected-current area deformation bridge."""
import sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'set-invariant-library'/'vendor'))
import sympy as s
OUT=Path(__file__).resolve().parent
checks={}
def zero(name,v):
    v=s.simplify(v)
    assert v==0,(name,v)
    checks[name]=str(v)
p,E,G,c,V=s.symbols('p E G c V',positive=True)
alpha=1-G*E/(c**4*p)
S=s.sqrt(c**2*(1-alpha**2))
Q=s.sqrt(24*s.pi*G*E*V/c**2)
AQ=Q/S
zero('source_calibrated_area',AQ**2-24*s.pi*p*V/(1+alpha))
zero('fixed_E_burden_shape_derivative',p*s.diff(s.log(S),p)+alpha/(1+alpha))
zero('fixed_EV_area_shape_derivative',p*s.diff(s.log(AQ),p)-alpha/(1+alpha))
zero('energy_burden_derivative',E*s.diff(s.log(S),E)-alpha/(1+alpha))
zero('energy_area_derivative',E*s.diff(s.log(AQ),E)-(1-alpha)/(2*(1+alpha)))
zero('volume_area_derivative',V*s.diff(s.log(AQ),V)-s.Rational(1,2))
R,rs=s.symbols('R rs',positive=True)
a=s.sqrt(1-rs/R)
pq=R*(1+a)/2
zero('selected_sphere_capacity_derivative',R*s.diff(pq,R)/pq-(1+a)/(2*a))
zero('selected_sphere_Hadamard',s.diff(pq,R)-pq**2/(a*R**2))
zero('selected_sphere_burden_slope',-a/(1+a)*R*s.diff(pq,R)/pq+s.Rational(1,2))
zero('selected_sphere_source_area',24*s.pi*pq*(4*s.pi*R**3/3)/(1+a)-(4*s.pi*R**2)**2)
zero('fixed_source_volume_area',24*s.pi*pq*V/(1+a)-12*s.pi*V*R)
# For delta q_ij=2 epsilon q_ij in three spatial dimensions, the metric
# variation in the Dirichlet capacity is epsilon times its integrand.
eps,g2=s.symbols('eps g2')
zero('uniform_metric_scale',2*eps*(s.Rational(3,2)*g2-g2)-eps*g2)
# The source area and burden derivatives reconstruct the full source law.
dE,dp,dV=s.symbols('dE dp dV')
dlogS=alpha/(1+alpha)*(dE/E-dp/p)
dlogA=dV/(2*V)+(1-alpha)/(2*(1+alpha))*dE/E+alpha/(1+alpha)*dp/p
zero('full_energy_area_differential',dlogS+dlogA-dE/(2*E)-dV/(2*V))
# Pure coordinate relabelling must cancel between the physical-metric
# and moving-boundary contributions. First check the stress divergence.
x,y,z=s.symbols('x y z',real=True)
coords=(x,y,z)
phi=s.Function('phi')(*coords)
grad=s.Matrix([s.diff(phi,t) for t in coords])
lap=sum(s.diff(phi,t,2) for t in coords)
stress=(grad.dot(grad)/2)*s.eye(3)-grad*grad.T
for j in range(3):
    zero('Dirichlet_stress_divergence_'+str(j),
         sum(s.diff(stress[i,j],coords[i]) for i in range(3))+lap*grad[j])
# Euclidean sphere phi=R/r, xi=xi0 R²/r². The metric pullback and
# opposite coordinate boundary displacement describe the same sphere.
r=s.symbols('r',positive=True)
xi0=s.symbols('xi0',real=True)
xi=xi0*R**2/r**2
bulk=4*s.pi*R**2*s.integrate(-s.diff(xi,r)/r**2+2*xi/r**3,(r,R,s.oo))
boundary=-4*s.pi*xi0
zero('pure_radial_relabelling_cancels',bulk+boundary)
record={'checks':checks,'scope':'Actual static selected vacuum, uniform boundary lapse; actual spatial metric variation retained.'}
(OUT/'field-area-deformation-checks.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'output':str(OUT/'field-area-deformation-checks.json')},indent=2))
