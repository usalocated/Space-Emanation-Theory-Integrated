"""Source/current/capacity area bridge, with metric capacity kept distinct."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'outputs/set-invariant-library/vendor'))
import sympy as s
G,c,p,u,V,A0,h=s.symbols('G c p u V A0 h',positive=True)
alpha=(1-u)/(1+u)
E=2*c**4*p*u/G
S2=c*c*(1-alpha**2)
Q2=24*s.pi*G*E*V/c**2
pq=p*(1+u)
presp=p*(1+u)**2
A=A0*(1+u)**4
phi=(1+u)*h/(1+u*h)
checks={}
checks['q_harmonic_flux_coefficient']=s.simplify((1+u*h)**2*s.diff(phi,h)-(1+u))==0
checks['q_harmonic_unit_boundary']=s.simplify(phi.subs(h,1)-1)==0
checks['q_harmonic_zero_infinity']=phi.subs(h,0)==0
checks['current_energy_reading']=s.simplify(c**4*pq*(1-alpha)/G-E)==0
checks['response_length_dictionary']=s.simplify(presp-2*pq/(1+alpha))==0
checks['burden_from_complete_energy']=s.simplify(S2-G*E*(1+alpha)/(c*c*pq))==0
checks['area_bridge_general']=s.simplify(Q2/S2-24*s.pi*pq*V/(1+alpha))==0
checks['area_bridge_response_length']=s.simplify(Q2/S2-12*s.pi*presp*V)==0
Vneeded=A*A/(12*s.pi*presp)
checks['same_actual_area_and_source_law']=s.simplify(Q2.subs(V,Vneeded)-A*A*S2)==0
# Spherical control: p is the reference-radius capacity, physical R=p(1+u)^2.
R=presp
Asphere=4*s.pi*R*R
Vsphere=4*s.pi*R**3/3
checks['sphere_volume_at_all_loads']=s.simplify((24*s.pi*pq*Vsphere/(1+alpha))-Asphere**2)==0
checks['horizon_q_capacity_is_half_areal_radius']=s.simplify((pq-R/2).subs(u,1))==0
checks['horizon_burden']=s.simplify(S2.subs(u,1)-c*c)==0
# Nonconstant boundary: constant-t reduction of the harmonic-measure identity.
t,Ab,pqb=s.symbols('t Ab pqb',positive=True)
Vnonuniform_constant=(Ab*s.sqrt(t*(2-t)))**2/(24*s.pi*pqb*t)
checks['nonuniform_constant_boundary_reduction']=s.simplify(Vnonuniform_constant-Ab*Ab*(2-t)/(24*s.pi*pqb))==0
out=dict(checks={k:bool(v) for k,v in checks.items()},all_passed=all(checks.values()),
    identity='A_Q^2 = 24*pi*p_q*Vref/(1+alpha_boundary)',
    scope='General identity uses the static vacuum work-current, common-energy flux and capacity relation on an equipotential boundary. Explicit p_q=(1+u)*p uses the selected conformal two-response vacuum family, not a generic full nonspherical canonical solution.')
Path(__file__).with_name('source-area-current-bridge-checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
