"""Exact source/area/capacity and retained-probe consequences; no fit."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'set-invariant-library'/'vendor'))
import sympy as s
OUT=Path(__file__).resolve().parent
checks={}
def zero(name,value):
    value=s.simplify(value)
    assert value==0,(name,value)
    checks[name]=str(value)
G,c,E,V,A,m,R,f,rho=s.symbols('G c E V A m R f rho',positive=True)
Q=s.sqrt(24*s.pi*G*E*V/c**2)
S=Q/A
Ecap=c**4*A**2/(24*s.pi*G*V)
u=S**2/c**2
alpha=s.sqrt(1-u)
zero('source_energy_capacity_fraction',u-E/Ecap)
zero('fixed_energy_volume_area_derivative',A*s.diff(S,A)+S)
zero('clock_area_derivative',A*s.diff(alpha,A)-u/alpha)
zero('clock_log_area_derivative',A*s.diff(alpha,A)/alpha-u/(1-u))
zero('normalized_source_area_derivative',A*s.diff(s.log(Q/alpha),A)+u/(1-u))
Kescape=m*c**2*(1/alpha-1)
zero('retained_probe_escape_area_work',A*s.diff(Kescape,A)+m*c**2*u/alpha**3)
area=f*s.pi*R**2
volume=4*s.pi*R**3/3
zero('equatorial_shape_capacity',u.subs({A:area,V:volume})-32*G*E/(f**2*c**4*R))
zero('equatorial_shape_capacity_energy',Ecap.subs({A:area,V:volume})-f**2*c**4*R/(32*G))
zero('density_source_volume_clock',(V/Q).subs(E,rho*c**2*V)-1/s.sqrt(24*s.pi*G*rho))
zero('density_area_speed',S.subs(E,rho*c**2*V)-s.sqrt(24*s.pi*G*rho)*V/A)

# Log-differential source law; no dynamical conservation is inserted.
dE,dV,dA=s.symbols('dE dV dA')
dS=s.diff(S,E)*dE+s.diff(S,V)*dV+s.diff(S,A)*dA
zero('general_area_source_differential',dS/S-dE/(2*E)-dV/(2*V)+dA/A)

# Formal source-readout examples, not solved galaxies or horizons.
rows=[]
for u0 in [.001,.05,.2]:
    for ratio in [1,.8,.5]:
        unew=u0/ratio**2
        rows.append({'initial_occupancy':u0,'area_ratio':ratio,
          'S_ratio':1/ratio,'final_occupancy':unew,
          'alpha_initial':(1-u0)**.5,
          'alpha_final':(1-unew)**.5 if unew<1 else None,
          'source_energy_ratio':1.0,
          'timelike_held_reading':unew<1})
record={'checks':checks,'examples':rows,'scope':[
 'Fixed source energy means complete energy; fixed baryonic inventory does not alone imply it.',
 'Clock and escape formulas require the effective S reading to equal the actual local S.',
 'Energy conservation constrains simultaneous field/source changes, not the geometry-to-area correspondence by itself.',
 'The capacity bound is algebraic admissibility, not a derived black-hole or cosmological horizon.',
 'The proper escape kinetic energy uses the already retained common probe Hamiltonian.'
]}
(OUT/'area-capacity-probe-checks.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'output':str(OUT/'area-capacity-probe-checks.json')},indent=2))
