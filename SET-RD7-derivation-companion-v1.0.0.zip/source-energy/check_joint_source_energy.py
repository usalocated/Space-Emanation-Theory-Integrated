"""Exact source-energy residual audit for both retained applications."""
import sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'set-invariant-library'/'vendor'))
import sympy as s
OUT=Path(__file__).resolve().parent
checks={}
def zero(name,v):
    v=s.simplify(v)
    assert v==0,(name,v)
    checks[name]=str(v)
c,G,V,Q,flux,Es,A,al,p,H,Eb,ab,El=s.symbols('c G V Q flux Es A al p H Eb ab El',positive=True)
def EQ(q):return c**2*q**2/(24*s.pi*G*V)
zero('actual_static_boundary_energy_ratio',EQ(Q)/(c**2*flux/(4*s.pi*G))-Q**2/(6*V*flux))
Sb2=G*Es*(1+al)/(c**2*p)
AQ2=24*s.pi*p*V/(1+al)
zero('field_source_area',24*s.pi*G*Es*V/c**2/Sb2-AQ2)
zero('image_energy_residual',EQ(A*s.sqrt(Sb2))/Es-1-(A**2/AQ2-1))
Qb=s.sqrt(24*s.pi*G*Eb*V/c**2)
zero('source_clock_assigned_energy',EQ(Qb/al)-Eb/al**2)
Eexp=3*c**2*V*H**2/(8*s.pi*G)
zero('rate_volume_energy',EQ(3*H*V)-Eexp)
zero('luminosity_common_energy_ratio',EQ(3*H*V)/EQ(Qb/al)-al**2*Eexp/Eb)
Qlocal=s.sqrt(24*s.pi*G*El*V/c**2)
Qref=ab*Qlocal;Eref=ab*El
zero('background_increment_source_relation',Qref**2-24*s.pi*G*ab*Eref*V/c**2)
zero('inverse_isolated_reading_not_canonical_transform',EQ(Qref)-ab*Eref)
record={'checks':checks,'scope':'Algebraic inverse-source readings; actual clock/domain correspondences must be earned separately.'}
(OUT/'joint-source-energy-checks.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'output':str(OUT/'joint-source-energy-checks.json')},indent=2))
