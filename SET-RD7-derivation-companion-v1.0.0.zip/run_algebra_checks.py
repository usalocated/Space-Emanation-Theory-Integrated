"""Run the small exact checks; preserves the original script contents."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
scripts=[
"source-area/check_area_capacity_probe.py",
"source-area/check_source_area_current_bridge.py",
"source-area/check_field_area_deformation.py",
"source-area/check_galaxy_source_universality.py",
"photon-frequency/check_frequency_energy.py",
"source-energy/check_joint_source_energy.py",
"selection/filled-sources/galaxies/check_weak_filled_source_rank.py",
]
for script in scripts:
 print(script,flush=True)
 subprocess.run([sys.executable,str(root/script)],check=True,timeout=180)
print("All algebra checks passed.")
