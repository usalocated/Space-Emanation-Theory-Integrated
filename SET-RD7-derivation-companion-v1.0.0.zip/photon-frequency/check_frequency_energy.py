"""Checks for photon frequency, reference/local energy, source-Q and work."""
from pathlib import Path
import sys,json
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE.parent/'set-invariant-library'/'vendor'))
import sympy as s
checks={}
def zero(name,expression):
    result=s.simplify(expression)
    assert result==0,(name,result)
    checks[name]=str(result)
c,alpha,b,P=s.symbols('c alpha b P',positive=True)
ar,at,br,bt,eta=s.symbols('alpha_r alpha_T b_r b_T eta',real=True)
# Independent radial Hamiltonian expansion, each momentum-sign branch.
for sign in (-1,1):
    rdot=sign*alpha*c/b
    pdot_over_p=-sign*c*(ar/b-alpha*br/b**2)
    localrate=pdot_over_p-bt/b-rdot*br/b
    zero('radial_energy_sign_'+str(sign),localrate+bt/b+sign*c*ar/b)
    refrate=localrate+at/alpha+rdot*ar/alpha
    zero('reference_energy_sign_'+str(sign),refrate-at/alpha+bt/b)
    zero('static_alpha_E_conserved_'+str(sign),refrate.subs({at:0,bt:0}))
# General diagonal physical spatial response, arbitrary momentum direction.
t=s.symbols('T',real=True)
a=[s.Function('a'+str(i))(t) for i in range(3)]
p=s.symbols('p0:3',real=True)
norm=s.sqrt(sum(p[i]**2/a[i]**2 for i in range(3)))
n=[p[i]/(a[i]**2*norm) for i in range(3)]
theta=sum(a[i]*s.diff(a[i],t)*n[i]**2 for i in range(3))
zero('general_diagonal_directional_energy',s.diff(norm,t)/norm+theta)
theta_volume=sum(s.diff(ai,t)/ai for ai in a)
shear_parallel=theta-theta_volume/3
volume=s.prod(a)
zero('anisotropic_source_photon_product',
     s.diff(s.log(norm**3*volume),t)+3*shear_parallel)
aa=s.Function('a')(t)
zero('homogeneous_direction_independent_rate',theta.subs({ai:aa for ai in a})-s.diff(aa,t)/aa)
# Temporal lapse only is a reference-time normalization change.
zero('uniform_temporal_lapse_local_energy',at/alpha-at/alpha)
Se,So=s.symbols('S_e S_o',positive=True)
ae=s.sqrt(1-Se**2/c**2);ao=s.sqrt(1-So**2/c**2)
Q0,Eg=s.symbols('Q0 E_gamma',positive=True)
zero('static_Qnormalized_redshift',(Q0/ae)/(Q0/ao)-ao/ae)
zero('static_Qnormalized_energy',(Eg/(Q0/alpha))-(alpha*Eg/Q0))
U,Ur=s.symbols('S_squared D_S_squared',real=True)
zero('capacity_work_current',c**2*s.diff(s.sqrt(1-U/c**2),U)*Ur+Ur/(2*s.sqrt(1-U/c**2)))
# Homogeneous source-energy identity and radiation work.
G,V0,Es,aq,ph=s.symbols('G V0 E_source a photon_constant',positive=True)
Qsq=24*s.pi*G*Es*V0*aq**3/c**2
Eg=ph/aq
zero('photon_source_product_scale',s.diff(Eg**3*Qsq/Es,aq))
zero('photon_source_product_Esource',s.diff(Eg**3*Qsq/Es,Es))
Es1,Es2,V1,V2=s.symbols('Es1 Es2 V1 V2',positive=True)
qs1=24*s.pi*G*Es1*V1/c**2;qs2=24*s.pi*G*Es2*V2/c**2
zero('endpoint_redshift_cubed',qs2*Es1/(qs1*Es2)-V2/V1)
VV,N,constant=s.symbols('V N constant',positive=True)
Er=N*constant*VV**(-s.Rational(1,3))
zero('radiation_work_pressure',s.diff(Er,VV)+Er/(3*VV))
record={'checks':checks,'scope':'Retained photon coupling, zero shift, explicitly specified observers/domains; no new cosmological solution or fit.'}
(BASE/'frequency-energy-checks.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'passed':len(checks),'output':str(BASE/'frequency-energy-checks.json')},indent=2))
