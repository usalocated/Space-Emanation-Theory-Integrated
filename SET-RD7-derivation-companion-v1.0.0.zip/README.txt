SET Integrated Rough Draft 7 — Derivation companion v1.0.0
Erik Echeverria | 1 November 2026

This archive supports the theoretical additions in RD7. It supplements the
unchanged SET-RD6-calculation-companion-v1.0.0.zip; it does not replace the
frozen galaxy and supernova inputs or their covariance accounting.

READING ORDER
1. The manuscript §3.3 and Appendix O supply the source-based field-energy
   proof. selection/published-proof retains the full earlier proof [47].
2. selection/filled-sources/galaxies/FIVE-CONTROL-NEGATIVE-DOMAIN-EXTENSION.txt
   is the full additional actual-source/rank argument referred to in O.8.
   Its neighboring files contain the source preparation, independent audit
   and numerical controls. Those controls are theoretical, not observations.
3. source-area/FIELD-DERIVED-AREA-DEFORMATION.txt gives the physical-ruler
   and boundary variation; LOCAL-SOURCE-UNIVERSALITY-AND-GALAXY-RESPONSE.txt
   gives the separate-C local calibration and nonuniform boundary reading.
4. photon-frequency/RESEARCH-NOTE.txt and source-energy/ explain how the
   same current and source readings enter measured photon frequency.
5. assembly/equation-correspondence.json maps old and inserted labels to
   final RD7 equation numbers; the change ledger records package preservation.

RUNTIME
Python 3; SymPy 1.14.0; NumPy and SciPy for the optional numerical controls.
Install these in your own Python environment. No network/data download is
used by the included checks. The original scripts retain historical vendor
fallbacks in sys.path; those paths are unnecessary when dependencies are
installed normally. Scripts write JSON beside themselves. Preserve the
supplied JSON if comparing a rerun with this record.

Run the exact algebra checks with:
  python run_algebra_checks.py
Optional actual-source numerical control (holds physical controls fixed):
  python selection/filled-sources/galaxies/check_five_control_candidate.py
Keep the neighboring host and candidate modules together for local imports.

SCOPE
The source theorem concerns the stated regular static two-response class,
source-law universality and admitted actual-source families. The attached
weak domain and the negative-ratio subwedges are stated precisely in the
proof; finite-load continuation has separate conditions. This archive does
not promote that theorem to arbitrary evolving or nonspherical matter.
The area/current/frequency identities do not silently replace the galaxy
image-area prescription or establish a new complete cosmological history.
The original luminosity calculations and empirical sample remain unchanged.

FILES
MANIFEST.json records every archived source file and its SHA256. The README,
runner and manifest themselves are package documentation. The numerical
baseline and both PDFs are available in the repository:
https://github.com/usalocated/Space-Emanation-Theory-Integrated
