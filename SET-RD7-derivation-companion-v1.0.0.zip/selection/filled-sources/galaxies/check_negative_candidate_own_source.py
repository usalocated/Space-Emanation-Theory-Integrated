"""Candidate-owned causal polytropic sources in the negative-response region.

G=c=K_eos=1, p=rho^2, epsilon=rho+p. The candidate is
H=H0+a min(n,0)^3 dI*dI, n=(psi+chi-2)/2, I=psi*chi.
It preserves proper local G exactly and agrees with H0 on n>=0.
No source-Q or energy-charge condition is used in the boundary-value solve.
"""
from pathlib import Path
import sys,json,math
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'outputs/set-capacity-continuation/vendor'))
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import root

H0=np.array([[0.,-1.],[-1.,0.]])
def geometry(u,coef):
    ps,ch=u; n=(ps+ch-2)/2; I=ps*ch; v=np.array([ch,ps]); X=np.array([ps,ch])
    h=coef*min(n,0.)**3; hp=3*coef*min(n,0.)**2 if n<0 else 0.
    H=H0+h*np.outer(v,v)
    Hi=H0-h/(1-2*h*I)*np.outer(X,X)
    Vp=np.array([0.,1.]); Vc=np.array([1.,0.])
    dHp=.5*hp*np.outer(v,v)+h*(np.outer(Vp,v)+np.outer(v,Vp))
    dHc=.5*hp*np.outer(v,v)+h*(np.outer(Vc,v)+np.outer(v,Vc))
    W=-.5*(ps-ch)*hp*np.outer(v,v)
    return H,Hi,dHp,dHc,W

def target_acc(u,v,src,coef):
    H,Hi,Hp,Hc,W=geometry(u,coef)
    conn=(v[0]*Hp+v[1]*Hc)@v-.5*np.array([v@Hp@v,v@Hc@v])
    return Hi@(src-conn),H,W

def trial(z,sigma,coef,rtol=2e-10,details=False):
    ps0,al0=z; ch0=ps0*al0
    if ps0<=0 or al0<=0: raise ValueError('positive operational responses')
    hc=1+2*sigma
    def density(u): return (hc*al0*u[0]/u[1]-1)/2
    def rhs(r,y):
        ps,ch=y[:2]; vel=y[2:4]; rho=max(density(y[:2]),0.); pr=rho*rho; eps=rho+pr
        src=2*math.pi*np.array([-ch*ps**4*(eps+6*pr),ps**5*eps])
        acc,H,W=target_acc(y[:2],vel,src,coef)
        return np.r_[vel,acc-2*vel/r,
                     4*math.pi*r*r*ch*ps**5*eps,
                     r*r*(vel@H@vel),.5*r*r*(vel@W@vel),
                     12*math.pi*r*r*ch*ps**5*pr]
    def edge(r,y): return density(y[:2])
    edge.terminal=True; edge.direction=-1
    r0=1e-6
    src0=2*math.pi*np.array([-ch0*ps0**4*(sigma+7*sigma*sigma),ps0**5*(sigma+sigma*sigma)])
    acc0=geometry([ps0,ch0],coef)[1]@src0
    y0=np.r_[np.array([ps0,ch0])+acc0*r0*r0/6,acc0*r0/3,np.zeros(4)]
    fluid=solve_ivp(rhs,[r0,10.],y0,events=edge,rtol=rtol,atol=rtol*1e-3,
                    max_step=.015,dense_output=details)
    if not fluid.t_events[0].size: raise ValueError('no finite fluid edge')
    re=fluid.t[-1]; ye=fluid.y[:,-1]; xi=1/re
    def vac(s,y):
        acc,H,W=target_acc(y[:2],y[2:4],np.zeros(2),coef)
        return np.r_[y[2:4],acc,-(y[2:4]@H@y[2:4]),-.5*(y[2:4]@W@y[2:4])]
    vv=solve_ivp(vac,[xi,0.],np.r_[ye[:2],-re*re*ye[2:4],0.,0.],
                 rtol=rtol,atol=rtol*1e-3,max_step=xi/100,dense_output=details)
    end=vv.y[:,-1]
    residual=end[:2]-1
    if not details:return residual
    E=ye[4]+ye[5]+end[4]; charge=end[2]-end[3]; ward=ye[6]+end[5]
    qread=re*ye[0]**2*(1-(ye[1]/ye[0])**2)/2
    samples=fluid.sol(np.linspace(r0,re,301)); nn=(samples[0]+samples[1]-2)/2
    return dict(central_density=sigma,candidate_coefficient=coef,central_psi=ps0,
      central_alpha=al0,minimum_n=float(np.min(nn)),coordinate_radius=re,
      physical_radius=re*ye[0]**2,maximum_sound_speed_squared=2*sigma/(1+2*sigma),
      material_energy=ye[4],field_energy=ye[5]+end[4],complete_energy=E,
      clock_charge=charge,charge_minus_energy=charge-E,ward_integral=ward,
      ward_identity_error=charge-E-ward,source_Q_reading=qread,source_Q_defect=qread-E,
      virial_error=ye[5]+end[4]-ye[7],boundary_residual=max(abs(residual)),rtol=rtol)

if __name__ == '__main__':
    rows=[]
    for sigma,coef in [(.01,0.),(.01,1e8),(.03,0.),(.03,1e6),(.05,0.),(.05,1e5)]:
        result=root(lambda z:trial(z,sigma,coef),[1+2*sigma,1-4*sigma],tol=1e-10)
        if not result.success and max(abs(result.fun))>1e-8:raise RuntimeError(result.message)
        row=trial(result.x,sigma,coef,details=True)
        rows.append(row)
        print(json.dumps(row),flush=True)
    # Refine the final rejected candidate without changing its source or equation.
    last=rows[-1]
    ans=root(lambda z:trial(z,.05,1e5,rtol=2e-12),
             [last['central_psi'],last['central_alpha']],tol=1e-11)
    refined=trial(ans.x,.05,1e5,rtol=2e-12,details=True)
    out=dict(sources=rows,refined_last_source=refined,
      refinement_charge_energy_gap_change=refined['charge_minus_energy']-last['charge_minus_energy'],
      note='Only asymptotic psi=chi=1 are solved. The candidate energy and Q defects are independent outputs, not fitted residuals.')
    Path(__file__).with_name('negative-candidate-own-source-checks.json').write_text(json.dumps(out,indent=2)+'\n')
