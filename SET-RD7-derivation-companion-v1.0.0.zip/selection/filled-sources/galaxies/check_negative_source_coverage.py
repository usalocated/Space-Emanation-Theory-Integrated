"""Negative-side source coverage and an exact residual-class exclusion.

The full arbitrary-H extension is NOT claimed here. Algebraic checks cover
a physical weak polytropic host, its small cavity-wall anchor, and a
local-G-preserving residual excluded by the complete-energy Ward identity.
"""
from pathlib import Path
import sys,json,math
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'outputs/set-invariant-library/vendor'))
sys.path.insert(0,str(ROOT/'outputs/set-capacity-continuation/vendor'))
import sympy as s
from scipy.integrate import quad
from scipy.special import sici

checks={}
x=s.symbols('x',positive=True)
f=s.sin(x)/x
J=(1+s.cos(x))*(x-s.sin(x))
checks['polytrope_integrated_normal_source']=s.simplify(s.diff(J,x)-(2*s.sin(x)**2-x*s.sin(x)))==0
checks['polytrope_outer_normal_flux_zero']=s.simplify(J.subs(x,s.pi))==0
checks['polytrope_regular_center_flux']=s.limit(J/x**2,x,0)==0
checks['polytrope_density_simple_surface']=s.simplify(s.diff(f,x).subs(x,s.pi)+1/s.pi)==0
checks['polytrope_density_lane_emden']=s.simplify(s.diff(x*x*s.diff(f,x),x)+x*x*f)==0

# A central particle wall supports an exterior pressure p_c. With reference
# cavity scale a and physical R=a z, choose rest mass M=m0 a^3 and ell=l0 a.
z,l0,pc=s.symbols('z l0 pc',positive=True)
w=l0**2/(1+l0**2)
m0=4*s.pi*pc*s.sqrt(1+l0*l0)/(l0*l0)
Pscaled=m0*l0*l0/(2*z*s.sqrt(z*z+l0*l0))
force=Pscaled-2*s.pi*pc*z**3
checks['cavity_wall_force_anchor']=s.simplify(force.subs(z,1))==0
checks['cavity_wall_nondegenerate_derivative']=s.simplify(s.diff(force,z).subs(z,1)+2*s.pi*pc*(5-w))==0
Uscaled=m0*s.sqrt(1+l0*l0)
checks['cavity_wall_positive_speed_ratio']=s.simplify((2*Pscaled.subs(z,1))/Uscaled-w)==0

# A whole residual family that leaves the local proper weak-source law exact.
psi,chi,a=s.symbols('psi chi a',positive=True)
I=psi*chi; n=(psi+chi-2)/2; ww=(psi-chi)/2
H0=s.Matrix([[0,-1],[-1,0]])
e=s.Matrix([-chi/psi,1]); dI=s.Matrix([chi,psi])
h=s.symbols('h',real=True)
HH=H0+h*dI*dI.T
checks['residual_clock_orthogonality']=(e.T*H0*dI)[0]==0
checks['residual_exact_localG']=s.simplify((e.T*HH.inv()*e)[0]-2*chi/psi)==0
checks['residual_nondegeneracy_determinant']=s.simplify(HH.det()-(-1+2*h*I))==0
Y=s.Matrix([-psi,chi]); DY=Y.jacobian([psi,chi])
Hneg=H0+a*n**3*dI*dI.T # formula on n<0; zero deformation on n>=0
LY=Hneg.applyfunc(lambda v:sum(Y[i]*s.diff(v,(psi,chi)[i]) for i in range(2)))+DY.T*Hneg+Hneg*DY
checks['negative_side_Ward_exact']=s.simplify(LY+3*a*ww*n*n*dI*dI.T)==s.zeros(2)
checks['negative_side_localG_exact']=s.simplify((e.T*Hneg.inv()*e)[0]-2*chi/psi)==0

# A homogeneous hydrostatic sphere provides a second independent weak control.
u=s.symbols('u',positive=True)
nsphere=-s.Rational(3,32)*u*u*(1-x*x)**2
checks['uniform_sphere_normal_ode']=s.simplify(s.diff(nsphere,x,2)+2*s.diff(nsphere,x)/x-s.Rational(3,8)*u*u*(3-5*x*x))==0
checks['uniform_sphere_normal_boundary']=nsphere.subs(x,1)==0 and s.diff(nsphere,x).subs(x,1)==0

# Polytrope n(x)/sigma^2 from the exact leading integral.
def ncoef(xx):
    return -quad(lambda t:(1+math.cos(t))*(t-math.sin(t))/(t*t) if t else 0,
                 xx,math.pi,epsabs=1e-12)[0]
_,Ci2pi=sici(2*math.pi)
center_closed=2+Ci2pi-0.5772156649015328606-math.log(2*math.pi)
checks['polytrope_center_integral']=abs(ncoef(0)-center_closed)<1e-12
rows=[dict(x=xx,n_over_sigma2=ncoef(xx)) for xx in [0,.25,.5,1,1.5,2,2.5,3,math.pi]]
out=dict(checks={key:bool(value) for key,value in checks.items()},all_passed=all(checks.values()),polytrope_profile=rows,
         polytrope_center_normal_coefficient=float(center_closed),
         wall_radius_jacobian='-2*pi*p_c*(5-w), p_c>0, 0<w<1',
         residual_exclusion='For h=a min(n,0)^3, a>0, LYH=-3 a w n^2 dI^2 on n<0; its complete Ward integral is strictly negative whenever w>0 and dI is nonzero there.',
         scope='Actual weak-host existence and regular continuation are stated in the companion note. No full arbitrary-H negative-domain selection theorem is claimed.')
Path(__file__).with_name('negative-source-coverage-checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
