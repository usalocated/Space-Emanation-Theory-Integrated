"""Unchanged five material controls under an actual negative-side candidate.

No source-Q, energy-charge equality or selected exterior charge is fitted.
Only asymptotic normalization, two shell forces and fluid particle inventory
are solved. This checks candidate-owned continuation, independently of the
algebraic theorem that excludes a candidate which fails source universality.
"""
from pathlib import Path
import sys,json,math,io,contextlib
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'outputs/set-capacity-continuation/vendor'))
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import root
from check_negative_candidate_own_source import geometry,target_acc
with contextlib.redirect_stdout(io.StringIO()):
    import check_filled_host_annular_rank as baseline

controls=baseline.controls.copy()

def particle(u,r,M,l2):
    ps,ch=u; al=ch/ps; R=r*ps*ps
    U=M*math.sqrt(1+l2/R**2); P=U*l2/(2*(R**2+l2))
    jump=np.array([al*(U+4*P)/(2*ps),-al*U/(2*ch)])
    return jump,al*P,al*U,2*P/U

def own(z,coef,rtol=3e-11,detail=False):
    ps,ch,r1,r2,rho2=np.exp(z)
    if not r1<r2:raise ValueError('shell ordering')
    u1=np.array([ps,ch]); p1,Pm1,Em1,w1=particle(u1,r1,*controls[:2])
    v1=geometry(u1,coef)[1]@p1; K1=p1@v1
    def vacuum(x,y):
        acc,H,W=target_acc(y[:2],y[2:4],np.zeros(2),coef)
        v=y[2:4]
        return np.r_[v,acc,-v@H@v,-.5*(v@W@v)]
    ann=solve_ivp(vacuum,[1/r1,1/r2],np.r_[u1,v1,0.,0.],
                  rtol=rtol,atol=rtol*1e-3,max_step=(1/r1-1/r2)/50)
    ya=ann.y[:,-1];u2=ya[:2];Hi2=geometry(u2,coef)[1]
    pin=geometry(u2,coef)[0]@ya[2:4]
    jump2,Pm2,Em2,w2=particle(u2,r2,*controls[2:4]);pout=pin+jump2
    Kin=pin@Hi2@pin;Kout=pout@Hi2@pout
    du2=-Hi2@pout/r2**2;al2=u2[1]/u2[0];R2=r2*u2[0]**2
    hconst=(1+2*rho2)*al2
    def density(u):return (hconst*u[0]/u[1]-1)/2
    def fluid(r,y):
        ps,ch=y[:2];v=y[2:4];rr=max(density(y[:2]),0.);pr=rr*rr;eps=rr+pr
        src=2*math.pi*np.array([-ch*ps**4*(eps+6*pr),ps**5*eps])
        acc,H,W=target_acc(y[:2],v,src,coef)
        return np.r_[v,acc-2*v/r,4*math.pi*r*r*ps**6*rr,
              4*math.pi*r*r*ch*ps**5*eps,r*r*(v@H@v),.5*r*r*(v@W@v)]
    def edge(r,y):return density(y[:2])
    edge.terminal=True;edge.direction=-1
    sol=solve_ivp(fluid,[r2,12.],np.r_[u2,du2,np.zeros(4)],events=edge,
                   rtol=rtol,atol=rtol*1e-3,max_step=.01)
    if not sol.t_events[0].size:raise ValueError('fluid free edge absent')
    re=sol.t[-1];ye=sol.y[:,-1]
    ext=solve_ivp(vacuum,[1/re,0.],np.r_[ye[:2],-re*re*ye[2:4],0.,0.],
                    rtol=rtol,atol=rtol*1e-3,max_step=1/re/70)
    end=ext.y[:,-1]
    f1=Pm1-K1/(2*r1)
    f2=Pm2-(Kout-Kin)/(2*r2)-2*math.pi*al2*rho2*rho2*R2**3
    res=np.r_[end[:2]-1,f1/baseline.s1['U'],f2/baseline.s2['U'],
                (ye[4]-controls[4])/controls[4]]
    if not detail:return res
    E=Em1+Em2+ya[4]+ye[5]+ye[6]+end[4]
    charge=end[2]-end[3];ward=ya[5]+ye[7]+end[5]
    return dict(coefficient=coef,z=z.tolist(),r1=r1,r2=r2,rho2=rho2,
       n_outer_wall=float((u2.sum()-2)/2),particle_speed_squared=[w1,w2],
       residual_max=float(max(abs(res))),fluid_inventory=ye[4],
       complete_energy=E,clock_charge=charge,charge_minus_energy=charge-E,
       ward_integral=ward,ward_identity_error=charge-E-ward,
       exterior_D=end[2]+end[3],rtol=rtol)

if __name__=='__main__':
    z=baseline.z.copy();rows=[]
    for coef in [0.,1e7,1e8]:
        ans=root(lambda zz:own(zz,coef),z,tol=2e-9)
        if max(abs(ans.fun))>3e-8:raise RuntimeError(ans.message)
        z=ans.x;row=own(z,coef,detail=True);rows.append(row)
        print(json.dumps(row),flush=True)
    ans=root(lambda zz:own(zz,1e8,rtol=8e-13),z,tol=5e-11)
    refined=own(ans.x,1e8,rtol=8e-13,detail=True)
    out=dict(material_controls=controls.tolist(),sources=rows,refined=refined,
       statement='Fixed positive particle controls and fluid inventory; Q, complete-energy equality and exterior D are independently checked outputs.')
    Path(__file__).with_name('five-control-candidate-checks.json').write_text(json.dumps(out,indent=2)+'\n')
