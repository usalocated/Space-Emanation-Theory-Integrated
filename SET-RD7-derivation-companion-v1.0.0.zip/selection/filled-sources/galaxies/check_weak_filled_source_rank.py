"""Analytic weak-rank anchors for the five-control negative-domain extension."""
from pathlib import Path
import sys,json,math
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'outputs/set-invariant-library/vendor'))
sys.path.insert(0,str(ROOT/'outputs/set-capacity-continuation/vendor'))
import sympy as s
from scipy.integrate import quad

checks={}
a,d,m1,m2,j2,K,k=s.symbols('a d m1 m2 j2 K k',positive=True)
F=m2*j2/(2*a*a)-m2*(2*m1+m2)/(4*a)-2*s.pi*K*a**3*d*d
jroot=a*(m1+m2/2)+4*s.pi*K*a**5*d*d/m2
checks['outer_force_root']=s.simplify(F.subs(j2,jroot))==0
checks['outer_force_radius_derivative']=s.simplify(s.diff(F,a).subs(j2,jroot)+m2*(2*m1+m2)/(4*a*a)+10*s.pi*K*a*a*d*d)==0
checks['outer_force_density_derivative']=s.simplify(s.diff(F,d)+4*s.pi*K*a**3*d)==0
x=s.symbols('x',positive=True)
Nd=2*K/k*(s.sin(x)-x*s.cos(x)+s.pi*(x*s.sin(x)+s.cos(x)))
Ar=(s.sin(x)**2-s.cos(x)**2)/x+s.sin(x)*s.cos(x)/x**2
Rsr=1-2*s.sin(x)*s.cos(x)/x+s.sin(x)**2/x**2
Na=2*K*(Rsr+s.pi*Ar)
checks['fluid_inventory_density_limit']=s.simplify(s.limit(Nd,x,0)-2*K*s.pi/k)==0
checks['fluid_inventory_radius_order']=s.limit(Na,x,0)==0
checks['fluid_inventory_radius_leading']=s.simplify(s.limit(Na/x,x,0)-8*K*s.pi/3)==0
frac=s.symbols('frac',positive=True)
mass=4*s.pi/k**3*(s.sin(k*a)-k*a*s.cos(k*a))
Fr=s.diff(F,a).subs(j2,jroot).subs({d:s.sin(k*a)/(k*a),m1:frac*mass,m2:(1-frac)*mass})
Fd=s.diff(F,d).subs({d:s.sin(k*a)/(k*a)})
det=s.simplify(Fr*Nd.subs(x,k*a)-Fd*Na.subs(x,k*a))
checks['fluid_force_inventory_determinant_leading']=s.simplify(s.limit(det/a**2,a,0)+20*s.pi**2*K*K/k)==0

# Full regular-host cut rank: a N_a < 2 d N_d follows from this positive difference.
Ndt=Nd*k/(2*K)
Nat=Na/(2*K)
Dcut=x*(s.pi-x)+s.sin(x)**2+s.pi*s.sin(x)*s.cos(x)
checks['all_cut_inventory_inequality_identity']=s.trigsimp(2*s.sin(x)*Ndt-x*x*Nat-Dcut)==0
y=s.symbols('y',real=True)
checks['all_cut_positive_difference_identity']=s.trigsimp(2*y*(y-s.sin(y)*s.cos(y))-(y*y-s.sin(y)**2)-(y-s.sin(y)*s.cos(y))**2-s.sin(y)**4)==0

# Global outside-rank sign proof, including its half-angle rationalization.
z=s.symbols('z',positive=True)
t=s.symbols('t',positive=True)
k0=2/s.pi
F=t*s.sin(t)+s.cos(t)+s.cos(2*t)
GG=(1+s.cos(t))*(t-s.sin(t))
L=t*(1+z*z)*(z-k0)+1-3*z*z+2*k0*z
rat=s.expand_trig(F-k0*GG).subs({s.sin(t):2*z/(1+z*z),s.cos(t):(1-z*z)/(1+z*z)})
checks['all_cut_outside_half_angle_identity']=s.factor(rat-2*L/(1+z*z)**2)==0
Lt=L.subs(t,2*s.atan(z))
checks['all_cut_outside_L_derivative']=s.simplify(s.diff(Lt,z)-(2*s.atan(z)*(3*z*z-2*k0*z+1)-4*z))==0
checks['all_cut_outside_L_at_one']=s.simplify(Lt.subs(z,1)-(s.pi-2)**2/s.pi)==0
Mt=-2*s.cos(x)/(x+s.sin(x))
checks['all_cut_outside_M_derivative']=s.trigsimp(s.diff(Mt,x)-2*(x*s.sin(x)+1+s.cos(x))/(x+s.sin(x))**2)==0

# H0 outer traction yields the seed phase-space rank.
ps,ch,xi,pc=s.symbols('psi chi xi p_chi',positive=True)
pp=-ch*pc/(ps+2*xi*pc)
checks['seed_phase_rank']=s.simplify(s.diff(pp,xi)-2*ch*pc*pc/(ps+2*xi*pc)**2)==0

# Exact general-H radial source Ward uses the matter potential W=-2pi alpha psi^6 p xi^-4.
# X acts on alpha trivially and psi^6 with weight6, while explicit xi weight is -4.
# On-shell C=X.p-xi K+2xi W therefore C'=1/2(L_XH-2H)(u',u').
# Verify the explicit cancellation with symbolic generic u,p,H derivative contraction.
Kv,contract,WW=s.symbols('K contraction W',real=True)
XW=6*WW; W_exp=-4*WW/xi
candidate=s.Rational(1,2)*contract-Kv+XW+2*WW+2*xi*W_exp
checks['general_fluid_dilation_cancellation']=s.simplify(candidate-(s.Rational(1,2)*contract-Kv))==0

N0=-.43765339305722417
rows=[]
for xx in [.5,.2,.1,.05,.02,.01,.005]:
    f=math.sin(xx)/xx
    N=f-f*f/2-quad(lambda t:(1-(math.sin(t)/t)**2)/t,xx,math.pi,epsabs=1e-12)[0]
    Nt=math.cos(xx)/xx*(1-f)+1/math.pi+quad(lambda t:math.sin(2*t)/t**3,xx,math.pi,epsabs=1e-12)[0]
    P=(1+f)*Nt-2*N*math.cos(xx)/xx
    rows.append(dict(x=xx,N=N,x_Ntheta=xx*Nt,x_scaled_outer_determinant=xx*P))
out=dict(checks={key:bool(value) for key,value in checks.items()},all_passed=all(checks.values()),
         outside_rank_controls=rows,exact_outer_limit_in_terms_of_N0=4-2*N0,
         scope='Weak rescaled own-source and outside-fluid rank anchors; source-domain, material-continuation and reconstruction premises are stated in FIVE-CONTROL-NEGATIVE-DOMAIN-EXTENSION.txt.')
Path(__file__).with_name('weak-filled-source-rank-checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
