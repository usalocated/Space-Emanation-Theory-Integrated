"""Actual five-control H0 source and outside-fluid reconstruction Jacobians.

Empty cavity -> particle shell r1 -> vacuum -> particle wall r2 ->
causal p=rho^2 fluid -> free surface -> vacuum infinity.
This is a finite source-map control, not a global arbitrary-H theorem.
"""
from pathlib import Path
import sys,json,math
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'outputs/set-capacity-continuation/vendor'))
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import root

H=np.array([[0.,-1.],[-1.,0.]])

def fluid_out(r2,u2,du2,rho2,rtol=5e-13,dense=False):
    alpha2=u2[1]/u2[0]; hconst=(1+2*rho2)*alpha2
    def rho(y):return (hconst*y[0]/y[1]-1)/2
    def rhs(r,y):
        ps,ch,dp,dc=y[:4]; rr=max(rho(y),0.); p=rr*rr; eps=rr+p
        return [dp,dc,-2*dp/r-2*math.pi*ps**5*eps,
                -2*dc/r+2*math.pi*ch*ps**4*(eps+6*p),
                4*math.pi*r*r*ps**6*rr]
    def edge(r,y):return rho(y)
    edge.terminal=True;edge.direction=-1
    sol=solve_ivp(rhs,[r2,12],np.r_[u2,du2,0.],events=edge,rtol=rtol,atol=rtol*1e-3,
                  max_step=.005,dense_output=dense)
    if not sol.t_events[0].size:raise ValueError('fluid edge absent')
    r=sol.t[-1]; y=sol.y[:,-1]; aa=-r*r*y[2:4]; bb=y[:2]+r*y[2:4]
    return dict(asymptotic=bb,charge=aa[0]-aa[1],D=aa.sum(),N=y[4],edge=r,sol=sol)

def central_star(z,sigma=.02,at=.2):
    ps,al=z; ch=ps*al; r0=1e-6
    acc=np.array([-2*math.pi*ps**5*(sigma+sigma*sigma),
                  2*math.pi*ch*ps**4*(sigma+7*sigma*sigma)])
    u=np.array([ps,ch])+acc*r0*r0/6;du=acc*r0/3
    out=fluid_out(r0,u,du,sigma,dense=True)
    y=out['sol'].sol(at); rr=((1+2*sigma)*al*y[0]/y[1]-1)/2
    out.update(u_cut=y[:2],du_cut=y[2:4],rho_cut=rr)
    return out

base=root(lambda z:central_star(z)['asymptotic']-1,[1.04,.925],tol=1e-10)
star=central_star(base.x);r2=.2;r1=.1
u2=star['u_cut'];du2=star['du_cut'];rho2=star['rho_cut'];xi2=1/r2
pout=H@(-r2*r2*du2)
pchi=.2*pout[1]
pin=np.array([-u2[1]*pchi/(u2[0]+2*xi2*pchi),pchi])
u1=u2+H@pin*(1/r1-1/r2)

def read_shell(u,jump,r):
    alpha=u[1]/u[0];Em=-2*u[1]*jump[1];Pm=(u@jump)/2
    U=Em/alpha;P=Pm/alpha;R=r*u[0]**2
    if not (U>2*P>0):raise ValueError(('particle support positivity',U,P))
    return dict(M=math.sqrt(U*(U-2*P)),ell2=2*P*R*R/(U-2*P),U=U,P=P,w=2*P/U,R=R)
s1=read_shell(u1,pin,r1);s2=read_shell(u2,pout-pin,r2)
outside=fluid_out(r2,u2,du2,rho2)
controls=np.array([s1['M'],s1['ell2'],s2['M'],s2['ell2'],outside['N']])
z0=np.log(np.r_[u1,r1,r2,rho2])

def particle_jump(u,r,M,ell2):
    ps,ch=u;alpha=ch/ps;R=r*ps*ps
    U=M*math.sqrt(1+ell2/(R*R));P=U*ell2/(2*(R*R+ell2))
    jump=np.array([alpha*(U+4*P)/(2*ps),-alpha*U/(2*ch)])
    return jump,alpha*P,U,P

def own_residual(z,ctrl=controls,rtol=5e-13,detail=False):
    ps,ch,rr1,rr2,rh2=np.exp(z)
    if rr2<=rr1:raise ValueError('wall ordering')
    uu1=np.array([ps,ch]); pp1,Pm1,U1,P1=particle_jump(uu1,rr1,*ctrl[:2])
    uu2=uu1+H@pp1*(1/rr2-1/rr1)
    jump2,Pm2,U2,P2=particle_jump(uu2,rr2,*ctrl[2:4]);pp2=pp1+jump2
    vv2=-H@pp2/(rr2*rr2);out=fluid_out(rr2,uu2,vv2,rh2,rtol=rtol)
    al2=uu2[1]/uu2[0];R2=rr2*uu2[0]**2
    f1=Pm1-(pp1@H@pp1)/(2*rr1)
    f2=Pm2-((pp2@H@pp2)-(pp1@H@pp1))/(2*rr2)-2*math.pi*al2*rh2*rh2*R2**3
    res=np.r_[out['asymptotic']-1,f1/s1['U'],f2/s2['U'],(out['N']-ctrl[4])/ctrl[4]]
    if not detail:return res
    return dict(residual=res,D=out['D'],u2=uu2,pin=pp1,r1=rr1,r2=rr2,rho2=rh2,
                U1=U1,P1=P1,U2=U2,P2=P2,N=out['N'])

def jac(fn,x,step=1e-4):
    return np.column_stack([(fn(x+np.eye(len(x))[i]*step)-fn(x-np.eye(len(x))[i]*step))/(2*step)
                            for i in range(len(x))])

# Refine the actual source at its independently reconstructed controls.
rr=root(own_residual,z0,tol=1e-10)
if max(abs(rr.fun))>1e-8:raise RuntimeError(rr.message)
z=rr.x;detail=own_residual(z,detail=True)
J=jac(own_residual,z)
Jfine=jac(own_residual,z,step=5e-5)

# Reconstruct outside solely from u2,r2 and its selected far charge D=0.
uu2=detail['u2'];rr2=detail['r2'];ppout=detail['pin']+particle_jump(uu2,rr2,*controls[2:4])[0]
duout=-H@ppout/(rr2*rr2)
vscale=max(abs(duout));outz=np.r_[duout/vscale,math.log(detail['rho2'])]
def outside_res(v):
    out=fluid_out(rr2,uu2,v[:2]*vscale,math.exp(v[2]))
    return np.r_[out['asymptotic']-1,out['D']/star['charge']]
Jo=jac(outside_res,outz)
Jof=jac(outside_res,outz,step=5e-5)

def js(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    raise TypeError(type(x).__name__)
out=dict(base_fluid_central=base.x,base_fields_at_outer_wall=uu2,
   base_n_at_outer_wall=float((uu2.sum()-2)/2),r1=detail['r1'],r2=detail['r2'],
   controls=dict(zip(['M1','ell1_squared','M2','ell2_squared','Nfluid'],controls)),
   particle_speed_squared=[2*detail['P1']/detail['U1'],2*detail['P2']/detail['U2']],
   maximum_actual_residual=float(max(abs(detail['residual']))),
   actual_source_D=detail['D'],own_BVP_Jacobian=J,
   own_BVP_determinant=float(np.linalg.det(J)),own_BVP_singular_values=np.linalg.svd(J)[1],
   own_Jacobian_step_change=float(np.max(abs(J-Jfine))),
   outside_reconstruction_Jacobian=Jo,outside_reconstruction_determinant=float(np.linalg.det(Jo)),
   outside_singular_values=np.linalg.svd(Jo)[1],outside_Jacobian_step_change=float(np.max(abs(Jo-Jof))),
   scope='One positive H0 preparation and two regular finite-dimensional maps. These numerical rank controls are evidence for a source-continuation lemma, not a completed arbitrary-H theorem.')
Path(__file__).with_name('filled-host-annular-rank-checks.json').write_text(json.dumps(out,indent=2,default=js)+'\n')
print(json.dumps(out,indent=2,default=js))
