"""Actual-source selection: main Sections 5--6 and proof Appendices A--C."""

MAIN_BLOCKS = []
APPENDIX_BLOCKS = []
_blocks = MAIN_BLOCKS


def p(text):
    _blocks.append(dict(type='p', text=text.replace("\\'", "'")))


def section(text):
    _blocks.append(dict(type='section', text=text))


def sub(text):
    _blocks.append(dict(type='sub', text=text))


def eq(label, *rows, result=False):
    _blocks.append(dict(type='eq', label=label, rows=list(rows), result=result))


def note(text):
    _blocks.append(dict(type='note', text=text))


section('5. Actual sources select the exterior response')
p(r'The source law constrains the complete physical preparation: its material, supporting motion, binding and entire field tail. Begin by keeping its complete energy $E_s$ distinct from the charge $E_C$ inferred by a distant clock. With $\rho$ the isotropic reference radius and $r=\rho\psi^2$ the areal radius, define')
eq('sp_charge',
   r'\psi=1+\frac{a_\psi}{\rho}+O(\rho^{-2}),\qquad \chi=1+\frac{a_\chi}{\rho}+O(\rho^{-2}),',
   r'\mu=a_\psi-a_\chi,\qquad E_C=\frac{c^4\mu}{G},\qquad \alpha^2=1-\frac{2GE_C}{c^4r}+O(r^{-2}).')
p(r'Enclose an admitted source $A$ in a real supported shell whose areal radius $L$ tends to infinity and whose proper energy tends to $m_B$. Regular source composition gives the following limits. The shell support, interaction energy and reaction of the inner source are included in the remainders:')
eq('sp_enclosure',
   r'E_{AB}=E_A+m_B+o(1),\qquad E_{C,AB}=E_{C,A}+m_B+o(1),',
   r'E_{AB}-E_{C,AB}=o(1)\quad\Longrightarrow\quad E_A=E_{C,A}.', result=True)
p('The second line follows by applying the exact source law at the aggregate\'s actual outer material boundary. It earns energy-charge agreement for every admitted inner source. Iterated enclosure permits the same argument for an aggregate itself. Appendix B gives the matching details; no vacuum surface is assigned the status of a material source.')
p(r'For each exterior use its own charge to normalize the inward radial parameter. The vacuum field equation is a geodesic equation in the two response variables, with constant quadratic norm:')
eq('sp_normalized',
   r'y=\frac{\mu}{2\rho},\qquad e=(1,-1),\qquad p^{(y)}=H u_y,\qquad K_y=u_y^{\mathsf{T}}H u_y,',
   r'\frac{dp^{(y)}_a}{dy}=\frac{1}{2} u_y^{\mathsf{T}}(\partial_aH)u_y,\qquad \frac{dK_y}{dy}=0,\qquad e^{\mathsf{T}}u_y(0)=2.')
p(r'Here $p^{(y)}$ is response-space momentum, not particle momentum; $K_y$ is a signed quadratic norm. Actual weak hollow shells exist before their exterior is selected. Their own energy, traction and second-order source law imply $H_\infty e=e$, where $H_\infty=H(1,1)$ (Appendix A). Their initial momenta are allowed to vary during that argument.')
p(r'The retained proper local source response, [[rt_localG]], then supplies an asymptotic test for any exterior. Write $\mathcal{D}=a_\psi+a_\chi$. Enclose the same source using either of two distinct finite limiting shell energies. Exact source matching gives a quadratic condition with at most one nonzero root:')
eq('sp_two_mass',
   r'j_B+\mathcal{C}_\infty j_B^2=0,\qquad j_B=\frac{2\mathcal{D}}{\mu+Gm_B/c^4},',
   r'm_{B,1}\ne m_{B,2}\quad\Longrightarrow\quad \mathcal{D}=0,\qquad u_y(0)=e,\quad p^{(y)}(0)=e,\quad K_y=2.')
p(r'The coefficient $\mathcal{C}_\infty$ belongs to the candidate energy, independently of the enclosing mass; Appendix B derives it. Two different masses cannot supply two different nonzero roots. Thus every passing source starts the same normalized vacuum geodesic. Ordinary uniqueness for the regular field equations makes that exterior curve common to the admitted source family.')
p(r'An actual hollow shell supplies values along this curve. Let $U$ be its proper material energy, $P$ its proper area-integrated tangential pressure, $E_m=\alpha U$, and $P_g=\alpha P$. The jumps, independent radius balance and complete energy give')
eq('sp_shell_endpoint',
   r'\chi p^{(y)}_\chi=-\frac{E_m}{E_s},\qquad \psi p^{(y)}_\psi=\frac{E_m+4P_g}{E_s},\qquad F_{\mathrm{ext}}=2P_g=E_s y,',
   r'\psi p^{(y)}_\psi=1+y,\qquad \chi p^{(y)}_\chi=y-1,\qquad \psi^2-\chi^2=4y.')
p(r'The pressure is supplied by the shell\'s own moving particles and is already in $U$. The last equality is the source law at that shell, using $r=\rho\psi^2$. Varying actual weak shells supplies an open endpoint interval, so these endpoint identities hold along the common curve. Define $L_u=\ln(\psi\chi)$ and $D_u=\ln(\psi/\chi)$. Contracting the momentum with $u_y$ gives the first equation below; the source law gives the second:')
eq('sp_curve_integration',
   r'y\frac{dL_u}{dy}+\frac{dD_u}{dy}=2,\qquad e^{L_u}=\frac{2y}{\sinh D_u},',
   r'\frac{dy}{dD_u}+y\coth D_u=1,\qquad y\sinh D_u=\cosh D_u-1,',
   r'y=\tanh(D_u/2),\qquad \psi=1+y,\qquad \chi=1-y.', result=True)
p(r'The integration constant is fixed by the regular unloaded endpoint $y=D_u=0$. This earns the exterior before fixing the energy away from that curve. On the curve, the shell momenta are $p^{(y)}=e$, so symmetry leaves only one matrix entry undetermined. The proper local source condition removes it:')
eq('sp_line_metric',
   r'H_{11}=H_{22}=h,\qquad H_{12}=h-1,\qquad \det H=2h-1,',
   r'e_\alpha^{\mathsf{T}}H^{-1}e_\alpha-2\alpha=\frac{h(\alpha-1)^2}{2h-1}=0,\qquad e_\alpha=(-\alpha,1),',
   r'H=H_0\ \mathrm{on\ the\ selected\ curve},\qquad (H_0)_{11}=(H_0)_{22}=0,\quad (H_0)_{12}=-1.', result=True)
p(r'Every loaded point has $\alpha\ne1$, hence $h=0$; continuity covers the endpoint. The ambient-response premise is retained on the regular domain used by the field equations, including its response derivatives. Agreement on one background curve alone would not supply that premise.')

section('6. Interacting sources select the remaining energy')
p('Two supported shells probe the energy between distinct response states. Their material law stays fixed: each shell contains a spherical counterrotating population of massive particles. The two rest populations and two angular momenta are four independently prepared physical controls. Appendix C proves a smooth open family of their actual equilibria for each fixed regular candidate at sufficiently weak strength.')
p(r'The proof uses the candidate\'s own equations: two asymptotic field values and two mechanical force balances. The source law and energy-charge agreement are subsequently applied to these solutions. No additional prescribed exterior or energy-agreement equation is used to manufacture their existence. Relative control of the shell separation supplies positive, subluminal sources approaching the exterior curve from one side.')
p(r'Use the unnormalized radial parameter $\xi=1/\rho$ in their vacuum annulus, with inner endpoint $\xi_1=1/\rho_1$. Define the response-space vector fields $X=(\psi,\chi)$ and $Y=(-\psi,\chi)$. The inner shell\'s traction and the complete energy identity are')
eq('sp_annular_identities',
   r'p^{(\xi)}=H u_\xi,\qquad K_\xi=u_\xi^{\mathsf{T}}H u_\xi,\qquad X\cdot p^{(\xi)}-\xi_1K_\xi=0,',
   r'E_C-E_s=\frac{\kappa}{4}\int (\mathcal{L}_YH)_{ab}\nabla u^a\cdot\nabla u^b\,d^3x=0.')
p(r'The Lie derivative $\mathcal{L}$ measures the change of the quadratic response under its indicated vector field. The second identity follows by varying the same complete energy, retaining its infinity boundary and material stresses. The constant inner cavity contributes no gradients; the selected exterior contributes zero to its integrand. Thus it becomes an annular identity.')
p(r'The actual controls map openly to outer annular seed data and the inner endpoint. Their local inverse reconstructs each particle population and angular momentum from its jump. Holding a seed fixed while changing the inner endpoint therefore describes actual neighboring sources. Differentiation of [[sp_annular_identities]] along that family gives')
eq('sp_quadratic_identities',
   r'(\mathcal{L}_XH-2H)(u_\xi,u_\xi)=0,\qquad (\mathcal{L}_YH)(u_\xi,u_\xi)=0,',
   r'\mathcal{L}_XH=2H,\qquad \mathcal{L}_YH=0.', result=True)
p('The second line follows because the actual phase flow supplies an open set of momentum directions at every sampled response point. A quadratic form vanishing on an open set vanishes identically. Appendix C establishes this rank statement from the particle preparations, rather than postulating arbitrary field variations.')
p(r'The two tensor identities integrate on each connected sampled region. Their constants are fixed by continuity to the already selected exterior curve:')
eq('sp_selected_energy',
   r'H_{11}=A_*\frac{\chi}{\psi},\qquad H_{12}=B_*,\qquad H_{22}=C_*\frac{\psi}{\chi},',
   r'A_*=C_*=0,\qquad B_*=-1,\qquad F=-\kappa\int\nabla\psi\cdot\nabla(\alpha\psi)\,d^3x.', result=True)
p(r'The field energy has therefore been selected on a genuine connected weak response domain attached to the exterior curve. Since $Z=(X+Y)/2=(0,\chi)$, the same source identities give $\mathcal{L}_ZH=H$: common clock homogeneity is a consequence there. The existence threshold may depend on the candidate\'s finite $C^2$ bounds. Extension to larger loads requires admitted regular source coverage; the weak theorem supplies no universal numerical compactness bound or unrestricted dynamical classification.')


_blocks = APPENDIX_BLOCKS

section('Appendix A. Weak one-shell existence and normalization')
p(r'For the material constructions set $c=G=1$, so energy has length units. Use $\xi=1/\rho$, $p^{(\xi)}=Hu_\xi$, and $K_\xi=(p^{(\xi)})^{\mathsf{T}}H^{-1}p^{(\xi)}$. A particle shell of rest energy $M$ and angular length $\ell$ has the following proper energy, integrated pressure, outward jump and independent traction:')
eq('sp_particle_shell',
   r'U=M\sqrt{1+\ell^2/r^2},\qquad P=\frac{U\ell^2}{2(r^2+\ell^2)},\qquad r=\rho\psi^2,',
   r'\Delta p^{(\xi)}=\left(\frac{\alpha(U+4P)}{2\psi},-\frac{\alpha U}{2\chi}\right),\qquad \alpha P=\frac{\Delta K_\xi}{2\rho}.')
p(r'The outward jump means exterior minus interior. For an empty cavity the interior momentum vanishes. Let $v=H_\infty^{-1}e$ and retain the ordinary attractive calibration $e^{\mathsf{T}}v=2$, also supplied by the unloaded local source law. Prepare $M=\epsilon m$, $\ell^2=\epsilon j$, and $u_c=(1,1)+\epsilon a$, with fixed $m,j>0$. The two asymptotic residuals divided by $\epsilon$ and the traction divided by $\epsilon^2$ tend to')
eq('sp_one_shell_ift',
   r'G_{\mathrm{AF}}=a-\frac{m}{2\rho}v,\qquad G_{\mathrm{force}}=\frac{mj}{2\rho^2}-\frac{m^2}{4\rho},',
   r'\rho_0=\frac{2j}{m},\qquad a_0=\frac{m}{2\rho_0}v,\qquad \det DG=-\frac{m^2}{4\rho_0^2}\ne0.')
p(r'In the vacuum flow write $u=(1,1)+\epsilon a(\xi)$ and $p^{(\xi)}=\epsilon\bar p(\xi)$. Its rescaled equations are')
eq('sp_one_shell_control',
   r'a_\xi=H^{-1}\bar p,\qquad (\bar p_b)_\xi=\frac{\epsilon}{2}a_\xi^{\mathsf{T}}(\partial_bH)a_\xi,',
   r'\alpha_c=1-\frac{\epsilon m}{\rho_0}+O(\epsilon^2),\qquad \frac{2P}{U}=\frac{\epsilon j}{\rho_0^2}+O(\epsilon^2).')
p(r'Finite $C^2$ bounds give convergence with one derivative on compact rescaled sets. The implicit-function theorem therefore supplies actual positive-energy, subluminal weak shells and an open endpoint interval. Only the three own field/force equations enter this construction. An extendible regular endpoint chart permits trial variations; the resulting physical solutions have $0<\alpha<1$.')
p(r'After enclosure has earned $E_s=E_C$, return to $y=\mu/(2\rho)$. On the same exterior $p^{(\xi)}=(\mu/2)p^{(y)}$ and $K_\xi=(\mu^2/4)K_y$. A hollow shell at $y=\delta$ obeys, for arbitrary $H$,')
eq('sp_weak_endpoint',
   r'\frac{F_{\mathrm{ext}}}{E_C}=\frac{K_y\delta}{2},\qquad F_{\mathrm{ext}}=2P_g,',
   r'\psi p^{(y)}_\psi=1+\frac{K_y\delta}{2},\qquad \chi p^{(y)}_\chi=-1+\frac{K_y\delta}{2}.')
p(r'Regularity first gives $p^{(y)}_\infty\to e$ and $K_y\to2$. Keep the source-dependent initial correction $p^{(y)}_\infty=e+\delta b+o(\delta)$, and write $v=(\gamma,\gamma-2)$. Let $f_a=\frac{1}{2}v^{\mathsf{T}}(\partial_aH)_\infty v$. Expansion of [[sp_weak_endpoint]] and exact charge normalization give')
eq('sp_weak_momentum',
   r'b+f+(\gamma,2-\gamma)=(1,1),\qquad v\cdot b=0,\qquad v\cdot f=2-2\gamma,',
   r'e\cdot u_{yy}(0)=-v\cdot f=2\gamma-2.')
p(r'The geodesic contraction in the second line follows directly by contracting the first-kind connection with $v$ three times. The moving initial momentum contributes $2v\cdot b=0$, rather than being set to zero. At the actual material endpoint,')
eq('sp_weak_Q',
   r'\psi_s^2-\chi_s^2=4\delta+6(\gamma-1)\delta^2+o(\delta^2)=4\delta,',
   r'\gamma=1,\qquad v=e,\qquad H_\infty e=e.', result=True)
p(r'The rightmost equality is exact source $Q$. This establishes the normalized tangent without assuming clock homogeneity or a common finite-source exterior. The support remains positive: $P/U=\delta/2+o(\delta)$.')

section('Appendix B. Source enclosure and the common exterior')
p(r'Restore $c$ and $G$ for the enclosure calculation. Before $H_\infty e=e$ is known, an asymptotically weak enclosing shell adds the field amplitudes shown below. The weak calibration already fixes its lapse-charge increment:')
eq('sp_cluster_matching',
   r'\delta(a_\psi,a_\chi)=\frac{m_B}{4\pi\kappa}H_\infty^{-1}e+O(L^{-1}),\qquad \delta E_C=m_B+O(L^{-1}),',
   r'\alpha_{AB}(L)^2=1-\frac{2GE_{C,AB}}{c^4L}+o(L^{-1})=1-\frac{2GE_{AB}}{c^4L}.')
p(r'Self and interaction field energies are $O(L^{-1})$; finite inner susceptibility gives the same order for inner readjustment. Included particle support has vanishing relative pressure. These are the regular distant-cluster conditions of the source class. Multiplying the last equality by $L$ and taking the limit proves [[sp_enclosure]].')
p(r'To fix the remaining asymptotic ruler charge, express the local-response identity throughout its ambient domain using $I=\psi\chi$ and $v_c=\frac{1}{2}\ln\alpha$. The target quadratic form $g$ then has $g^{v_cv_c}=1/(2I)$, equivalently')
eq('sp_local_metric',
   r'g=\mathcal{A}\,dI^2+2\mathcal{B}\,dI\,dv_c+\left(2I+\frac{\mathcal{B}^2}{\mathcal{A}}\right)dv_c^2,\qquad \mathcal{A}\ne0,',
   r'\mathcal{B}_\infty=0,\qquad \mathcal{C}_\infty=\left(\frac{1}{2}\partial_I\mathcal{B}-\frac{1}{4}\partial_{v_c}\mathcal{A}\right)_\infty.')
p(r'For a normalized exterior, $I_y(0)=j=2\mathcal{D}/\mu$ and $(v_c)_y(0)=-1$. The geodesic equation of [[sp_local_metric]] gives the following Taylor expansion of the actual source expression:')
eq('sp_Q_root',
   r'\mathcal{F}_Q=-\frac{I}{2}\sinh(2v_c),\qquad \mathcal{F}_Q(y)=y+\frac{1}{2}(j+\mathcal{C}_\infty j^2)y^2+o(y^2),',
   r'\mathcal{F}_Q(y_s)=y_s\quad\mathrm{at\ each\ actual\ outer\ boundary}.')
p(r'Once Appendix A is applied, distant weak matching gives $\mathcal{D}_{AB}=\mathcal{D}_A+o(1)$ and $\mu_{AB}=\mu_A+Gm_B/c^4+o(1)$. Apply [[sp_Q_root]] at the aggregate\'s own outer shell and divide by $y_s^2$. Smoothness gives a uniform remainder for the bounded normalized initial data. The limit yields [[sp_two_mass]]. Applying enclosure also to these aggregates respects the order in which energy-charge agreement was earned.')
p(r'The resulting common initial data and actual hollow endpoint interval justify every differentiation in [[sp_curve_integration]]. The regular solution follows either by its integrating factor $\sinh D_u$ or by geodesic uniqueness after the endpoint is fixed. Its areal readings are')
eq('sp_areal_response',
   r'r=\rho(1+y)^2,\qquad \alpha=\frac{1-y}{1+y},\qquad \frac{dr}{d\rho}=1-y^2,',
   r'A=\alpha^2=1-\frac{2\mu}{r},\qquad B=\frac{\psi^4}{(dr/d\rho)^2}=\frac{1}{A}.', result=True)
p('These statements hold on the regular exterior interval reached by the source argument. They use the exact law on actual material boundaries followed by solution uniqueness, preserving the distinction between a source domain and a vacuum reading.')

section('Appendix C. Actual two-shell sources and local functional selection')
p(r'Use the geometric units and shell law of Appendix A. Let $0<\rho_1<\rho_2$, with a constant inner cavity, one vacuum annulus and the outer vacuum. Prepare $M_i=\epsilon m_i$ and $\ell_i^2=\epsilon j_i$. Write the unknown cavity fields as $\psi_c=1+\epsilon\Phi+\epsilon^2 Z_c$ and $\chi_c=1-\epsilon\Phi+\epsilon^2 Z_c$. Divide the antisymmetric and symmetric asymptotic residuals by $\epsilon$ and $\epsilon^2$, respectively, and both tractions by $\epsilon^2$. Their limits are')
eq('sp_two_shell_residuals',
   r'G_\Phi=\Phi-\frac{m_1}{2\rho_1}-\frac{m_2}{2\rho_2},\qquad \Phi_2=\Phi-\frac{m_1}{2\rho_1}+\frac{m_1}{2\rho_2},',
   r'G_Z=Z_c+\frac{1}{2}\left(-\frac{m_1\Phi}{\rho_1}+\frac{m_1j_1}{\rho_1^3}-\frac{m_2\Phi_2}{\rho_2}+\frac{m_2j_2}{\rho_2^3}\right),',
   r'G_1=\frac{m_1j_1}{2\rho_1^2}-\frac{m_1^2}{4\rho_1},\qquad G_2=\frac{m_2j_2}{2\rho_2^2}-\frac{m_2(2m_1+m_2)}{4\rho_2}.')
p(r'Their positive root and Jacobian, in unknown order $(\Phi,Z_c,\rho_1,\rho_2)$, are explicit:')
eq('sp_two_shell_root',
   r'\rho_1=\frac{2j_1}{m_1},\qquad \rho_2=\frac{j_2}{m_1+m_2/2},\qquad \Phi=\frac{m_1}{2\rho_1}+\frac{m_2}{2\rho_2},',
   r'Z_c=\frac{m_1m_2}{4\rho_2}\left(\frac{1}{\rho_1}-\frac{1}{\rho_2}\right),\qquad \det DG=\frac{m_1^2m_2(2m_1+m_2)}{16\rho_1^2\rho_2^2}>0.')
p(r'To control a general candidate, use normal and tangent response coordinates $n=(\psi+\chi-2)/2$ and $w=(\psi-\chi)/2$. Equality to $H_0$ on $n=0$, together with its own selected-line geodesicity, implies')
eq('sp_transverse_control',
   r'g_{nn}=-2+O(n),\qquad g_{nw}=O(n),\qquad g_{ww}=2+O(n^2),',
   r'n=\epsilon^2\zeta,\quad w=\epsilon\phi,\quad p_n=\epsilon^2\eta,\quad p_w=\epsilon\Pi,',
   r'\zeta_\xi=-\eta/2+O(\epsilon),\quad \phi_\xi=\Pi/2+o(1),\quad \eta_\xi=O(\epsilon),\quad \Pi_\xi=o(1).')
p(r'The potentially leading normal force contains $\partial_n g_{ww}=O(n)$; mixed normal derivatives carry an extra $\epsilon$. The estimates hold with one derivative under finite $C^2$ bounds. Thus the normalized own boundary problem converges in $C^1$ to [[sp_two_shell_residuals]], and its nonzero determinant supplies independent actual particle controls. Neither vanishing normal first derivatives nor small constitutive deformation is assumed.')
p(r'Attachment to the line requires relative separation control. Parametrize exact $H_0$ particle data by a gap $g\geq0$, keeping masses positive and radii bounded away from zero. At the ordered zero-gap reference, the annulus has zero length; the candidate and $H_0$ have exactly the same root because their line values and exterior geodesic coincide. The determinant remains nonzero there. Uniform continuation and differentiation in $g$ give')
eq('sp_gap_control',
   r'(\rho_2-\rho_1)_H=(\rho_2-\rho_1)_{H_0}[1+O(\epsilon)],',
   r'\frac{n}{\epsilon^2}=\frac{m_1m_2}{4\rho_2}\left(\xi-\frac{1}{\rho_2}\right)+o(1),\qquad \frac{w}{\epsilon}=\frac{m_2}{2\rho_2}+\frac{m_1\xi}{2}+o(1).')
p(r'For sufficiently small fixed strength and positive arbitrarily small gap, the physical shells remain separated, their energies positive and their support speeds subluminal. The reference with zero separation is only a limiting point of the proof. These sources reach a connected side of the line at nonzero weak load.')
p(r'For every passing actual source its outer exterior is already selected. At $\xi_2=1/\rho_2$, put $y=\mu\xi_2/2$, $u_s=(1+y,1-y)$, and $p_{\mathrm{out}}^{(\xi)}=(\mu/2)e$. The annular momentum $p$ below is $p^{(\xi)}$. Combining the outer jump with its traction leaves exactly three seeds:')
eq('sp_annular_seed',
   r'\psi_s p_\psi+\chi_s p_\chi+2\xi_2p_\psi p_\chi=0,\qquad p_\psi=-\frac{\chi_s p_\chi}{\psi_s+2\xi_2p_\chi},',
   r'(\mu,\xi_2,p_\chi,\xi_1),\qquad \xi_1=1/\rho_1.')
p(r'These four seed/endpoint variables have an actual open image. To see this, integrate the candidate annulus, read $U_i,P_i$ from each jump, and reconstruct its controls:')
eq('sp_inverse_controls',
   r'M_i=\sqrt{U_i(U_i-2P_i)},\qquad \ell_i^2=\frac{2P_i r_i^2}{U_i-2P_i},\qquad 0<2P_i<U_i,',
   r'\mathcal{G}_H(\mathcal{S}_H(z))=z,\qquad D\mathcal{G}_H\,D\mathcal{S}_H=\mathrm{Id}.')
p(r'Here $z=(M_1,\ell_1^2,M_2,\ell_2^2)$ and $\mathcal{S}_H$ is the actual source map earned above. Its smooth left inverse proves full rank. Hence an endpoint variation at fixed seed is an actual source variation. At the selected section $\Sigma=\psi+\chi-2=0$, positive inner and outer populations give')
eq('sp_phase_transversality',
   r'-\mu/2<p_\chi<0,\qquad \frac{d\Sigma}{d\xi}=-\frac{2\xi_2p_\chi(\mu/2+p_\chi)}{\psi_s+2\xi_2p_\chi}>0.')
p(r'Three seed coordinates and elapsed affine parameter therefore form a local flow box in four-dimensional $(u,p)$ space. Regular geodesic flow preserves its rank. Each sampled response point has an open momentum fiber, which is the required set of physical directions.')
p(r'The complete-energy identity can be derived before localizing it. Let $\sigma$ be the proper material stress including support, and put $\mathcal{T}=\int\alpha\operatorname{tr}\sigma\,dV$. Spatial dilation gives the closed-source virial $F=\mathcal{T}$. The variation generated by $Y$ changes both clock and physical area; its material term and the retained infinity boundary are')
eq('sp_energy_ward_derivation',
   r'\delta_Y E_m=2E_m+2\mathcal{T}=2E_s,',
   r'B_Y=2E_s+\frac{\kappa}{2}\int(\mathcal{L}_YH)_{ab}\nabla u^a\cdot\nabla u^b\,d^3x,\qquad B_Y=4\pi\kappa\mu=2E_C.')
p(r'The boundary value uses the earned $H_\infty=H_0$ and the actual asymptotic charge. This proves [[sp_annular_identities]] with material and support terms retained.')
p(r'Finally, the inner jump and traction give $X\cdot p-\xi_1K_\xi=0$. Differentiate at fixed seed. For the energy identity, radial integration converts the annular term to $4\pi\int_{\xi_2}^{\xi_1}(\mathcal{L}_YH)(u_\xi,u_\xi)d\xi$. The selected exterior has zero integrand by line agreement and geodesicity. Therefore')
eq('sp_endpoint_differentiation',
   r'\frac{d}{d\xi_1}(X\cdot p-\xi_1K_\xi)=\frac{1}{2}(\mathcal{L}_XH-2H)(u_\xi,u_\xi)=0,',
   r'\frac{d}{d\xi_1}\int_{\xi_2}^{\xi_1}(\mathcal{L}_YH)(u_\xi,u_\xi)\,d\xi=(\mathcal{L}_YH)(u_\xi,u_\xi)=0.')
p(r'Open momentum fibers give [[sp_quadratic_identities]] pointwise. Their component equations first make $H$ degree zero under $X$; the $Y$ equations then give precisely the three-constant form in [[sp_selected_energy]]. Connected attachment fixes those constants. This proves exact functional equality on the attained weak domain, including smooth terms invisible in every Taylor coefficient along the exterior line.')
