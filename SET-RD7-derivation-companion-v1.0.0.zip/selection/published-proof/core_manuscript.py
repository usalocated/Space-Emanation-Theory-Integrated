"""Authorial main text; independent proof and orbit modules complete the paper."""
INTRO_BLOCKS=[]
CURRENT_BLOCKS=[]
CLOSING_BLOCKS=[]
_blocks=INTRO_BLOCKS
def p(s): _blocks.append(dict(type='p',text=s))
def section(s): _blocks.append(dict(type='section',text=s))
def sub(s): _blocks.append(dict(type='sub',text=s))
def eq(label,*rows,result=False): _blocks.append(dict(type='eq',label=label,rows=list(rows),result=result))
def note(s): _blocks.append(dict(type='note',text=s))

_blocks.append(dict(type='title',text='Source, capacity and the<br/>selection of field energy',subtitle='From complete sources to spherical motion',author='Erik Echeverria',date='Rough Draft 2 | 1 November 2026'))
p('Matter continuously commits field interaction capacity as gravitational burden. SET expresses this commitment through its source law and relates the remaining capacity to translation and local physical evolution. The question developed here is how those source and capacity requirements restrict the energy of the field itself.')
p('I begin with independent clock and spatial responses and unknown local field-energy coefficients. The same properly measured weak-source law is required in loaded surroundings, and the actual source law is applied to complete closed sources, including their field and physical supports. Supported hollow sources determine the exterior response; interacting sources determine the remaining energy coefficients on the connected domain they probe. Clock homogeneity follows from their force and energy identities. The selected energy supplies the work current, the spherical clock and radial response, and, through the established probe coupling, the perihelion equation.')
p('The main theorem concerns a regular local static two-response class and an attached weak source-covered domain. A conditional continuation along the regular finite-load source family is developed separately in Appendix D. The mathematical steps and the source preparations that justify them are kept together throughout the derivation.')

section('1. Capacity: one physical limit for motion and events')
p("In SET, a field's limited capacity for interaction means a limited capacity for physical motion. Mass continuously commits part of that capacity as gravitational burden, with its sourcing quantified by the law Q. Greater burden leaves less capacity available for translation and the local motion through which events unfold. Greater translational speed takes a larger share of what remains, leaving less for internal progression per reference second. A clock's journey and its ticks participate in the same physical limit.")
eq('rt_capacity',r'S^2+V_{\mathrm{rel}}^2+c^2\beta^2=c^2,\qquad \beta=\frac{d\tau}{dT}.',result=True)
p(r'Here $T$ is the specified reference time and $\tau$ is the probe\'s proper time. The burden $S$ and translational reading $V_{\mathrm{rel}}$ have speed units. For a held clock, translation vanishes and its progression is $\alpha$. Define its square $A$:')
eq('rt_held',r'\alpha^2=A=1-\frac{S^2}{c^2},\qquad \beta^2=A-\frac{V_{\mathrm{rel}}^2}{c^2}.')
p('The local observer uses clocks and rulers participating in the same field response. The locally measured limiting speed is c; propagation measured against the reference time depends on that response. The radial propagation law will be calculated after the spatial response has been selected.')
p('The capacity relation also has an exact quadratic energy reading. Multiplying every term by m/2 gives')
eq('rt_quadratic',r'K_0=\frac{mV_{\mathrm{rel}}^2}{2}=\frac{mc^2}{2}(1-\beta^2)-\frac{mS^2}{2},',r'dK_0=-\frac{m}{2}\,dS^2-\frac{mc^2}{2}\,d\beta^2.')
p('Motion and clock progression cannot be varied independently of burden. The complete energy framework used below determines how this balance is realized by actual sources and probes. The stationary sources are equilibria of that same energy, so their supporting stresses belong in the calculation.')

section('2. The source law and the energy of a complete source')
p('For a specified spherical source, the source law can be written in its surface form or its volume form:')
eq('rt_source',r'Q_s=4\pi\sqrt{2GMR_0^3},\qquad Q_s^2=24\pi GMV_{\mathrm{ref}},',r'M=\frac{E_s}{c^2},\qquad V_{\mathrm{ref}}=\frac{4\pi R_0^3}{3}.',result=True)
p(r'For later motion calculations define the source strength $\mu_Q$, with units of $\mathrm{m^3\,s^{-2}}$:')
eq('rt_source_strength',r'\mu_Q\equiv\frac{Q_s^2}{24\pi V_{\mathrm{ref}}}=\frac{GE_s}{c^2}=GM.')
p(r'$R_0$ is the actual outer areal radius: its surface has physical area $4\pi R_0^2$. The complete isolated energy $E_s$ includes material, binding, field energy and every physical support. It includes the exterior field tail as well as the material inside the boundary. The source-law volume $V_{\mathrm{ref}}$ is specified by $R_0$; the physical volume integral will be defined by the spatial response.')
p('At this actual source surface, the area reading of the law is')
eq('rt_surface',r'Q_s=4\pi R_0^2S_0,\qquad S_0=S(R_0).')
p('Squaring this reading and comparing it with the source law gives the source boundary condition:')
eq('rt_boundary',r'S_0^2=\frac{2GE_s}{c^2R_0},\qquad \alpha_0^2=1-\frac{2GE_s}{c^4R_0}.',result=True)
p('The same law is applied to closed sources assembled from ordinary material, including supported hollow sources and a source surrounded by another physical layer. Each assembly has its own complete energy and actual outer boundary. The field and support energies are evaluated for that assembly.')
p('A distant or weak added layer provides a controlled comparison between source states. The admitted family has regular cluster limits: its small interactions and induced readjustments tend to zero as the separation grows. This source-composition requirement is used explicitly when complete energy is related to the distant clock response.')
_blocks.append(dict(type='table',headers=['Reading','Meaning','Units / role'],rows=[
 [r'$S,\ V_{\mathrm{rel}}$', 'Burden and translational motion readings', r'$\mathrm{m\,s^{-1}}$'],
 [r'$\alpha,\ \beta$', 'Held and moving clock progression per reference time', 'Dimensionless'],
 [r'$Q_s$', 'Source rate for its specified complete domain', r'$\mathrm{m^3\,s^{-1}}$'],
 [r'$E_s,\ M$', 'Complete source energy and its mass equivalent', r'$\mathrm{J},\ \mathrm{kg}$'],
 [r'$R_0,\ r,\ \rho$', 'Actual source areal radius, evaluation areal radius, isotropic reference radius', r'$\mathrm m$'],
 [r'$V_{\mathrm{ref}},\ dV$', 'Specified source-law volume; physical volume element', r'$\mathrm{m^3}$']
],widths=[96,290,103]))

section('3. The same local source law in a loaded field')
p(r'Consider a small experiment in an approximately uniform background burden $S_b$, with held-clock factor $\alpha_b>0$. Its background proper time is $d\tau_b=\alpha_b\,dT$. Subtract the background commitment from the capacity equation and divide by the remaining background capacity:')
eq('rt_subtract',r'(S^2-S_b^2)+V_{\mathrm{rel}}^2+c^2\beta^2=c^2-S_b^2=c^2\alpha_b^2.')
p('Define the added burden and the local motion and clock readings by')
eq('rt_relative',r'S_{\mathrm{local}}^2=\frac{S^2-S_b^2}{\alpha_b^2},\qquad V_{\mathrm{local}}=\frac{V_{\mathrm{rel}}}{\alpha_b},\qquad \beta_{\mathrm{local}}=\frac{\beta}{\alpha_b},',r'S_{\mathrm{local}}^2+V_{\mathrm{local}}^2+c^2\beta_{\mathrm{local}}^2=c^2.',result=True)
p('The normalization preserves the capacity relation exactly. The physical requirement applied to this local experiment is:')
note('<b>Local source universality.</b> A weak added source obeys the same calibrated source law when its energy, radius and added burden are read using the physical clocks and rulers of its approximately uniform surroundings.')
p(r'At leading weak-source order, for proper source mass $m$ and proper local radius $r_{\mathrm{local}}$, this means')
eq('rt_localweak',r'S_{\mathrm{local}}^2=\frac{2Gm}{r_{\mathrm{local}}}+O\left(\frac{G^2m^2}{r_{\mathrm{local}}^2c^2}\right).')
p(r'Equation [[rt_relative]] derives the local normalization. The requirement in [[rt_localweak]] states that the actual added source has the same properly measured response. Converting a rate to $Q/\alpha_b$ is a change of clock reading; the local-source requirement additionally constrains the field\'s response to that source.')
p('This requirement is imposed on the regular ambient-response domain used by the local field equations. It applies to neighboring physically compared background states, so the derivatives of the response are part of the same statement. The global source boundary continues to use the complete energy of the whole assembly.')

section('4. Leave the field-energy coefficients unknown')
p('Use two independent operational responses. The spatial reading is conformal to the declared Euclidean reference ruler, and the second response combines the clock and spatial factors:')
eq('rt_responses',r'q_{ij}=\psi^4\delta_{ij},\qquad dV=\psi^6d^3x,\qquad \chi=\alpha\psi,\qquad u=(\psi,\chi).')
p(r'$\psi$ and $\chi$ are dimensionless. Their relationship is initially unsolved. In spherical symmetry the areal radius is $r=\rho\psi^2$. Gradients written $\nabla$ use the reference ruler; $D$ denotes differentiation in the physical spatial reading $q_{ij}$.')
p('Examine the regular local quadratic first-gradient energy for these responses:')
eq('rt_class',r'E=E_m+F,\qquad E_m=\int\alpha\epsilon_m\,dV,\qquad \kappa=\frac{c^4}{2\pi G},',r'F=\frac{\kappa}{2}\int\left[H_{11}(u)|\nabla\psi|^2+2H_{12}(u)\nabla\psi\cdot\nabla\chi+H_{22}(u)|\nabla\chi|^2\right]d^3x.',result=True)
p(r'The symmetric coefficient matrix $H(u)$ is unknown, regular and nondegenerate. It is a field-energy coefficient matrix, distinct from a probe Hamiltonian or a Hubble rate. The constant $\kappa$ has force units, so the integral has energy units. The physical energy density $\epsilon_m$ includes material and support, and the same material energy determines its stress.')
p('This class specifies two response variables, a local first-gradient energy, a regular unloaded state and a fixed boundary-energy convention. Regularity means twice continuously differentiable coefficients in the operational variables near the unloaded state. Source fields approach the reference state at infinity. The same stationary energy supplies both field variations and the mechanical force balance of the supports.')
p('For a test body, the retained common-energy coupling generates translational motion and internal clock progression. Its canonical, test-body homogeneity and clock conditions give')
eq('rt_probe',r'E_p=\alpha\sqrt{E_0^2+c^2q^{ij}p_i p_j},\qquad \frac{\partial E_p}{\partial E_0}=\beta,\qquad E_0=mc^2.')
p('Here p is material canonical momentum. Appendix E spells out this retained coupling. The field-space momenta used in the source calculations are different objects and carry their normalization explicitly.')
p(r'The local added-source experiment constrains the unknown matrix. At a uniform ambient state define $e_\alpha=(-\alpha,1)$. Linearizing the same energy in a small proper source gives')
eq('rt_localG',r'\frac{G_{\mathrm{local}}}{G}=\frac{e_\alpha^{\mathsf{T}}H^{-1}e_\alpha}{2\alpha}=1.',result=True)
p(r'The factors follow by adding a proper point energy $E_{\mathrm{local}}=mc^2$ to a uniform background. Its linear material covector is $E_{\mathrm{local}}e_b/\psi_b$, where $e_b=(-\alpha_b,1)$ and $H_b$ is the background matrix. The Green function of the reference Laplacian gives')
eq('rt_green',r'\delta u=-\frac{E_{\mathrm{local}}}{4\pi\kappa\psi_b\rho}H_b^{-1}e_b,\qquad r_{\mathrm{local}}=\psi_b^2\rho,',r'\frac{\delta\alpha}{\alpha_b}=-\frac{Gm}{c^2r_{\mathrm{local}}}\frac{e_b^{\mathsf{T}}H_b^{-1}e_b}{2\alpha_b}.')
p(r'The coefficient of the proper local potential is precisely the ratio in [[rt_localG]]. The same local source law therefore restricts the energy coefficients before an exterior or orbit is prescribed.')
p('The remaining derivation tests these coefficients against actual complete sources. The positive-clock, ordinary attractive branch and the regular source preparations are maintained throughout. The main selection result is exact on the connected weak domain reached by those preparations; Appendix D states the finite-load continuation conditions used to extend the application.')

_blocks=CURRENT_BLOCKS
section('7. The selected field energy and its work current')
p('The source tests select the mixed energy on their connected domain:')
eq('rt_selected',r'H_{11}=H_{22}=0,\qquad H_{12}=H_{21}=-1,',r'F=-\frac{c^4}{2\pi G}\int\nabla\psi\cdot\nabla(\alpha\psi)\,d^3x.',result=True)
p('This energy has the reciprocal response symmetry used in the selection proof. Give its infinitesimal parameter a position dependence, eta(x), and vary the two responses oppositely:')
eq('rt_localvariation',r'\delta\psi=-\eta\psi,\qquad \delta\chi=\eta\chi,',r'\delta F=\int\mathbf j\cdot\nabla\eta\,d^3x,\qquad \mathbf j=\kappa(\psi\nabla\chi-\chi\nabla\psi)=\kappa\psi^2\nabla\alpha.')
p(r'The material energy is affected by the same variation. Let $\sigma$ be its proper stress, with positive isotropic pressure satisfying $\mathrm{tr}\,\sigma=3p$. The material and support work gives')
eq('rt_materialvariation',r'\delta E_m=2\int\alpha\psi^6(\epsilon_m+\mathrm{tr}\,\sigma)\eta\,d^3x.',r'\nabla\cdot\mathbf j=2\alpha\psi^6(\epsilon_m+\mathrm{tr}\,\sigma).')
p('The second line follows by integrating the field variation by parts and requiring stationarity for an arbitrary compact variation. The physical spatial Laplacian converts the reference current into a local work reading:')
eq('rt_current',r'D^2\alpha=\psi^{-6}\nabla\cdot(\psi^2\nabla\alpha),\qquad \mathbf J_W=c^2D\alpha,',r'D\cdot\mathbf J_W=\frac{4\pi G}{c^2}\alpha(\epsilon_m+\mathrm{tr}\,\sigma).',result=True)
p('The work current has acceleration units. Its source contains the physical support stresses because those stresses were already included in the same energy. The current is a stationary spatial balance.')
p('A uniform spatial dilation of a closed equilibrium scales the first-gradient field energy by one power of length. The accompanying material work is minus the integrated stress trace. Stationarity therefore gives')
eq('rt_virial',r'F=\int\alpha\,\mathrm{tr}\,\sigma\,dV,\qquad E_s=\int\alpha(\epsilon_m+\mathrm{tr}\,\sigma)\,dV.')
p('Integrating [[rt_current]] over the complete source connects the field current to the same source law:')
eq('rt_flux',r'\oint_{\Sigma}\mathbf J_W\cdot d\mathbf A=\frac{4\pi GE_s}{c^2}=\frac{Q_s^2}{6V_{\mathrm{ref}}}.',result=True)
p(r'$\Sigma$ is a complete vacuum surface surrounding the source. Its flux is conserved because $D\cdot\mathbf J_W=0$ in vacuum. The finite-domain $Q_s$ remains attached to its actual source domain. It is the combination $Q_s^2/(6V_{\mathrm{ref}})$ that normalizes this conserved work flux.')
sub('7.1 Three physical gradient readings')
p('Capacity converts the same clock gradient into three useful readings:')
eq('rt_three',r'\mathbf J_{\mathrm{cap}}=-\frac12D(S^2)=\alpha\mathbf J_W,',r'\mathbf J_W=-\frac{D(S^2)}{2\alpha},\qquad \mathbf a_{\mathrm{hold}}=\frac{\mathbf J_W}{\alpha}=c^2D\ln\alpha.')
p('The last quantity is the outward local acceleration required to hold a probe. The work current is that acceleration expressed with its clock weight. Their different factors matter:')
eq('rt_divcap',r'D\cdot\mathbf J_{\mathrm{cap}}=\alpha D\cdot\mathbf J_W+\frac{|\mathbf J_W|^2}{c^2}.')
p('Thus the capacity gradient and the conserved vacuum current have distinct mathematical roles. Their relation follows from the invariant, while conservation follows from the selected energy.')
sub('7.2 A field equation written in burden')
p(r'Put $b_S=S^2=c^2(1-\alpha^2)$; the subscript distinguishes this burden variable from a gravitational length. Applying the chain rule to [[rt_current]] gives')
eq('rt_burdenPDE',r'D^2b_S+\frac{|Db_S|^2}{2(c^2-b_S)}=-\frac{8\pi G}{c^2}\left(1-\frac{b_S}{c^2}\right)(\epsilon_m+\mathrm{tr}\,\sigma).',result=True)
p('The nonlinear gradient term follows from the capacity-to-clock conversion. Every term has inverse-time-squared units. The equation uses the positive-clock domain already specified in the construction.')
p(r'For weak nonrelativistic sources set $\Phi=-S^2/2$ and $\epsilon_m\simeq\rho_m c^2$. To leading order the physical ruler is Euclidean, and the same equation becomes')
eq('rt_newton',r'\nabla^2\Phi=4\pi G\rho_m,\qquad \mathbf a=-\nabla\Phi=\frac12\nabla S^2.')
p('The weak binding energy is consistent with the same complete accounting. The selected field contribution is positive in this decomposition, while the material energy is clock weighted. Together they give')
eq('rt_binding',r'F\simeq\frac{1}{8\pi G}\int|\nabla\Phi|^2d^3x=-\frac12\int\rho_m\Phi\,d^3x,',r'E_s\simeq E_{\mathrm{proper\ material}}+\frac12\int\rho_m\Phi\,d^3x.')
p('For an attractive potential the net binding contribution is negative. The proper material term includes the internal and support energy of the actual preparation.')

_blocks=CLOSING_BLOCKS
section('10. Source, capacity and motion in one calculation')
p('The physical requirement is straightforward: the same source law must describe an added source in local field readings and a complete source assembled with other matter. The field, material and supporting stresses participate in one energy account. These requirements restrict how the clock and spatial responses can depend on each other.')
p('The derivation begins with unknown energy coefficients. Actual source balance determines the exterior, and interacting source preparations determine the energy on the domain they explore. The selected reciprocal response supplies the work current and its normalization in Q. The established probe energy then carries that field response into motion, radial light propagation and perihelion.')
p('The field energy has an upstream source-based justification. Its spherical motion follows through the established probe coupling.')

FINAL_BLOCKS=[]
_blocks=FINAL_BLOCKS
section('References and calculation record')
p('E. Echeverria, <i>Space Emanation Theory - Integrated Rough Draft 6</i> (2026). Capacity, complete source energy and the retained common-energy probe coupling. <link href="https://github.com/usalocated/Space-Emanation-Theory-Integrated/blob/main/Space%20Emanation%20Theory%20-%20Integrated%20Rough%20Draft%206.pdf" color="#234a60">Public manuscript.</link>')
p('The source-field algebra, particle-source equilibrium calculations and numerical controls accompanying this paper are indexed in its calculation record. Appendix G identifies the checks and their mathematical role. Astronomical inputs and the comparison for Mercury are cited at the calculation in Section 9.')
