"""Replay three fixed NFW prescriptions on the two measured stellar contours."""
import argparse
import csv
import io
import json
from pathlib import Path
import sys
from zipfile import ZipFile

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
G = 4.30091e-6
N = 32768


def rows(archive, filename):
    return list(csv.DictReader(io.StringIO(archive.read(filename).decode())))


def stream(rank, channel):
    return np.random.default_rng(np.random.SeedSequence([202611180833, rank, channel]))


def positive_normal(generator, center, sd):
    values = center + sd * generator.standard_normal(len(center))
    while np.any(mask := (values <= 0)):
        values[mask] = center[mask] + sd * generator.standard_normal(mask.sum())
    return values


def accepted_angles(rank, projected_ratio, inclination, sigma):
    # Consume both independent streams in each candidate batch, even when
    # ellipse error and tilt correlation are zero, to reproduce the prior draw.
    rng = stream(rank, 0)
    accepted = []
    count = 0
    while count < N:
        size = max(1024, N - count)
        rng.standard_normal(size)
        angles = inclination + sigma * rng.standard_normal(size)
        rad = np.deg2rad(angles)
        q2 = (projected_ratio**2 - np.cos(rad)**2) / np.sin(rad)**2
        good = angles[(q2 >= 0) & (q2 <= 1) & (np.abs(np.sin(rad)) > 0)]
        accepted.append(good)
        count += len(good)
    return np.concatenate(accepted)[:N]


def mass200(stellar):
    low = np.full_like(stellar, 6., dtype=float)
    high = np.full_like(stellar, 18., dtype=float)
    for _ in range(45):
        midpoint = (low + high) / 2
        mass = 10**midpoint
        ratio = mass / 10**11.590
        below = 2 * .0351 * mass / (ratio**-1.376 + ratio**.608) < stellar
        low = np.where(below, midpoint, low)
        high = np.where(below, high, midpoint)
    return 10**((low + high) / 2)


def halo_speeds(stellar, radii, baryon_v2, projection):
    mass = mass200(stellar)
    x = .700 * mass / 1e12
    # Recipes from research/01_original/forty_halo.py. The Dutton-Maccio cross-
    # calibration keeps the same Moster inferred mass while changing c, h, f_DM.
    calibrations = [
        ('klypin_all', 6.60*x**-.110*(1+(x/2e6)**.4), .0704, 1-.0455/.272),
        ('klypin_relaxed', 6.90*x**-.090*(1+(x/5.5e5)**.4), .0704, 1-.0455/.272),
        ('dutton_maccio', 10**.905*(.671*mass/1e12)**-.101, .0671, 1-.049/.3175),
    ]

    def enclosed(x):
        return np.log1p(x) - x / (1+x)

    result = {}
    for name, concentration, hubble, dark_fraction in calibrations:
        r200 = (G*mass/(100*hubble**2))**(1/3)
        dark_v2 = G*dark_fraction*mass/radii * enclosed(concentration*radii/r200)/enclosed(concentration)
        result[name] = projection*np.sqrt(baryon_v2 + dark_v2)
    return result


def score_row(entry, catalog, rings, observer, forecast, eligibility, angles_row):
    g = entry['galaxy']
    rank = int(entry['draw_rank'])
    distance = float(catalog['d_mpc'])
    luminosity = float(catalog['L36_1e9_Lsun'])
    mass = 1e9*(.5*luminosity + .2*float(catalog['Lbulge_1e9_Lsun']))
    method = int(catalog['distance_method'])
    shared = .9/distance if method == 4 else .07 if method == 1 else 0.
    shared_stream = stream(0, 1 if method == 4 else 2)
    ds = positive_normal(stream(rank, 2), 1+shared*shared_stream.standard_normal(N),
                         np.sqrt(max(0, (float(catalog['e_d_mpc'])/distance)**2 - shared**2)))
    light = positive_normal(stream(rank, 3), np.ones(N), float(catalog['e_L36_1e9_Lsun'])/luminosity)
    sigma = 0.
    if observer.get('eFHI_Jy_kms') and observer['flux_treatment'].startswith('same'):
        sigma = float(observer['eFHI_Jy_kms'])/float(observer['FHI_Jy_kms'])
    gas = positive_normal(stream(rank, 4), np.ones(N), sigma)
    inclination = float(catalog['inclination_deg'])
    angle = accepted_angles(rank, float(eligibility['projected_axis_ratio']), inclination,
                            float(catalog['e_inc_deg']))
    weight = float(forecast['interpolation_weight'])
    radius = float(entry['R_kpc'])
    baryon_gas = baryon_stars = projection = 0.
    for lohi, w in [('lo', 1-weight), ('hi', weight)]:
        ring = rings[g, float(forecast[f'bracket_{lohi}_kpc'])]
        gas_v, disk_v, bulge_v = [float(ring[k]) for k in ('vgas_kms','vdisk_unit_kms','vbul_unit_kms')]
        baryon_gas += w*gas_v*abs(gas_v)
        baryon_stars += w*(.5*disk_v*abs(disk_v) + .7*bulge_v*abs(bulge_v))
        tilt = float(angles_row[f'gas_i_{lohi}_deg'])
        projection += w*np.abs(np.sin(np.deg2rad(tilt+angle-inclination)))/np.sin(np.deg2rad(tilt))

    nominal = halo_speeds(mass, radius, baryon_gas+baryon_stars, 1.)
    draws = halo_speeds(mass*light*ds**2, radius*ds, ds*(baryon_gas*gas+baryon_stars*light), projection)
    row = {'galaxy':g, 'contour':entry['contour'], 'draw_rank':rank, 'observed_kms':float(entry['observed_kms']),
           'nominal_set_kms':float(entry['nominal_SET_surface_kms']), 'propagated_set_kms':float(entry['SET_surface_kms'])}
    row.update({f'nominal_{model}_kms':float(value) for model,value in nominal.items()})
    row.update({f'propagated_{model}_kms':float(np.median(value)) for model,value in draws.items()})
    for version, archived in [('nominal', 'nominal_halo_kms'), ('propagated','survey_halo_kms')]:
        row[f'{version}_replay_difference_kms'] = row[f'{version}_klypin_all_kms']-float(entry[archived])
    return row


def scores(scored):
    report = {}
    for contour in ('25.5','26.5'):
        group = sorted([r for r in scored if r['contour']==contour],key=lambda r:r['draw_rank'])
        obs = np.array([r['observed_kms'] for r in group])
        boot = np.random.default_rng(202611181650).integers(len(group),size=(24000,len(group)))
        result = {}
        for version in ('nominal','propagated'):
            set_speeds = np.array([r[f'{version}_set_kms'] for r in group])
            set_error = 100*np.abs(set_speeds/obs-1)
            models = {'set_median_ape_pct':float(np.median(set_error))}
            for model in ('klypin_all','klypin_relaxed','dutton_maccio'):
                v = np.array([r[f'{version}_{model}_kms'] for r in group])
                error = 100*np.abs(v/obs-1)
                gap = np.median(set_error[boot],axis=1)-np.median(error[boot],axis=1)
                models[model] = {'median_ape_pct':float(np.median(error)), 'set_closer_count':int(np.sum(set_error<error)),
                                 'count':len(obs), 'set_minus_halo_median_gap_pp':float(np.median(set_error)-np.median(error)),
                                 'paired_bootstrap_gap_95_pp':np.quantile(gap,[.025,.975]).tolist()}
            result[version] = models
        report[contour] = result
    return report


def main(output):
    output.mkdir(parents=True, exist_ok=True)
    with (ROOT / 'data' / 'contour_predictions.csv').open() as file:
        c = list(csv.DictReader(file))
    with ZipFile(ROOT / 'source_replay.zip') as archived:
        cat = {r['galaxy']:r for r in rows(archived, 'work/forty_sample/inference_catalog.csv')}
        rings = {(r['galaxy'],float(r['r_kpc'])):r for r in rows(archived, 'work/forty_sample/inference_radii.csv')}
        eligibility = {(r['galaxy'],r['contour']):r for r in rows(archived, 'work/consensus_photometric/eligibility.csv')}
        proj = {(r['galaxy'],r['contour']):r for r in rows(archived, 'work/consensus_photometric/uncertainty_forecasts_preferred.csv')
                if r['model']=='halo' and r['case']=='fixed_contour'}
        ob = {r['galaxy']:r for r in rows(archived,'work/uncertainty_speeds/observer_inputs.csv')}
        fo = {(r['galaxy'],r['contour']):r for r in rows(archived,'work/consensus_photometric/forecasts.csv')}
    result=[]
    for r in c:
        g=r['galaxy']
        key=(g,r['contour'])
        result.append(score_row(r, cat[g], rings, ob.get(g,{}), fo[key], eligibility[key], proj[key]))
    report=scores(result)
    for version in ('nominal','propagated'):
        check=max(abs(r[f'{version}_replay_difference_kms']) for r in result)
        assert check < 1e-7,(version,check)
        report[f'{version}_maximum_archive_replay_difference_kms']=check
    with (output/'halo_calibration_comparison_by_galaxy.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,list(result[0]))
        w.writeheader()
        w.writerows(result)
    with (output/'halo_calibration_comparison.json').open('w') as f:
        json.dump(report,f,indent=2)
        f.write('\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT/'recomputed')
    main(parser.parse_args().output)
