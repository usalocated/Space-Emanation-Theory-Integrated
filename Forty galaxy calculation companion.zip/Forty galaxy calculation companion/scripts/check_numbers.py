"""Check the sample, coverage, and headline statistics against archived galaxy rows."""
import csv
import io
import math
import random
from collections import Counter
from pathlib import Path
from statistics import median
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]


def read(name):
    with (ROOT / 'data' / name).open() as f:
        return list(csv.DictReader(f))


frame = read('catalogue_eligibility.csv')
eligible = sorted([r for r in frame if r['catalog_gate'] == 'eligible_before_photometry'], key=lambda r: r['galaxy'])
assert len(frame) == 175 and len(eligible) == 123
random.Random(20261118).shuffle(eligible)
photo = [r for r in eligible if r['eligible_geometry'] == '1']
register = read('primary_boundary_all_40.csv')
assert len(photo) == 59 and [r['galaxy'] for r in photo[:40]] == [r['galaxy'] for r in register]

pairs = read('contour_predictions.csv')
primary = [r for r in pairs if r['contour'] == '25.5']
assert len(primary) == 30 and len(pairs) == 51
data = {(r['galaxy'], r['contour']): r for r in pairs}
statuses = {'Scored': 'scored', 'Velocity coverage': 'outside_kinematic_range',
            'Shape': 'unphysical_central_oblate', 'Contour': 'missing_catalog_contour'}

with ZipFile(ROOT / 'source_replay.zip') as z:
    def archived(name):
        return list(csv.DictReader(io.StringIO(z.read(name).decode())))

    boundaries = {(r['galaxy'], r['contour']): r for r in archived('work/consensus_photometric/eligibility.csv')}
    scores = archived('reference/consensus_photometric/uncertainty_scores_preferred.csv')

for r in register:
    meta = boundaries[r['galaxy'], '25.5']
    assert meta['status'] == statuses[r['status']]
    if r['status'] == 'Scored':
        values = data[r['galaxy'], '25.5']
        for left, right in [('observed_kms','observed_kms'),('set_kms','SET_surface_kms'),
                            ('primary_halo_kms','survey_halo_kms'),('radius_kpc','R_kpc')]:
            assert math.isclose(float(r[left]), float(values[right]), rel_tol=1e-12)
assert Counter(r['status'] for r in register) == {'Scored':30,'Velocity coverage':6,'Shape':2,'Contour':2}

models = {'gr':'baryonic_GR_kms','halo':'survey_halo_kms','uniform':'SET_uniform_kms',
          'isotropic_surface':'SET_surface_kms','isotropic_gradient':'SET_gradient_kms'}
for r in scores:
    if r['case'] == 'fixed_contour' and r['contour'] in ('25.5','26.5'):
        result = data[r['galaxy'],r['contour']]
        assert math.isclose(float(r['median']),float(result[models[r['model']]]),rel_tol=1e-12)
        assert math.isclose(float(r['observed_kms']),float(result['observed_kms']),rel_tol=1e-12)

def err(model):
    return [100 * abs(float(r[model])/float(r['observed_kms']) - 1) for r in primary]

print('Published contour: median absolute percentage errors across 30 galaxies')
for k in models.values():
    print(f'{k:25} {median(err(k)):.6f}')
s = err('SET_surface_kms')
h = err('survey_halo_kms')
old = [float(r['prior_fixed_outline_SET_ape_pct']) for r in primary]
assert round(median(s),2) == 10.44 and round(median(h),2) == 13.70
assert sum(i < j for i,j in zip(s,h)) == 16
assert sum(i < j for i,j in zip(s,old)) == 24
assert round(median(old),2) == 16.16
print('Old to primary matched SET median:',round(median(old),4),'to',round(median(s),4))
print('24/30 improved over original boundary; SET closer than the primary halo in 16/30.')
print('All source-score links, sample rows, and primary headline checks passed.')
