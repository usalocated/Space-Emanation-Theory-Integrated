"""Generate the paper's empirical figure from the published packet's tables."""
import argparse
import csv
import io
import os
import sys
from pathlib import Path
import tempfile

parser = argparse.ArgumentParser()
ROOT = Path(__file__).resolve().parents[1]
parser.add_argument('output', type=Path)
parser.add_argument('--matplotlib-vendor', type=Path)
args = parser.parse_args()
if args.matplotlib_vendor:
    sys.path.insert(0, str(args.matplotlib_vendor.resolve()))
os.environ.setdefault('MPLCONFIGDIR', str(Path(tempfile.gettempdir()) / 'set-galaxies-mpl-cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np

def rows(name):
    with (ROOT/'data'/name).open() as file:
        return list(csv.DictReader(file))

def number(row, key):
    return float(row[key])

ranked = sorted((r for r in rows('contour_predictions.csv') if r['contour']=='25.5'), key=lambda r:int(r['draw_rank']))
endpoints = rows('location_scores_pct.csv')
bootstrap = next(r for r in rows('location_bootstrap.csv') if r['selection_contour']=='25.5' and r['scored_contour']=='25.5' and r['case']=='fixed_contour' and r['subset']=='matched')
assert len(ranked)==30 and len({r['galaxy'] for r in ranked})==30
rank = np.array([int(r['draw_rank']) for r in ranked])
def errors(prediction, published):
    calculated = np.array([100*abs(number(r,prediction)/number(r,'observed_kms')-1) for r in ranked])
    np.testing.assert_allclose(calculated, [number(r,published) for r in ranked],rtol=0,atol=1e-11)
    return calculated
eset=errors('SET_surface_kms','SET_surface_ape_pct')
ehalo=errors('survey_halo_kms','survey_halo_ape_pct')
ebar=errors('baryonic_GR_kms','baryonic_GR_ape_pct')
assert np.sum(eset < ehalo)==16
assert [r['location'] for r in endpoints]==['original','25.5','26.5','last']
assert [int(r['n']) for r in endpoints]==[40,30,21,40]
for e, key in ((eset,'SET_surface'),(ehalo,'population_halo'),(ebar,'GR_baryons')):
    np.testing.assert_allclose(np.median(e),number(endpoints[1],key),rtol=0,atol=1e-11)
np.testing.assert_allclose(np.median(eset)-np.median(ehalo),number(bootstrap,'gap_set_minus_halo'),rtol=0,atol=1e-11)

colors = dict(SET_surface='#0B686B',population_halo='#A44324',GR_baryons='#485664')
shapes = dict(SET_surface='o',population_halo='s',GR_baryons='D')
labels = dict(SET_surface='SET boundary', population_halo='Baryons + fixed NFW halo',GR_baryons='Baryons alone')
ink='#203039'
grid='#DEE3E4'
plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42,'svg.fonttype':'none','font.size':8.2,'axes.labelcolor':ink,'text.color':ink,'axes.labelsize':8.8,
                     'xtick.color':ink,'ytick.color':ink,'axes.edgecolor':'#8B979A','axes.linewidth':.65,
                     'axes.titleweight':'bold','axes.titlesize':10.5,'axes.unicode_minus':True})
fig=plt.figure(figsize=(7,5.58),facecolor='white')
top=fig.add_axes([.099,.538,.869,.327]);bot=fig.add_axes([.280,.102,.627,.279])
for ax in (top,bot):
    ax.spines[['top','right']].set_visible(False)
    ax.tick_params(length=2.5,width=.60)
    ax.set_axisbelow(True)
def dot(ax, x,y, key, size):
    return ax.scatter(x,y, s=size,marker=shapes[key],facecolor=colors[key],edgecolor='white',linewidth=.55,zorder=4)
legend=[Line2D([],[],ls='',marker=shapes[k],mfc=colors[k],mec='none',ms=6,label=labels[k]) for k in labels]
fig.legend(handles=legend,loc='upper center',bbox_to_anchor=(.50, .999),ncol=3,frameon=False,handletextpad=.2,columnspacing=1.7,fontsize=8.5)
fig.text(.018,.901,'A',fontsize=11,weight='bold')
fig.text(.069,.901,'Individual speed errors at the 25.5 stellar contour',fontsize=10.5,weight='bold')

# Offset the two markers horizontally by a small sub-rank so an exact tie remains visible.
for x,s,h in zip(rank,eset,ehalo):
    top.plot([x-.13,x+.13],[s,h],lw=.85,color='#A9B3B6',zorder=2)
dot(top,rank-.13,eset,'SET_surface',24);dot(top,rank+.13,ehalo,'population_halo',21)
top.set_xlim(-.20,41.15);top.set_ylim(-3.2,82);top.set_yticks([0,20,40,60,80]);top.set_xticks([1,5,10,15,20,25,30,35,40])
top.grid(axis='y',color=grid,linewidth=.65)
top.set_ylabel('Absolute speed error (%)',labelpad=3)
top.set_xlabel('Galaxy number in the forty-object draw', labelpad=3)
# Identify the worked example and the largest measured SET residual without covering data.
i=list(rank).index(3)
top.annotate('UGC 6446',xy=(3+.15,ehalo[i]),xytext=(3.8,46),size=7.5,color='#394950',
    arrowprops={'arrowstyle':'-','color':'#89969A','lw':.65,'shrinkA':1.8,'shrinkB':3.2})
i=list(rank).index(39)
top.annotate('UGC 7125',xy=(39-.15,eset[i]),xytext=(31.8,71.6),size=7.5,color='#394950',
    arrowprops={'arrowstyle':'-','color':'#89969A','lw':.65,'shrinkA':1.8,'shrinkB':3.2})

fig.text(.018,.417,'B',fontsize=11,weight='bold')
fig.text(.069,.417,'Median speed error at each evaluation radius',fontsize=10.5,weight='bold')
names=['Earlier stellar ring  (40)','25.5 contour  (30)','26.5 contour  (21)','Last measured ring  (40)']
bot.set_yticks(range(4),names,fontsize=8.1);bot.tick_params(axis='y',length=0,pad=8)
bot.set_xlim(0,58);bot.set_xticks([0,10,20,30,40,50]);bot.set_ylim(3.48,-.47)
bot.set_xlabel('Median absolute speed error (%)',labelpad=3);bot.grid(axis='x',color=grid,linewidth=.65)
bot.axhspan(.57,1.43,color='#F1F5F4',zorder=0)
for i,r in enumerate(endpoints):
    for k,shift in [('SET_surface',-.14),('population_halo',.14),('GR_baryons',0.)]:
        val=number(r,k);y=i+shift
        dot(bot,val,y,k,24)
        if i==1 and k in ('SET_surface','population_halo'):
            bot.text(val+1.12, y, f'{val:.2f}',ha='left',va='center',size=7.4,color=colors[k],weight='bold',bbox=dict(facecolor='#F1F5F4',edgecolor='none',pad=.25))
        elif i==1:
            bot.text(val+1.2, y, f'{val:.2f}',ha='left',va='center',size=7.4,color=colors[k],weight='bold',bbox=dict(facecolor='#F1F5F4',edgecolor='none',pad=.25))
bot.spines['left'].set_visible(False)
args.output.mkdir(parents=True,exist_ok=True)
for ext in ('png','pdf'):
    fig.savefig(args.output / ('boundary_results.'+ext),dpi=360,facecolor='white')
fig.savefig(args.output/'preview.png',dpi=150,facecolor='white')
print('Shown rank count:',len(rank),'error maxima:',eset.max(),ehalo.max(),'fixed halo vs SET:',np.median(ehalo),np.median(eset),'SET closer:',int((eset<ehalo).sum()))
