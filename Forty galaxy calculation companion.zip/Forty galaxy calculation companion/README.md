# Forty galaxies · calculation companion

This archive follows the forty-object draw from galaxy selection through the comparison at a common 3.6 μm stellar contour. Start with `data/primary_boundary_all_40.csv` for the full register. Each galaxy has its draw number, name and evaluation status. At the primary 25.5 AB mag arcsec⁻² contour, 30 galaxies have an observed speed and a prediction. Six lack bracketing rotation data, two lack a reported contour and two have an inadmissible central oblate deprojection. All 40 enter the original-boundary and last-ring comparisons. The 21 galaxies at the 26.5 contour are a separately scored set.

For each scored galaxy the absolute speed error is `100 × |predicted / observed − 1|`. The headline statistic is the sample median of these errors. Predicted speeds in this statistic are medians over uncertainties in the inputs. Nominal speeds evaluated at the tabulated central inputs are also available. At the primary contour the SET two-moment calculation gives 10.44%, uniform loading gives 9.50%, three fixed baryons-plus-NFW calculations give 11.69–13.70%, and baryons alone give 42.20%. The paired bootstrap interval for each difference of sample medians is provided with its calibration.

## Quick numerical checks

From the extracted companion directory, using Python 3.12, run:

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/check_numbers.py
python scripts/replay_halos.py --output recomputed
python area/area_decomposition.py --out recomputed/area
python scripts/plot_boundary.py recomputed/figures
```

`check_numbers.py` reproduces the seeded draw, checks all 40 statuses, matches each error-input pair to the original calculation tables and reports the speed comparisons. `replay_halos.py` recalculates three fixed NFW calibrations, propagates the same source uncertainties, and reports nominal and propagated medians plus paired bootstrap intervals. Compare its CSV and JSON directly with `reference/`. `area_decomposition.py` reconstructs the uniform geometric multiplier and concentration correction from central source inputs without using observed speeds. Its CSV and JSON references are in `area/`. `plot_boundary.py` rebuilds the speed-error figure. A reference image is provided in `reference/`. The numerical draw checks and area calculation run with the Python standard library. NumPy is needed for the halo and full SET replays; Matplotlib is needed only for the figure.

## Full SET replay from the source inputs

```sh
python -m zipfile -e source_replay.zip recomputed/source_replay
(cd recomputed/source_replay && python reproduce.py --verify-only && python reproduce.py)
```

`source_replay.zip` is the unmodified, 16,935,685-byte research archive. Its SHA-256 is `f1e41f652ce9310b27b6a18286ac979f363de7f9110a78a29a98c69d15df0e13`. The full replay verifies 442 archived files and recomputes the original source, survey-contour, uncertainty, matched-location and coverage tables offline. The nested README documents the mass model, the phase-by-phase replay, observational provenance and limits of the input uncertainties. `data/contour_predictions.csv` contains all 51 qualifying galaxy–contour records. `data/location_scores_pct.csv` and `data/location_bootstrap.csv` provide the comparisons used in the figure. `data/catalogue_eligibility.csv` records the initial catalogue screens. `data/spitzer_mosaic_sources.csv` provides public observational image URLs and file hashes.

The reference tables, all numerical checks and the full archived replay were verified with Python 3.12.14 and NumPy 2.3.5. The figure was checked against its reference image with Matplotlib 3.11.1. `SHA256SUMS.txt` supplies hashes for the distributed files. On macOS, run `shasum -a 256 -c SHA256SUMS.txt` in the extracted directory.

## Sources

- The kinematic data, catalogue distances, luminosities and baryonic rotation components are from [Lelli, McGaugh & Schombert, SPARC (2016)](https://arxiv.org/abs/1606.09251).
- The infrared stellar contours are from [Muñoz-Mateos et al., S⁴G surface photometry (2015)](https://arxiv.org/abs/1505.03534). The survey mosaics and masks are available from [NASA/IPAC IRSA](https://irsa.ipac.caltech.edu/data/SPITZER/S4G/overview.html).
- The individual neutral-hydrogen profiles and their provenance appear in `work/consensus_review/ledger.csv` inside the source replay. In the worked UGC 6446 example the profile was digitized from the original [Verheijen thesis, page 122 of the PDF](https://pure.rug.nl/ws/portalfiles/portal/3235445/thesis.pdf#page=122).
- The halo comparisons combine the [Navarro–Frenk–White profile](https://arxiv.org/abs/astro-ph/9611107) with [Moster, Naab & White’s stellar–halo mass relation](https://arxiv.org/abs/1205.5807) and fixed concentrations from [Klypin et al.](https://arxiv.org/abs/1411.4001) or [Dutton & Macciò](https://arxiv.org/abs/1402.7073). The latter is a cross-calibration retaining the common Moster halo mass. The constants and projection conventions are explicit in `scripts/replay_halos.py`.
