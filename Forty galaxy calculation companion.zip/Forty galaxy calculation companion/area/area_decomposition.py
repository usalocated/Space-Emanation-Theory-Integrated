"""Reproduce the geometric and loading factors of the 25.5 stellar-boundary speed.

Standard-library Python. Supply either RD8x handoff ZIP, or use the adjacent
compact extract of the same source inputs. No observed rotation speed is read.
"""
import argparse
import csv
import io
import json
import math
from pathlib import Path
from statistics import median
from zipfile import ZipFile


BASE = "research/04_measured_gas/tables/"
ELIGIBILITY = BASE + "consensus_photometric/eligibility.csv"
FORECASTS = BASE + "consensus_photometric/uncertainty_forecasts_preferred.csv"
SOURCES = BASE + "shape_law/source_chain.csv"
GM_SUN = 1.3271244e20       # m^3/s^2, nominal solar gravitational parameter used by the archived shell solver
KPC = 3.085677581491367e19  # m
C_KMS = 299792.458


def read_table(archive, name):
    with archive.open(name) as stream:
        return list(csv.DictReader(io.TextIOWrapper(stream, encoding="utf-8")))


def extract_inputs(archive_path):
    with ZipFile(archive_path) as archive:
        eligible = read_table(archive, ELIGIBILITY)
        forecasts = read_table(archive, FORECASTS)
        source_rows = read_table(archive, SOURCES)
    sources = {row["galaxy"]: row for row in source_rows}
    central = {(row["galaxy"], row["model"]): float(row["central"])
               for row in forecasts
               if row["case"] == "fixed_contour" and row["contour"] == "25.5"}
    rows = []
    for row in eligible:
        if row["contour"] != "25.5" or row["status"] != "scored":
            continue
        name = row["galaxy"]
        rows.append({
            "draw_rank": int(sources[name]["draw_rank"]), "galaxy": name,
            "Rb_kpc": float(row["radius_kpc"]),
            "Mbar_Msun": float(sources[name]["Mbar_global_Msun"]),
            "projected_ratio": float(row["projected_axis_ratio"]),
            "inclination_deg": float(row["inclination_deg"]),
            "nominal_eta_squared": float(row["q_squared"]),
            "nominal_uniform_kms": central[name, "uniform"],
            "nominal_surface_kms": central[name, "isotropic_surface"],
        })
    rows.sort(key=lambda row: row["draw_rank"])
    return rows


def write_csv(path, records):
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=records[0].keys())
        writer.writeheader()
        writer.writerows(records)


def calculate(row):
    q2 = float(row["nominal_eta_squared"])
    projected_ratio = float(row["projected_ratio"])
    inclination = math.radians(float(row["inclination_deg"]))
    q2_check = (projected_ratio**2 - math.cos(inclination)**2) / math.sin(inclination)**2
    assert math.isclose(q2, q2_check, rel_tol=1e-10, abs_tol=1e-14)
    assert 0 < q2 <= 1
    eccentricity = math.sqrt(1 - q2)
    f_geom = 2 * (1 + q2 * math.atanh(eccentricity)/eccentricity) if eccentricity else 4
    v_sphere = math.sqrt(GM_SUN * float(row["Mbar_Msun"]) / (float(row["Rb_kpc"]) * KPC)) / 1000
    uniform_speed = float(row["nominal_uniform_kms"])
    surface_speed = float(row["nominal_surface_kms"])
    shape_factor = 4 / f_geom
    loading_factor = surface_speed / uniform_speed
    total_factor = shape_factor * loading_factor
    # Independent use of Mbar, Rb and the analytic spheroidal area.
    assert math.isclose(v_sphere * shape_factor, uniform_speed, rel_tol=2e-8)
    assert math.isclose(v_sphere * total_factor, surface_speed, rel_tol=2e-8)
    assert loading_factor >= 1 - 1e-12
    return {
        "draw_rank": int(row["draw_rank"]), "galaxy": row["galaxy"],
        "Rb_kpc": float(row["Rb_kpc"]), "Mbar_Msun": float(row["Mbar_Msun"]),
        "nominal_eta": math.sqrt(q2), "f_geom": f_geom,
        "v_spherical_reference_kms": v_sphere, "nominal_uniform_kms": uniform_speed,
        "nominal_surface_kms": surface_speed, "shape_speed_factor": shape_factor,
        "loading_speed_factor": loading_factor, "total_speed_factor": total_factor,
        "area_eff_over_sphere": 1 / total_factor,
        "effective_S_squared_over_c_squared": 2 * (surface_speed / C_KMS)**2,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--archive", type=Path, help="RD8x illustrated or complete research ZIP")
    group.add_argument("--inputs", type=Path, help="Compact input CSV, defaults to the copy beside this script")
    parser.add_argument("--out", type=Path, default=Path.cwd())
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    if args.archive:
        rows = extract_inputs(args.archive)
        write_csv(args.out / "inputs_25p5.csv", rows)
    else:
        path = args.inputs or Path(__file__).with_name("inputs_25p5.csv")
        with path.open(encoding="utf-8") as file:
            rows = list(csv.DictReader(file))
    assert len(rows) == len({row["galaxy"] for row in rows}) == 30
    results = [calculate(row) for row in rows]
    write_csv(args.out / "area_factors_25p5.csv", results)
    summary = {}
    for key in ("shape_speed_factor", "loading_speed_factor", "total_speed_factor",
                "area_eff_over_sphere", "effective_S_squared_over_c_squared"):
        values = [row[key] for row in results]
        summary[key] = {"min": min(values), "median": median(values), "max": max(values)}
    (args.out / "area_factors_25p5_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
