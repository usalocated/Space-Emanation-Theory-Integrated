"""Portable numerical reproduction of retained RD6 benchmarks, without fitting.

Run from any directory: python verify.py
Frozen galaxy source inputs and frozen SN15 contrast covariance are inputs.
Union2.1 contrasts/covariance are rebuilt from released rows plus the fixed ledger.
Original20 uncertainty quantiles are frozen; additional42 draws are regenerated.
"""
from pathlib import Path
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import json, math, csv, hashlib, platform, argparse
import numpy as np
import scipy
from scipy.integrate import quad, solve_ivp
from scipy.optimize import brentq
P=Path(__file__).resolve().parent
OUT=P/'generated';OUT.mkdir(exist_ok=True)
def read(s):return json.loads((P/s).read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def csvwrite(name,rows):
 with (OUT/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def near(a,b,atol=1e-9,rtol=1e-10):
 assert np.allclose(a,b,atol=atol,rtol=rtol),(np.max(np.abs(np.asarray(a)-b)),a,b)
K=read('inputs/constants.json');c=K['c_m_s'];G=K['G_SI']
checks={}
# Source-copy and packaged-file integrity checks run before numerical work.
copied=read('provenance/COPIED-SOURCE-MAP.json')
for d in copied:
 assert hashlib.sha256((P/d['package_path']).read_bytes()).hexdigest()==d['sha256'],d['package_path']
if (P/'MANIFEST-SHA256.json').exists():
 for d in read('MANIFEST-SHA256.json')['files']:
  assert hashlib.sha256((P/d['path']).read_bytes()).hexdigest()==d['sha256'],d['path']
checks['integrity']={'copied_sources_verified':len(copied),'all_packaged_frozen_hashes_verified':(P/'MANIFEST-SHA256.json').exists()}
# Mercury: direct leading formula plus the exact turning-radius quadrature.
m=K['Mercury'];p=m['a_au']*m['au_m']*(1-m['e']**2);delta=m['GM_m3_s2']/(p*c*c)
adv=6*math.pi*delta;asec=adv*180/math.pi*3600
exact=2*quad(lambda chi:math.expm1(-.5*math.log1p(-delta*(6+2*m['e']*math.cos(chi)))),0,math.pi,epsabs=1e-17,epsrel=1e-12)[0]
checks['perihelion']={'p_m':p,'GM_over_pc2':delta,'leading_radian_per_orbit':adv,'leading_arcsec_per_orbit':asec,'leading_arcsec_per_Julian_century':asec*m['julian_century_days']/m['sidereal_period_days'],'exact_turning_radius_advance_radian':exact,'exact_minus_leading_radian':exact-adv,'scope':'Spherical test-body benchmark under the selected exterior. No planetary perturbation or source-multipole fit.'}
near(asec,0.1035173023,atol=1e-10);near(checks['perihelion']['leading_arcsec_per_Julian_century'],42.98070,atol=1e-5)
assert exact>adv
# Galaxies: recompute Q,area,S and speed from every frozen M,R,f; never use observed speed to predict.
gal=read('inputs/galaxy/expanded83.json');rows=[];Gastro=K['G_kpc_km2_s2_Msun']
for r in gal['displayed_rows']:
 M=r['Mbar_Msun']*K['galaxy_Msun_kg'];R=r['R_kpc']*K['galaxy_kpc_m'];f=r['f_image']
 Q=4*math.pi*math.sqrt(2*G*M*R**3);area=f*math.pi*R*R;S=Q/area;v=S/math.sqrt(2)/1000
 near(v,r['v_SET_km_s'],atol=2e-10);near(v,4/f*math.sqrt(Gastro*r['Mbar_Msun']/r['R_kpc']),atol=2e-10)
 residual=100*(v/r['v_observed_km_s']-1);near(residual,r['residual_pct'],atol=2e-10)
 rows.append(dict(name=r['name'],R_kpc=r['R_kpc'],Mbar_Msun=r['Mbar_Msun'],f_image=f,Q_m3_s=Q,A_image_m2=area,S_km_s=S/1000,v_SET_km_s=v,v_observed_km_s=r['v_observed_km_s'],recorded_velocity_range_km_s=r['velocity_range_km_s'],v_Newton_km_s=r['v_Newton_km_s'],residual_pct=residual))
assert len(rows)==len({r['name'] for r in rows})==83
median=float(np.median([abs(r['residual_pct']) for r in rows]));near(median,gal['summary']['median_absolute_difference_displayed_pct'])
# Rebuild all available Newtonian velocities from their recorded signed components.
components={}
for r in read('inputs/galaxy/original20.json')['rows']:
 if r.get('v_Newton_kms') is not None:components[r['name']]=math.sqrt(sum(r['signed_component_v2_kms2'].values()))
for r in [read('inputs/galaxy/NGC3972-source.json')]+[r for f in sorted((P/'inputs/galaxy/new-source-records').glob('*.json')) for r in json.loads(f.read_text())['rows']]:
 if r.get('v_Newton_km_s') is not None and 'gas_component_km_s' in r:
  values=[r['gas_component_km_s'],r['disk_component_unitML_km_s'],r['bulge_component_unitML_km_s']]
  v2=values[0]*abs(values[0])+.5*values[1]*abs(values[1])+.7*values[2]*abs(values[2])
  components[r['name']]=math.sqrt(v2)
newton=[r for r in rows if r['v_Newton_km_s'] is not None]
for r in newton:near(components[r['name']],r['v_Newton_km_s'],atol=1e-9)
assert len(newton)==26
checks['galaxies']={'recomputed_rows':83,'Newtonian_component_checks':len(newton),'median_absolute_speed_difference_percent':median,'new_eligible_calculations':len(gal['complete_new_calculated_screen']),'new_displayed_examples':len(gal['additional_rows']),'prediction_inputs':'Frozen baryonic mass,comparison radius,image coefficient. Observed velocities are used only after prediction to calculate residuals.'}
csvwrite('galaxy83-recalculated.csv',rows)
# Recompute42 uncertainty draws. The original20 source quantiles stay as archived.
u=read('inputs/galaxy/source-uncertainty62.json');urr={r['name']:r for r in u['rows']};gr={r['name']:r for r in rows}
qkeys=['p025','p16','median','p84','p975'];maxerr=0.
for z in sorted(u['new_input_ledger'],key=lambda r:r['name']):
 r=urr[z['name']];N=r['draws'];rng=np.random.default_rng(r['seed'])
 D=rng.normal(z['D'],z['eD'] or 0,N);proj=rng.normal(z['p'],z['ep'],N)
 ideg=rng.normal(z['inc'],z['einc'] or 0,N)%180;ideg=np.minimum(ideg,180-ideg);inc=np.deg2rad(ideg)
 t=(proj*proj-np.cos(inc)**2)/np.maximum(np.sin(inc)**2,1e-300)
 sd=rng.normal(0,z['estar'] or 0,N);sf=10**(-.4*sd) if z['star_kind']=='magnitude' else 1+sd
 gd=rng.normal(0,z['egas'] or 0,N);gf=10**(-.4*gd) if z['gas_kind']=='magnitude' else 1+gd
 good=(proj>0)&(proj<=1)&(inc>1e-8)&(t>0)&(t<=1)&(D>0)&(sf>0)&(gf>0)
 e=np.sqrt(1-t[good]);kernel=np.divide(np.arcsinh(e/np.sqrt(t[good])),e,out=np.ones_like(e),where=e>1e-10);f=2*(1+t[good]*kernel)
 d=D[good]/z['D'];flux=(z['star']*sf[good]+z['gas']*gf[good])/(z['star']+z['gas'])
 v=r['v_SET_km_s']*gr[z['name']]['f_image']/f*np.sqrt(d*flux)
 obs=r['v_obs_km_s']*(math.sin(math.radians(z['inc']))/np.sin(inc[good]) if z['shared_inclination'] else np.ones(good.sum()))
 quant=np.quantile(v/obs,[.025,.16,.5,.84,.975]);expected=np.array([r['ratio_source_only'][k] for k in qkeys]);near(quant,expected,atol=3e-12);maxerr=max(maxerr,float(max(abs(quant-expected))))
 assert int(good.sum())==r['accepted_draws']
overlaps={}
for label,lo,hi in [('source68_overlaps_obs_range','p16','p84'),('source95_overlaps_obs_range','p025','p975')]:
 count=0
 for r in u['rows']:
  q=r['ratio_source_only'];er=r['obs_range_km_s']/r['v_obs_km_s'];match=q[lo]<=1+er and q[hi]>=1-er
  assert bool(match)==r[label];count+=match
 overlaps[label]=int(count);assert count==u['summary'][label]
checks['source_uncertainty']={'rows_checked':62,'original20_quantiles':'Frozen archived source-only quantiles; original Monte Carlo is not repeated by this runner.','new42_draws_regenerated':42,'draws_per_new_object':250000,'max_quantile_difference':maxerr,**overlaps}
# Independent separated-variable luminosity history from unchanged M0,R0.
M=K['cosmology_M0_kg'];R=K['cosmology_R0_m'];u0=3*G*M/(R*c*c);y0=math.sqrt(u0/(1-u0));b=math.sqrt(6)
def F(y):return (math.log1p(y*y)+2*b*math.atan(y)-2*math.log(b-y))/7
F0=F(y0);zmax=math.expm1(F0-F(0))
def distance(z):
 if z==0:return 0.
 assert 0<z<zmax
 y=brentq(lambda yy:F0-F(yy)-math.log1p(z),0,y0,xtol=5e-15,rtol=1e-14)
 return (1+z)*quad(lambda t:2*math.sqrt(1+y0*y0)*math.exp(-.5*(F0-F(t)))/((1+t*t)**1.5*(b-t)),y,y0,epsabs=2e-13,epsrel=2e-13)[0]
def distances(z):return np.array([distance(float(zz)) for zz in z])
def ode(z,state):
 y,dc=state;E=(1+z)**1.5*math.sqrt(1+y*y)/math.sqrt(1+y0*y0)
 return [-(1+y*y)*(b-y)/(2*(1+z)),1/E]
sol=solve_ivp(ode,[0,zmax],[y0,0],rtol=2e-12,atol=2e-13,dense_output=True)
grid=np.linspace(0,zmax*.999,100);analytic=distances(grid);direct=(1+grid)*sol.sol(grid)[1]
near(analytic,direct,atol=3e-10)
checks['source_history']={'u0':u0,'alpha0':math.sqrt(1-u0),'zmax':zmax,'max_analytic_vs_ODE_dimensionless_distance':float(max(abs(analytic-direct))),'fitted_inputs':0,'history':'ln(1+z)=F(y0)-F(y), F=[ln(1+y^2)+2sqrt(6)atan(y)-2ln(sqrt(6)-y)]/7'}
# Fifteen original groups: rebuild predictions from every object redshift.
sn15={};table=[];expected=read('expected/sn15-verification.json')
for name,fn in [('Pantheon+','pantheonplus'),('DES-Dovekie','des-dovekie')]:
 d=np.load(P/'inputs/sn15'/f'{fn}.npz');z=d['z'];zh=d['zHEL'];L=d['L'];mag=d['observed'];C=d['covariance']
 assert max(abs(L.sum(axis=1)))<1e-13
 base=2*(1+zh)*(1-(1+z)**-.5);trial=distances(z)*(1+zh)/(1+z)
 obs=L@(mag-5*np.log10(base));pred=L@(5*np.log10(trial/base));res=obs-pred
 bo,bp=10**(-.4*obs),10**(-.4*pred)
 exp=expected['catalogues'][name];near(bo,[r['observed'] for r in exp['rows']],atol=2e-11)
 near(bp,[r['central_source_clock_prediction'] for r in exp['rows']],atol=2e-10)
 chi0=float(obs@np.linalg.solve(C,obs));chi=float(res@np.linalg.solve(C,res));near(chi,exp['chi2_SET'],atol=2e-7)
 e0=100*(1/bo-1);e1=100*(bp/bo-1)
 sn15[name]={'groups':len(L),'chi2_initial':chi0,'chi2_SET':chi,'median_absolute_initial_percent':float(np.median(abs(e0))),'median_absolute_SET_percent':float(np.median(abs(e1))),'improved':int(np.sum(abs(e1)<abs(e0))),'within_marginal_1sigma':int(np.sum(abs(res)<=np.sqrt(np.diag(C))))}
 for i,r in enumerate(exp['rows']):table.append({'catalogue':name,'group':i,'z_mean':r['z_mean'],'observed_relative_brightness':float(bo[i]),'SET_relative_brightness':float(bp[i]),'residual_mag':float(res[i]),'sigma_mag':float(math.sqrt(C[i,i]))})
checks['supernova15']=sn15;csvwrite('supernova15-recalculated.csv',table)
# Union2.1: source rows and complete released covariance, frozen membership only.
U=P/'inputs/union21';raw=[line.split() for line in (U/'union21-mu.txt').read_text().splitlines() if line.strip() and not line.startswith('#')]
ids=np.array([r[0] for r in raw]);z=np.array([float(r[1]) for r in raw]);mu=np.array([float(r[2]) for r in raw]);Craw=np.loadtxt(U/'union21-cov-statsys.txt')
ledger=read('inputs/union21/union21-all580-overlap-ledger-strict.json');ix=np.array([r['union_index'] for r in ledger if r['included_strict_unseen']],int)
frozen=np.load(U/'union21-strict-unseen.npz');assert np.array_equal(ix,frozen['original_index'])
assert np.array_equal(Craw[np.ix_(ix,ix)],frozen['covariance']);assert np.array_equal(mu[ix],frozen['mu']);assert np.array_equal(z[ix],frozen['z']);assert np.array_equal(ids[ix],frozen['CID'])
ids,z,mu,C=ids[ix],z[ix],mu[ix],Craw[np.ix_(ix,ix)]
anchor=(z>.025)&(z<.1);wa=np.zeros(len(z));wa[anchor]=1/np.diag(C)[anchor];wa/=wa.sum()
bins=[.1,.2,.35,.5,.65,.8,1.,1.3,2.4];weights=[];meta=[]
for lo,hi in zip(bins[:-1],bins[1:]):
 mask=(z>=lo)&(z<hi)
 if not mask.any():continue
 w=np.zeros(len(z));w[mask]=1/np.diag(C)[mask];w/=w.sum();weights.append(w-wa);meta.append((lo,hi,int(mask.sum()),float(w@z)))
L=np.array(weights);targets=(z>=bins[0])&(z<bins[-1]);ti=np.flatnonzero(targets);PP=np.eye(len(z))[ti]-wa[None,:]
base=2*(1+z)*(1-(1+z)**-.5);obs=mu-5*np.log10(base);pred=5*np.log10(distances(z)/base)
Cg=L@C@L.T;Ci=PP@C@PP.T;og,pg=L@obs,L@pred;oi,pi=PP@obs,PP@pred
archive=read('expected/union21-results.json');aa=np.load(P/'expected/union21-contrast-arrays.npz')
for own,key in [(L,'L'),(PP,'P'),(Cg,'covariance_groups'),(Ci,'covariance_individual'),(obs,'observed_delta'),(pred,'predicted_delta')]:near(own,aa[key],atol=2e-9)
def stat(o,p,C):return {'chi2_initial':float(o@np.linalg.solve(C,o)),'chi2_SET':float((o-p)@np.linalg.solve(C,o-p)),'n':len(o)}
ug=stat(og,pg,Cg);ui=stat(oi,pi,Ci)
for name,ours in [('grouped',ug),('individual',ui)]:
 near(ours['chi2_initial'],archive[name]['baseline']['chi2'],atol=3e-7);near(ours['chi2_SET'],archive[name]['SET']['chi2'],atol=3e-7)
assert len(ti)==260 and anchor.sum()==23 and len(L)==7
checks['union21']={'released_rows':580,'frozen_retained_rows':len(ix),'targets':len(ti),'reference_objects':int(anchor.sum()),'groups':ug,'individual':ui,'raw_covariance_rebuilt':True,'intercept_or_parameters_fitted':False,'grouped_and_individual_are_same_data':True}
individual=[{'CID':ids[j],'z':float(z[j]),'observed_delta_mag':float(oi[k]),'predicted_delta_mag':float(pi[k]),'residual_mag':float(oi[k]-pi[k]),'sigma_mag':float(math.sqrt(Ci[k,k]))} for k,j in enumerate(ti)]
csvwrite('union21-260-recalculated.csv',individual)
np.savez_compressed(OUT/'union21-rebuilt-covariance.npz',grouped=Cg,individual=Ci,contrast_matrix_groups=L,contrast_matrix_individual=PP)
checks['runtime']={'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__}
checks['status']='PASS';write('VERIFICATION.json',checks);print(json.dumps(checks,indent=2))
