"""Hash frozen companion files and create its local distributable zip.
Re-run after an approved documentation/equation-map addition, then run verify.py.
"""
from pathlib import Path
import hashlib,json,zipfile
P=Path(__file__).resolve().parent
rows=[]
for f in sorted(P.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(P)
 if any(x in rel.parts for x in ['generated','__pycache__','.venv']) or f.name=='MANIFEST-SHA256.json':continue
 rows.append({'path':str(rel),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(P/'MANIFEST-SHA256.json').write_text(json.dumps({'version':'RD6-calculations-1.0.0','files':rows,'generated_outputs':'Generated outputs are not inputs to the frozen-file manifest; they are included in the zipped delivery and covered by its outer hash.'},indent=2)+'\n')
zip_path=P.parent/'SET-RD6-calculation-companion-v1.0.0.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(P.rglob('*')):
  if not f.is_file() or any(x in f.relative_to(P).parts for x in ['__pycache__','.venv','mpl-cache']):continue
  z.write(f,'SET-RD6-calculation-companion-v1.0.0/'+str(f.relative_to(P)))
manifest={'archive':zip_path.name,'sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'bytes':zip_path.stat().st_size,'frozen_files':len(rows),'public_upload_performed':False}
(P.parent/'calculation-companion-delivery.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
