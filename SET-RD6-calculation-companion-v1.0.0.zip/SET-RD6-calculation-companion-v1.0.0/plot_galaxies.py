"""Re-render the retained galaxy plots from frozen plotted source records.
RD5 Figures7/8 become RD6 Figures6/7 after removal of the old Figure4.
Plot bodies are copied from the archived production scripts; data loading and
output names are adapted for this standalone companion. This replot does not
rerun the raw image measurement or uncertainty propagation; verify.py checks
central calculations and regenerates the42 later source-input draw records.
"""
from pathlib import Path
import json, os
P=Path(__file__).resolve().parent; OUT=P/'generated/figures';OUT.mkdir(parents=True,exist_ok=True)
os.environ['MPLCONFIGDIR']=str(P/'generated/mpl-cache')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch,Polygon,Rectangle
d=json.loads((P/'inputs/galaxy/expanded83.json').read_text())
allrows=d['displayed_rows'];N=len(allrows);A=len(d['additional_rows']);nn=d['summary']['resolved_Newtonian_comparisons']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10.5,'axes.spines.top':False,'axes.spines.right':False,'text.color':'#263442','axes.labelcolor':'#263442','svg.fonttype':'none'})
blue,teal,orange,gray='#365caf','#087f8c','#c77825','#65717c';green,violet,ve='#dfeee4','#d9ccf1','#8b6db3'
def save(fig,name):
 for ext in ['png','svg','pdf']:fig.savefig(OUT/f'{name}.{ext}',dpi=240,facecolor='white')
 plt.close(fig)
# Requested landscape format, same normalization and two distinct shade meanings.
fig,ax=plt.subplots(figsize=(14.8,7.6));x=np.linspace(.65,2.2,500);ax.fill_between(x,x/1.1,x/.9,color=green,zorder=0)
ss=sorted(allrows,key=lambda r:r['x']);xx=np.array([r['x'] for r in ss]);assert np.all(np.diff(xx)>0)
edges=np.r_[xx[0]-(xx[1]-xx[0])/2,(xx[:-1]+xx[1:])/2,xx[-1]+(xx[-1]-xx[-2])/2]
for i,r in enumerate(ss):
 if r['dy'] is None:continue
 l,h=edges[i:i+2];dy=r['dy'];ax.add_patch(Polygon([(l,l-dy),(h,h-dy),(h,h+dy),(l,l+dy)],closed=True,facecolor=violet,edgecolor='none',alpha=.78,zorder=1))
 ax.plot([l,h],[l+dy,h+dy],c=ve,lw=.4,alpha=.7);ax.plot([l,h],[l-dy,h-dy],c=ve,lw=.4,alpha=.7)
ax.plot(x,x,c='#495664',ls='--',lw=1.1,zorder=3);ax.axvline(1,c='#9ba4ad',ls=':',lw=.9,zorder=0)
for r in allrows:
 if r['v_Newton_km_s'] is not None:
  nx=r['v_Newton_km_s']/r['reference_km_s'];ax.plot([nx,r['x']],[r['y']]*2,c='#d9dee3',lw=.55,zorder=0);ax.scatter(nx,r['y'],c=orange,marker='x',s=26,lw=1.1,zorder=4)
 color=blue if r['group']=='Existing 62' else teal;marker='D' if r['large_side_asymmetry'] else ('^' if r['secondary_quality'] else 'o')
 ax.scatter(r['x'],r['y'],edgecolors=color,facecolors='white' if marker!='o' else color,marker=marker,s=40 if marker!='o' else 34,lw=1.1,zorder=5)
ax.set(xlim=(.65,2.20),ylim=(.60,3.10),xlabel=r'Calculated speed / $\sqrt{G M_{\rm bar}/R}$',ylabel=r'Observed speed / $\sqrt{G M_{\rm bar}/R}$');ax.grid(alpha=.10)
leg=[Patch(facecolor=green,label='±10% speed-agreement band'),Patch(facecolor=violet,label='Individual velocity-range shadow (stepped)'),Line2D([],[],c='#495664',ls='--',label='Equal calculated and observed speed'),Line2D([],[],c=blue,marker='o',ls='',label='62 existing SET examples'),Line2D([],[],c=teal,marker='o',ls='',label=f'{A} new SET examples'),Line2D([],[],c=orange,marker='x',ls='',label=f'Newtonian baryons: {nn} available profiles')]
ax.legend(handles=leg,loc='upper left',fontsize=10,frameon=True,facecolor='white',edgecolor='white',framealpha=1)
fig.text(.075,.955,'Galaxy rotation: source-law calculations and measured speeds',fontsize=16,weight='bold');fig.text(.075,.919,f'{N} worked comparisons  |  {A} new examples from this run  |  Formula and central-input rules retained',fontsize=11,color=gray)
fig.subplots_adjust(left=.075,right=.975,top=.88,bottom=.20)
fig.text(.075,.120,'Purple cells use each galaxy’s own recorded velocity range; cell joins are for display, not interpolation.',fontsize=10,color=gray)
fig.text(.075,.086,'Open diamonds: larger side asymmetry. Open triangles: Apertif A2 model or inclination below 40°; flags remain in the table.',fontsize=9.5,color=gray)
fig.text(.075,.051,'The green band is an agreement criterion. Heterogeneous recorded errors/ranges are not a common confidence interval.',fontsize=9.5,color=gray)
save(fig,'RD6-Figure6-galaxy-comparison83')

u=json.loads((P/'inputs/galaxy/source-uncertainty62.json').read_text())
records=u['rows'];summary=u['summary'];ordered=sorted(records,key=lambda r:(r['group']!='Original 20',r['name']))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
    'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none',
    'text.color':'#253442','axes.labelcolor':'#253442'})
blue,teal,green,purple,gray='#365caf','#087f8c','#e5f1e9','#d8c8ef','#627180'
fig,axes=plt.subplots(1,2,figsize=(16.5,11.4),sharex=True)
for ax,chunk in zip(axes,[ordered[:31],ordered[31:]]):
    ax.axvspan(-10,10,color=green,zorder=0)
    for j,r in enumerate(chunk):
        y=len(chunk)-1-j
        e=100*r['obs_relative_range'];q=r['ratio_source_only']
        color=blue if r['group']=='Original 20' else teal
        formal=r['obs_range_kind']=='Listed rotation-bin error'
        ax.add_patch(Rectangle((-e,y-.31),2*e,.62,facecolor=purple,
            edgecolor='#b6a0d0' if formal else 'none',linewidth=.5,
            alpha=.80 if formal else .48,zorder=1))
        ax.plot([100*(q['p025']-1),100*(q['p975']-1)],[y,y],c=color,lw=1.0,zorder=3)
        ax.plot([100*(q['p16']-1),100*(q['p84']-1)],[y,y],c=color,lw=3.0,solid_capstyle='butt',zorder=4)
        ax.scatter(100*(r['nominal_ratio']-1),y,s=25,c=color,edgecolors='white',linewidths=.55,zorder=5)
    ax.axvline(0,c='#334656',ls='--',lw=.9,zorder=2)
    ax.set_yticks(range(len(chunk)))
    ax.set_yticklabels([r['name'] for r in chunk[::-1]],fontsize=8.5)
    ax.tick_params(axis='y',length=0,pad=6)
    ax.set(xlim=(-65,65),ylim=(-.8,len(chunk)-.2),xlabel=r'$100\,(v_{\rm SET}/v_{\rm obs}-1)$  (%)')
    ax.set_xticks([-60,-40,-20,0,20,40,60]);ax.grid(axis='x',alpha=.12)
fig.subplots_adjust(left=.09,right=.98,top=.82,bottom=.18,wspace=.26)
fig.text(.045,.965,'Galaxy rotation: uncertainty in SET’s calculation inputs',fontsize=20,weight='bold')
fig.text(.045,.931,'62 worked examples  •  Original central calculations preserved  •  Mass, radius and shape propagated together',fontsize=11.7,color=gray)
handles=[Line2D([],[],c=blue,marker='o',lw=3,label='Original 20: SET input range'),
         Line2D([],[],c=teal,marker='o',lw=3,label='Additional 42: SET input range'),
         Patch(facecolor=purple,alpha=.8,label='Recorded observational range'),
         Patch(facecolor=green,label='±10% agreement region')]
fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.52,.904),ncol=2,
    fontsize=10.8,frameon=False,columnspacing=3.2)
fig.text(.52,.837,
    f"Overlap with recorded observation ranges: {summary['source68_overlaps_obs_range']}/62 (thick segments), "
    f"{summary['source95_overlaps_obs_range']}/62 (thin segments)",
    ha='center',fontsize=11.0,color='#314b59')
fig.text(.09,.125,'Dots: unchanged nominal results. Thick / thin segments: central 68% / 95% of conditional source-input draws.',fontsize=10.5,color=gray)
fig.text(.09,.098,'Purple rows show each object’s own velocity range: outlined = listed error; pale = descriptive dispersion / side range.',fontsize=10.3,color=gray)
fig.text(.09,.071,'Distance changes mass and radius together; shared inclination changes both geometry and velocity deprojection.',fontsize=10.3,color=gray)
fig.text(.09,.044,'Unreported errors and mass-to-light ratios remain fixed. Source intervals are partial and conditioned on valid oblate geometry.',fontsize=10.3,color=gray)
for ext in ['png','svg']:
    fig.savefig(OUT/f'RD6-Figure7-source-uncertainty62.{ext}',dpi=260,facecolor='white')
plt.close(fig)

print('Created retained galaxy figures in',OUT)
