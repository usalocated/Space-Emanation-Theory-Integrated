"""Assemble immutable-source copies for the RD6 calculation companion; no source edits."""
from pathlib import Path
import json, shutil, hashlib
P=Path(__file__).resolve().parent
ROOT=P.parents[2]
records=[]
def copy(src,dst,role):
 s=ROOT/src; d=P/dst; d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(s,d)
 records.append({'package_path':dst,'original_workspace_path':src,'sha256':hashlib.sha256(d.read_bytes()).hexdigest(),'bytes':d.stat().st_size,'role':role})
g0='outputs/set-classical-audit-20'
g1='outputs/set-galaxy-expansion-2026-10-21'
g2='outputs/set-galaxy-expansion-plus60-2026-10-21'
sn='outputs/set-q-no-fit-investigation-2026-10-13'
u='outputs/set-independent-de-and-rotation-curves-2026-10-21'
copy(g2+'/results/EXPANSION-RESULTS.json','inputs/galaxy/expanded83.json','All83 plotted rows,26 resolved Newtonian comparisons,71 eligible new outcomes and supplementary diagnostics')
copy(g1+'/results/source-uncertainty-preview/source-uncertainty-results.json','inputs/galaxy/source-uncertainty62.json','Frozen source-input quantiles,seeds,42-source draw input ledger and62 overlap flags')
copy(g1+'/results/source-uncertainty-preview/source-uncertainty-table.csv','inputs/galaxy/source-uncertainty62.csv','Exact plotted62-source table')
copy(g0+'/audited-results.json','inputs/galaxy/original20.json','Original20 source measurements,Newtonian decomposition and provenance')
copy(g1+'/results/additional-calculations.json','inputs/galaxy/additional42.json','Additional42 source masses,radii,image coefficients and provenance')
copy(g1+'/screen/NGC3972-additional-example.json','inputs/galaxy/NGC3972-source.json','Additional resolved Newtonian component inputs')
copy(g2+'/screen/ALL-NEW-ATTEMPTS.json','inputs/galaxy/all-new-attempts.json','Complete new identity/input/calculation attempt ledger')
for name in ['SPARC-ALIAS-RESULTS','SPARC-EXTENDED-ALIAS-RESULTS','APERTIF-screen','WALLABY-RESULTS','PROBESII-screen','PROBES-HI-COMPLETION-RESULTS','PHANGS-screen']:
 copy(g2+'/screen/'+name+'.json','inputs/galaxy/new-source-records/'+name+'.json','Frozen new-source calculation records,including nondisplayed results')
for src,dst in [('protocol/original20-source-only-intervals.json','original20-source-only.json'),('screen/PROBES-SPARC-UNCERTAINTY-INPUTS.json','PROBES-SPARC-uncertainty-inputs.json'),('sources/GHASP-UMA-UNCERTAINTY-INPUTS.json','GHASP-UMA-uncertainty-inputs.json')]:copy(g1+'/'+src,'inputs/galaxy/'+dst,'Frozen source-input propagation record')
for src,dst in [(g1+'/RESEARCH-INDEX.txt','galaxy-original-index.txt'),(g0+'/manifest.json','galaxy-original20-manifest.json'),(g1+'/review-artifacts-manifest.json','galaxy62-manifest.json'),(g2+'/audit/FINAL-ASSEMBLY-INDEPENDENT-AUDIT.json','galaxy83-independent-audit.json')]:copy(src,'provenance/'+dst,'Pre-existing provenance/audit record')
for cat in ['pantheonplus','des-dovekie']:
 copy(sn+'/'+cat+'-published_uncertainty-contrasts.npz','inputs/sn15/'+cat+'.npz','Frozen object-level standardized magnitudes/redshifts,contrast matrix and full grouped covariance')
copy(sn+'/brightness-contrast-table.json','expected/sn15-brightness.json','Published15-group brightness values')
copy('outputs/set-dark-energy-rough-draft-3/verified-results.json','expected/sn15-verification.json','Archived forward-calculation summary')
copy(sn+'/contrasts-published_uncertainty.json','inputs/sn15/contrast-membership.json','Group endpoints/counts/reference metadata and covariance provenance')
for name in ['pantheon-manifest.json','des-manifest.json']:
 copy('outputs/set-dark-energy-observations-2026-10-13/provenance/'+name,'provenance/'+name,'Original release download/provenance manifest')
for name in ['union21-mu.txt','union21-cov-stat.txt','union21-cov-statsys.txt','union21-strict-unseen.npz','union21-strict-unseen-sensitivity.npz','union21-all580-overlap-ledger-strict.json','UNION21-FINAL-INDEPENDENCE-MANIFEST.json','STRICT-UNSEEN-MANIFEST.json','union21-covariance-semantics-final.json','download-queue-1-manifest.json']:
 copy(u+'/supernova/data/'+name,'inputs/union21/'+name,'Released Union2.1 data/covariance or frozen identity-selection provenance')
copy(u+'/supernova/new-supernova-results.json','expected/union21-results.json','Published260-target and7-group values')
copy(u+'/supernova/new-supernova-contrast-arrays.npz','expected/union21-contrast-arrays.npz','Published260-target and7-group covariance arrays')
copy(u+'/verification/SUPERNOVA-INDEPENDENT-AUDIT.json','provenance/union21-independent-audit.json','Existing independent raw-release/history audit')
copy(u+'/protocol/FROZEN-RESEARCH-PROTOCOL.txt','provenance/frozen-supernova-protocol.txt','Pre-existing fixed numerical protocol')
# Original scripts remain byte-identical reference copies. The portable runner is verify.py.
for src,dst in [(g2+'/assemble_review.py','assemble_galaxies_original.py'),(g1+'/plot_source_uncertainty.py','uncertainty_original.py'),(sn+'/calculate_causal_clock.py','causal_clock_original.py'),(sn+'/calculate_contrasts.py','contrasts_original.py'),('outputs/set-dark-energy-rough-draft-3/verify_calculation.py','sn15_original.py'),(u+'/supernova/calculate_new.py','union21_production_original.py'),(u+'/verification/audit_supernova_independent.py','union21_audit_original.py')]:copy(src,'reference-scripts/'+dst,'Byte-identical original script; workspace-specific paths preserved; use portable verify.py for standalone execution')
copy('outputs/set-integrated-rough-draft-5-2026-10-23/github-publication.json','provenance/rd5-publication.json','Existing PDF publication record; not evidence that this companion was previously public')
constants={'version':'RD6-calculations-1.0.0','created':'2026-10-29','G_SI':6.67430e-11,'c_m_s':299792458.0,'G_kpc_km2_s2_Msun':4.3009172700362775e-6,'cosmology_M0_kg':1.5005279083130905e53,'cosmology_R0_m':4.399239669750072e26,'Mpc_m':3.0856775814913673e22,'galaxy_kpc_m':3.085677581491367e19,'galaxy_Msun_kg':1.988409870698051e30,'Mercury':{'GM_m3_s2':1.3271244004127942e20,'au_m':149597870700.0,'a_au':0.38709927,'e':0.20563593,'sidereal_period_days':87.969,'julian_century_days':36525,'sources':['https://ssd.jpl.nasa.gov/astro_par.html','https://ssd.jpl.nasa.gov/planets/approx_pos.html'],'reading':'RD5 section5.6 equations145–151; leading spherical perihelion benchmark'}}
(P/'inputs/constants.json').write_text(json.dumps(constants,indent=2)+'\n')
(P/'provenance/COPIED-SOURCE-MAP.json').write_text(json.dumps(records,indent=2)+'\n')
print('Copied',len(records),'files',sum(x['bytes'] for x in records),'bytes')
