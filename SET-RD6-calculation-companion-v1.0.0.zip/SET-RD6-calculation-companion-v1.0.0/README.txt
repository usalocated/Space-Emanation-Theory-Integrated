SPACE EMANATION THEORY — INTEGRATED ROUGH DRAFT 6
Calculation companion RD6-calculations-1.0.0 — 29 October 2026

START HERE
This companion contains the frozen calculation inputs, original provenance,
portable verification code, original script snapshots, and regenerated result
tables for the headline Mercury, galaxy and supernova calculations retained in
Integrated Rough Draft 6. CALCULATION-INDEX.json maps manuscript results to files.
COPIED-SOURCE-MAP.json in provenance maps each unchanged copy to its workspace
origin and SHA256. MANIFEST-SHA256.json checks the complete frozen companion.
The archive is delivered locally with RD6; this file claims no public release URL.

RUN
Use Python 3.12. The tested numerical environment is recorded in requirements.txt.
From the unpacked reproduction directory:
  python3 -m venv .venv
  .venv/bin/python -m pip install -r requirements.txt
  .venv/bin/python verify.py
  .venv/bin/python plot_galaxies.py

verify.py writes generated/VERIFICATION.json and three recalculated CSV tables.
It exits with an error if a comparison or integrity assertion fails. The two
commands write into generated/, never into the frozen input files.
The supplied generated/ files are the actual tested output from this package.

WHAT IS REPRODUCED
1. Mercury: leading spherical perihelion benchmark from the listed constants;
   exact turning-radius quadrature gives a separate numerical check.
2. Galaxies: all83 Q/area/circular-speed calculations from frozen baryonic mass,
   radius and image coefficient; all26 available Newtonian comparison speeds
   rebuilt from the recorded signed gas/disk/bulge components. The full new
   calculation/attempt ledgers accompany the displayed examples.
3. Galaxy source uncertainty: regenerate the42 later objects'250000 draws each,
   retaining the original seed and shared distance/inclination rules; verify the
   exact stored quantiles. Original20 source-only quantiles remain frozen from
   their previously archived65536-draw calculation. Recheck62 overlap counts.
4. Pantheon+ and DES-Dovekie: evaluate the unchanged source history at every
   retained catalogue redshift and reconstruct the15 brightness contrasts and
   covariance statistics. Inputs are frozen standardized magnitudes, redshifts,
   contrast matrices and propagated grouped covariance; raw light-curve reduction
   and the full upstream covariance projection are not rerun by this package.
5. Union2.1: reconstruct the298 retained source rows from the released580-row
   table and fixed identity ledger; extract the full released covariance; rebuild
   the23-reference/260-target contrast matrices,7 group covariances and260-object
   covariance. Recompute the distance predictions and statistics independently
   using the separated-variable integral, checked against direct ODE integration.
6. Re-render the retained galaxy plots with original plot bodies adapted only
   for portable data loading and filenames. These are RD6 Figures6 and7, formerly
   RD5 Figures7 and8.

The numerical runner begins at the frozen input level specified above. It does
not download data, remeasure galaxy images, refit stellar mass-to-light ratios,
refit supernova standardization, or optimize a SET parameter. This is a compact
reproduction of the retained calculations, not a new observational study.

FILE ORGANIZATION
 inputs/constants.json       Fixed source/physical/Mercury inputs
 inputs/galaxy/              83 rows,62 uncertainty records, component inputs,
                             source provenance, and complete new attempt ledgers
 inputs/sn15/               15-group catalogue inputs and contrast membership
 inputs/union21/             Released data/covariance and fixed selection ledger
 expected/                   Archived outputs used as comparison targets only
 provenance/                 Original download/audit/publication/source records
 reference-scripts/          Byte-identical original scripts for provenance;
                             their workspace paths are historical, not portable
 verify.py                   Portable numerical reproduction (standalone)
 plot_galaxies.py            Portable re-render of the two retained galaxy plots
 generated/                  Actual numerical and graphical outputs

The original scripts contain the wider historical research context. The portable
runner's explicit scope above is the executable contract of this companion.
Figure4 from RD5 was removed in RD6 as an approved redundant display. Figures1–3
retain their numbers; old Figures5–13 become Figures4–12. No result rows were
removed by that figure change. Tables retain their numbering.

PROVENANCE AND REUSE
Original catalogue/provider URLs, data identities, file hashes and parsing
records are retained in provenance and the source-record JSON files. Third-party
data remain subject to their providers' terms. The original RD5 publication
record verifies the paper PDF only; it is not presented as prior publication of
this newly assembled companion.

TESTED LOCAL INVOCATION
Executable: bundled Python3.12.14 from the Codex workspace dependency runtime.
The local test used the existing workspace package directories for NumPy2.3.5,
SciPy1.18.1 and Matplotlib3.11.1. No package install or network access was needed.
The package itself uses ordinary imports and is independent of those local paths.
