"""Independent raw-release audit; no production model or contrast imports."""
from pathlib import Path
import os, sys, json, hashlib, collections
os.environ['OPENBLAS_NUM_THREADS'] = '1'
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
ROOT = BASE.parents[1]
sys.path.insert(0, str(ROOT / 'work/set-ngc3198-field-runtime'))
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.stats import chi2

DATA = BASE / 'supernova/data'
released_rows = [line.split() for line in (DATA/'union21-mu.txt').read_text().splitlines()
                 if line.strip() and not line.startswith('#')]
raw_ids = np.array([r[0] for r in released_rows])
raw_z = np.array([float(r[1]) for r in released_rows])
raw_mu = np.array([float(r[2]) for r in released_rows])
raw_sigma = np.array([float(r[3]) for r in released_rows])
Craw = np.loadtxt(DATA/'union21-cov-statsys.txt')
Cstat = np.loadtxt(DATA/'union21-cov-stat.txt')
ledger = json.loads((DATA/'union21-all580-overlap-ledger-strict.json').read_text())
manifest = json.loads((DATA/'UNION21-FINAL-INDEPENDENCE-MANIFEST.json').read_text())
retained = np.array([r['union_index'] for r in ledger if r['included_strict_unseen']], int)
file = DATA/'union21-strict-unseen.npz'
given = np.load(file)
assert len(released_rows) == len(ledger) == 580
assert len(np.unique(raw_ids)) == 580
assert np.array_equal(given['original_index'], retained)
assert np.array_equal(given['CID'], raw_ids[retained])
assert np.array_equal(given['z'], raw_z[retained])
assert np.array_equal(given['mu'], raw_mu[retained])
assert np.array_equal(given['covariance'], Craw[np.ix_(retained, retained)])
assert np.array_equal(given['covariance_stat'], Cstat[np.ix_(retained, retained)])
assert '2001go' not in raw_ids[retained]
assert len(retained) == 298 and not any(ledger[i]['overlap_matches'] for i in retained)
assert all(r['union_index'] == i and r['name'] == raw_ids[i] and
           r['z'] == raw_z[i] and r['mu'] == raw_mu[i] for i, r in enumerate(ledger))

# Frozen source inputs, then the separated analytic history.  Neither the
# production solve_ivp history nor its state interpolation is used here.
G = 6.67430e-11
c = 299792458.
M = 1.5005279083130905e53
R = 4.399239669750072e26
u0 = 3*G*M/(R*c*c)
y0 = np.sqrt(u0/(1-u0))
a = np.sqrt(6.)
def F(y):
    return (np.log1p(y*y)+2*a*np.arctan(y)-2*np.log(a-y))/7
F0 = F(y0)
zmax = np.expm1(F0-F(0.))
def independent_distance(z):
    if not 0 <= z <= zmax:
        raise ValueError('The frozen history is outside its retained y>=0 domain')
    y = brentq(lambda t: F0-F(t)-np.log1p(z), 0., y0, xtol=5e-15, rtol=1e-14)
    # dz/dy = -(1+z)F'(y); integrate dchi=dz/E(z) directly in y.
    val, error = quad(lambda t: 2*np.sqrt(1+y0*y0)*np.exp(-.5*(F0-F(t))) /
                     ((1+t*t)**1.5*(a-t)), y, y0, epsabs=2e-13, epsrel=2e-13)
    return (1+z)*val

BINS = np.array([.10,.20,.35,.50,.65,.80,1.,1.3,2.4])
def stats(residual, covariance):
    q = float(residual @ np.linalg.solve(covariance, residual))
    return {'chi2': q, 'n_contrasts': len(residual),
            'p_gaussian': float(chi2.sf(q, len(residual))),
            'rms_mag': float(np.sqrt(np.mean(residual**2))),
            'median_abs_mag': float(np.median(np.abs(residual)))}

def evaluate(ix):
    ids, z, mu = raw_ids[ix], raw_z[ix], raw_mu[ix]
    C = Craw[np.ix_(ix, ix)]
    # This release has one row per object, so archived repeat-equalization
    # reduces exactly to inverse marginal variance weights.
    assert len(np.unique(ids)) == len(ids)
    anchor = (z>.025)&(z<.1)
    target = (z>=BINS[0])&(z<BINS[-1])
    w = np.zeros(len(ix))
    w[anchor] = 1/np.diag(C)[anchor]
    w /= w.sum()
    d0 = 2*(1+z)*(1-(1+z)**(-.5))
    ds = np.array([independent_distance(zz) for zz in z])
    dlcdm = np.array([(1+zz)*quad(lambda t: (.3*(1+t)**3+.7)**(-.5),0.,zz,
                      epsabs=2e-13,epsrel=2e-13)[0] for zz in z])
    obs = mu - 5*np.log10(d0)
    pred = 5*np.log10(ds/d0)
    conventional = 5*np.log10(dlcdm/d0)
    # Entire 580-row arrays remain the source. All interval membership is
    # determined from released z before examining any residual.
    groupw, rows = [], []
    for low, high in zip(BINS[:-1],BINS[1:]):
        mask = (z>=low)&(z<high)
        if not mask.any():
            continue
        wi = np.zeros(len(ix))
        wi[mask] = 1/np.diag(C)[mask]
        wi /= wi.sum()
        groupw.append(wi-w)
        rows.append({'z_lo':float(low), 'z_hi':float(high), 'n_objects':int(mask.sum()),
                     'ids':ids[mask].tolist(), 'z_mean':float(wi@z)})
    L = np.array(groupw)
    ti = np.flatnonzero(target)
    P = np.zeros((len(ti), len(ix)))
    P[np.arange(len(ti)), ti] = 1
    P -= w
    groupC = L@C@L.T
    pointC = P@C@P.T
    anchor_var = float(w@C@w)
    anchor_cross = C[ti,:]@w
    explicit_pointC = (C[np.ix_(ti,ti)] + anchor_var -
                       anchor_cross[:,None] - anchor_cross[None,:])
    assert np.max(abs(pointC-explicit_pointC)) < 1e-13
    group_obs, group_pred, group_lcdm = L@obs, L@pred, L@conventional
    point_obs, point_pred, point_lcdm = P@obs, P@pred, P@conventional
    gs, ps = np.sqrt(np.diag(groupC)), np.sqrt(np.diag(pointC))
    for j, row in enumerate(rows):
        residual = group_obs[j]-group_pred[j]
        observed = 10**(-.4*group_obs[j])
        predicted = 10**(-.4*group_pred[j])
        row.update(observed=float(observed), SET=float(predicted),
                   delta_mag_observed=float(group_obs[j]), delta_mag_SET=float(group_pred[j]),
                   sigma_mag=float(gs[j]), residual_mag=float(residual),
                   residual_marginal_sigma=float(residual/gs[j]),
                   observed_1sigma_low=float(10**(-.4*(group_obs[j]+gs[j]))),
                   observed_1sigma_high=float(10**(-.4*(group_obs[j]-gs[j]))),
                   error_baseline_percent=float(100*(1/observed-1)),
                   error_SET_percent=float(100*(predicted/observed-1)),
                   fixed_LCDM_03=float(10**(-.4*group_lcdm[j])))
    gr, pr = group_obs-group_pred, point_obs-point_pred
    group_corr = groupC/np.sqrt(np.outer(np.diag(groupC),np.diag(groupC)))
    result = {
        'counts': {'released':580, 'subset':len(ix), 'anchor':int(anchor.sum()),
                   'target':int(target.sum()), 'outside_windows':int((~(anchor|target)).sum()),
                   'group_counts':[r['n_objects'] for r in rows]},
        'anchor':{'ids':ids[anchor].tolist(),'weights':w[anchor].tolist(),
                  'mean_z':float(w@z),'variance_mag2':anchor_var},
        'algebra_checks':{'max_group_zero_sum_error':float(abs(L.sum(axis=1)).max()),
                          'max_point_zero_sum_error':float(abs(P.sum(axis=1)).max()),
                          'group_rank':int(np.linalg.matrix_rank(L)),
                          'point_rank':int(np.linalg.matrix_rank(P)),
                          'explicit_point_covariance_max_difference':float(abs(pointC-explicit_pointC).max()),
                          'additive_100mag_zero_point_max_error':float(abs(L@(obs+100)-group_obs).max()),
                          'group_min_eigenvalue':float(np.linalg.eigvalsh(groupC).min()),
                          'point_min_eigenvalue':float(np.linalg.eigvalsh(pointC).min()),
                          'group_max_offdiagonal_correlation':float(np.max(group_corr-np.eye(len(groupC))))},
        'grouped':{'rows':rows,'baseline':stats(group_obs,groupC),'SET':stats(gr,groupC),
                   'fixed_LCDM_03':stats(group_obs-group_lcdm,groupC),
                   'n_improved':int(np.sum(abs(gr)<abs(group_obs))),
                   'n_within_marginal_1sigma':int(np.sum(abs(gr)<=gs)),
                   'median_absolute_flux_error_baseline_percent':float(np.median(abs(100*np.expm1(.4*np.log(10)*group_obs)))),
                   'median_absolute_flux_error_SET_percent':float(np.median(abs(100*np.expm1(.4*np.log(10)*gr))))},
        'individual':{'baseline':stats(point_obs,pointC),'SET':stats(pr,pointC),
                      'fixed_LCDM_03':stats(point_obs-point_lcdm,pointC),
                      'n_improved_mag':int(np.sum(abs(pr)<abs(point_obs))),
                      'n_within_marginal_1sigma':int(np.sum(abs(pr)<=ps)),
                      'n_SET_too_bright':int(np.sum(pr>0)), 'n_SET_too_dim':int(np.sum(pr<0))}}
    return result, {'L':L,'P':P,'groupC':groupC,'pointC':pointC,'obs':obs,'pred':pred,
                    'point_obs':point_obs,'point_pred':point_pred,'point_residual':pr,'point_sigma':ps}

primary, arrays = evaluate(retained)
published = json.loads((BASE/'supernova/new-supernova-results.json').read_text())
existing_arrays = np.load(BASE/'supernova/new-supernova-contrast-arrays.npz')
differences = {}
for own, orig in [('L','L'),('P','P'),('groupC','covariance_groups'),
                  ('pointC','covariance_individual'),('obs','observed_delta'),('pred','predicted_delta')]:
    differences[own] = float(np.max(abs(arrays[own]-existing_arrays[orig])))
for block in ['grouped','individual']:
    for model in ['baseline','SET','fixed_LCDM_03']:
        for key in ['chi2','p_gaussian','rms_mag','median_abs_mag']:
            differences[f'{block}_{model}_{key}'] = abs(primary[block][model][key]-published[block][model][key])
rowkeys = ['observed','SET','sigma_mag','residual_mag','residual_marginal_sigma',
           'observed_1sigma_low','observed_1sigma_high','error_baseline_percent',
           'error_SET_percent','fixed_LCDM_03']
for key in rowkeys:
    differences['group_rows_'+key] = max(abs(a[key]-b[key]) for a,b in
                                        zip(primary['grouped']['rows'],published['grouped']['rows']))
assert np.max([v for k,v in differences.items() if 'chi2' not in k]) < 2e-8
assert max(differences.values()) < 2e-7
assert primary['anchor']['ids'] == published['anchor_ids']
assert primary['counts']['group_counts'] == [r['n_objects'] for r in published['grouped']['rows']]
assert all(a['ids']==b['ids'] for a,b in zip(primary['grouped']['rows'],published['grouped']['rows']))
for block, keys in [('grouped',['n_improved','n_within_marginal_1sigma']),
                    ('individual',['n_improved_mag','n_within_marginal_1sigma','n_SET_too_bright','n_SET_too_dim'])]:
    assert all(primary[block][k]==published[block][k] for k in keys)

sensitivity_ix = np.array([r['union_index'] for r in ledger if r['included_strict_unseen_sensitivity']],int)
sensitivity_file = DATA/'union21-strict-unseen-sensitivity.npz'
sensitivity_given = np.load(sensitivity_file)
assert np.array_equal(sensitivity_given['original_index'], sensitivity_ix)
assert np.array_equal(sensitivity_given['CID'], raw_ids[sensitivity_ix])
assert np.array_equal(sensitivity_given['z'], raw_z[sensitivity_ix])
assert np.array_equal(sensitivity_given['mu'], raw_mu[sensitivity_ix])
assert np.array_equal(sensitivity_given['covariance'], Craw[np.ix_(sensitivity_ix,sensitivity_ix)])
assert np.array_equal(sensitivity_given['covariance_stat'], Cstat[np.ix_(sensitivity_ix,sensitivity_ix)])
sensitivity, _ = evaluate(sensitivity_ix)
out = {
    'status':'PASS: independent raw-data, analytic-history, covariance, sign and membership audit',
    'method':'Raw580 mu/z/covariance; final membership ledger; analytic F(y) inversion and y-domain distance quadrature. No import of production model or contrast functions.',
    'source_checks':{'raw_rows':len(raw_ids),'unique_raw_ids':len(np.unique(raw_ids)),
                     'covariance_shape':list(Craw.shape),
                     'max_covariance_asymmetry':float(abs(Craw-Craw.T).max()),
                     'covariance_min_eigenvalue':float(np.linalg.eigvalsh(Craw).min()),
                     'max_stat_variance_difference':float(abs(np.diag(Cstat)-raw_sigma**2).max()),
                     'exact_npz_agreement_to_raw':True,
                     'ledger_counts':dict(collections.Counter(r['status'] for r in ledger)),
                     'selection_manifest_data_only':manifest['data_only_selection'],
                     'selection_manifest_auditor_saw_SET_predictions':manifest['SET_predictions_seen_by_identity_auditor'],
                     'prior_research_exclusions':['2001go'],
                     'primary_redshift_conflict_exclusions':[r['name'] for r in ledger if r['included_strict_unseen_sensitivity'] and not r['included_strict_unseen']]},
    'history':{'u0':float(u0),'y0':float(y0),'zmax':float(zmax),
                'primitive':'F(y)=[ln(1+y²)+2sqrt(6)atan(y)-2ln(sqrt(6)-y)]/7',
                'identity':'ln(1+z)=F(y0)-F(y)'},
    'primary':primary,'sensitivity_all301':sensitivity,
    'strict_prior_research_manifest':json.loads((DATA/'STRICT-UNSEEN-MANIFEST.json').read_text()),
    'reproduction':{'invocation':'calculate_new.py --input data/union21-strict-unseen.npz',
                    'prior299_audit_preserved':'verification/prior299/'},
    'max_abs_differences_from_production':differences,
    'interpretation':[
      'Zero-sum contrasts remove one common magnitude zero point without fitting it; ranks7 and260 are the appropriate dimensions for these fixed contrast tests.',
      'The nearby-anchor uncertainty and all released cross-covariance terms are present. Marginal one-sigma counts are descriptive, not independent Bernoulli trials.',
      'Gaussian goodness-of-fit p values are conditional on the released standardized distances, fixed covariance and fixed chosen model. They are not posterior model probabilities.',
      'All seven populated grouped contrasts improve against the stipulated source-volume baseline; the individual fixed SET test is compatible with this covariance. This does not establish a mechanism or uniqueness.',
      'Grouped and individual results use the same data and must not be multiplied as independent evidence. Cross-catalogue calibration, training and nuisance-estimation dependence also remains.',
      'The brightness ordinate is an exponentiated magnitude contrast, equivalent to a weighted geometric relative-flux quantity, not an arithmetic mean of raw measured fluxes.',
      'No SET parameter or intercept is fit on this new subset. Earlier model development and the inherited catalogue standardization remain distinct historical/model inputs.',
      'The test checks relative redshift-distance shape; global zero-point removal does not test absolute H0 or a fully independent absolute source normalization.'
    ],
    'sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in
              [DATA/'union21-mu.txt',DATA/'union21-cov-statsys.txt',DATA/'union21-cov-stat.txt',file,sensitivity_file,
               DATA/'union21-all580-overlap-ledger-strict.json',BASE/'supernova/calculate_new.py']}
}
(HERE/'SUPERNOVA-INDEPENDENT-AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'counts':primary['counts'],
                 'grouped':{k:v for k,v in primary['grouped'].items() if k!='rows'},
                 'individual':primary['individual'],
                 'maximum_production_difference':max(differences.values()),
                 'sensitivity':{'counts':sensitivity['counts'],'grouped_SET':sensitivity['grouped']['SET'],
                                'individual_SET':sensitivity['individual']['SET']}},indent=2))
