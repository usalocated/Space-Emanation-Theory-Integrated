"""Frozen, zero-intercept-fit contrasts on previously unused individual SNe."""
from pathlib import Path
import os,sys,json,hashlib,csv,argparse
os.environ['OPENBLAS_NUM_THREADS']='1'
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'work/set-ngc3198-field-runtime'))
sys.path.insert(0,str(ROOT/'outputs/set-q-no-fit-investigation-2026-10-13'))
import numpy as np
from scipy.integrate import quad
from scipy.stats import chi2
from calculate_causal_clock import Model
from calculate_contrasts import BINS,equal_object_weights

def summarize(d,c):
    x=float(d@np.linalg.solve(c,d));n=len(d)
    return dict(chi2=x,n_contrasts=n,p_gaussian=float(chi2.sf(x,n)),
                rms_mag=float(np.sqrt(np.mean(d*d))),median_abs_mag=float(np.median(abs(d))))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',default='data/union21-strict-unseen.npz');ap.add_argument('--tag',default='')
    args=ap.parse_args();path=HERE/args.input;outdir=HERE/args.tag;outdir.mkdir(exist_ok=True,parents=True)
    d=np.load(path);ids=d['CID'].astype(str);z=d['z'];m=d['mu'];cov=d['covariance']
    assert cov.shape==(len(z),len(z)) and np.all(np.isfinite(cov))
    assert np.max(abs(cov-cov.T))<1e-10
    np.linalg.cholesky(cov)
    mod=Model(1.5)
    anchor=(z>.025)&(z<.10)
    if not anchor.any():raise RuntimeError('No independent nearby reference; do not reuse old anchor silently')
    wa=equal_object_weights(ids,anchor,np.diag(cov))
    domain=(z>=0)&(z<=mod.zmax)
    # Out-of-domain sources stay in the ledger and receive no extrapolated SET value.
    dl0=2*(1+z)*(1-(1+z)**-.5)
    bmag=5*np.log10(dl0);smag=np.full(len(z),np.nan);cmag=np.full(len(z),np.nan)
    _,_,dc,_=mod.state(z[domain]);smag[domain]=5*np.log10((1+z[domain])*dc)
    cmag[domain]=5*np.log10((1+z[domain])*np.array([quad(lambda q:1/np.sqrt(.3*(1+q)**3+.7),0,t,epsabs=1e-11)[0] for t in z[domain]]))
    weights=[];rows=[]
    for lo,hi in zip(BINS[:-1],BINS[1:]):
        mask=(z>=lo)&(z<hi)
        if not mask.any():continue
        if not np.all(domain[mask]):raise RuntimeError('A frozen contrast includes out-of-domain targets')
        w=equal_object_weights(ids,mask,np.diag(cov));weights.append(w-wa)
        rows.append(dict(z_lo=lo,z_hi=hi,z_mean=float(w@z),n_objects=len(set(ids[mask])),
                         ids=ids[mask].tolist()))
    L=np.array(weights);assert np.max(abs(L.sum(axis=1)))<1e-13
    bc=L@cov@L.T;sig=np.sqrt(np.diag(bc))
    # Inactive entries set to zero only after domain checks; no missing observation dropped.
    delta=m-bmag;sdelta=np.nan_to_num(smag-bmag,nan=0.);cdelta=np.nan_to_num(cmag-bmag,nan=0.)
    obs=L@delta;pred=L@sdelta;conv=L@cdelta;res=obs-pred
    bo=10**(-.4*obs);bp=10**(-.4*pred)
    for i,r in enumerate(rows):
        r.update(observed=float(bo[i]),SET=float(bp[i]),baseline=1.,
                 observed_1sigma_low=float(10**(-.4*(obs[i]+sig[i]))),
                 observed_1sigma_high=float(10**(-.4*(obs[i]-sig[i]))),
                 delta_mag_observed=float(obs[i]),delta_mag_SET=float(pred[i]),
                 residual_mag=float(res[i]),sigma_mag=float(sig[i]),
                 residual_marginal_sigma=float(res[i]/sig[i]),
                 error_baseline_percent=float(100*(1/bo[i]-1)),
                 error_SET_percent=float(100*(bp[i]/bo[i]-1)),
                 fixed_LCDM_03=float(10**(-.4*conv[i])))
    targets=(z>=BINS[0])&(z<BINS[-1]);ti=np.flatnonzero(targets)
    P=np.eye(len(z))[ti]-wa[None,:]
    pc=P@cov@P.T;po=P@delta;pp=P@sdelta;pr=po-pp;ps=np.sqrt(np.diag(pc))
    individual=[]
    for i,j in enumerate(ti):
        individual.append(dict(CID=ids[j],original_index=int(d['original_index'][j]),z=float(z[j]),
          observed=float(10**(-.4*po[i])),SET=float(10**(-.4*pp[i])),
          delta_mag_observed=float(po[i]),delta_mag_SET=float(pp[i]),
          residual_mag=float(pr[i]),sigma_mag=float(ps[i]),
          error_baseline_percent=float(100*(10**(.4*po[i])-1)),
          error_SET_percent=float(100*(10**(.4*pr[i])-1))))
    out=dict(dataset='Union2.1 previously unused positional/alias-audited subset',
      inputs=dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                  model_verification=str(HERE.parent/'verification/frozen-model-verification.json'),
                  protocol=str(HERE.parent/'protocol/FROZEN-RESEARCH-PROTOCOL.txt')),
      n_usable_objects=len(ids),n_reference=int(anchor.sum()),n_target=int(targets.sum()),
      n_outside_redshift_windows=int((~(anchor|targets)).sum()),
      outside_redshift_window_ids=ids[~(anchor|targets)].tolist(),
      n_outside_model_domain=int((~domain).sum()),
      anchor_ids=ids[anchor].tolist(),anchor_weights=wa[anchor].tolist(),anchor_mean_z=float(wa@z),
      grouped=dict(rows=rows,covariance=bc.tolist(),
                   baseline=summarize(obs,bc),SET=summarize(res,bc),
                   fixed_LCDM_03=summarize(obs-conv,bc),
                   n_improved=int(np.sum(abs(res)<abs(obs))),
                   n_within_marginal_1sigma=int(np.sum(abs(res)<=sig)),
                   median_absolute_flux_error_baseline_percent=float(np.median(abs(100*(1/bo-1)))),
                   median_absolute_flux_error_SET_percent=float(np.median(abs(100*(bp/bo-1))))),
      individual=dict(baseline=summarize(po,pc),SET=summarize(pr,pc),
                     fixed_LCDM_03=summarize(po-P@cdelta,pc),
                     n_improved_mag=int(np.sum(abs(pr)<abs(po))),
                     n_within_marginal_1sigma=int(np.sum(abs(pr)<=ps)),
                     n_SET_too_bright=int(np.sum(pr>0)),n_SET_too_dim=int(np.sum(pr<0))),
      fitted_SET_parameters=0,absolute_intercept_fitted=False,
      interpretation='New objects relative to prior catalogues; not independent calibration or a new raw-photometry reduction.')
    (outdir/'new-supernova-results.json').write_text(json.dumps(out,indent=2)+'\n')
    with (outdir/'new-supernova-individual.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(individual[0]));w.writeheader();w.writerows(individual)
    np.savez_compressed(outdir/'new-supernova-contrast-arrays.npz',L=L,P=P,covariance_groups=bc,
                        covariance_individual=pc,z=z,CID=ids,observed_delta=delta,predicted_delta=sdelta)
    print(json.dumps({k:v for k,v in out.items() if k not in ['anchor_ids','anchor_weights','grouped','inputs']},indent=2))
    print('GROUPS',json.dumps({k:v for k,v in out['grouped'].items() if k not in ['rows','covariance']},indent=2))
    for r in rows:print(r['z_mean'],r['n_objects'],r['observed'],r['SET'],r['error_SET_percent'],r['residual_marginal_sigma'])

if __name__=='__main__':main()
