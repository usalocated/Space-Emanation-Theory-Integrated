"""Unfitted causal-boundary + source-clock branches, per causal-clock-protocol.txt."""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'work/set-ngc3198-field-runtime'))
import numpy as np
from scipy.integrate import quad,solve_ivp
from calculate_contrasts import G,C,M,R,H_B,MPC

class Model:
    def __init__(self,xi,source_G_ratio=1.):
        self.xi=xi;self.source_G_ratio=source_G_ratio
        self.u0=xi*source_G_ratio*2*G*M/(R*C*C)
        self.y0=np.sqrt(self.u0/(1-self.u0));self.h0=H_B*np.sqrt(source_G_ratio)*np.sqrt(1+self.y0**2)
        self.zmax=np.expm1(quad(lambda y:2/((1+y*y)*(2*np.sqrt(xi)-y)),0,self.y0,epsabs=1e-13)[0])
        def ode(z,state):
            y=state[0];e=(1+z)**1.5*np.sqrt(1+y*y)/np.sqrt(1+self.y0**2)
            return [-(1+y*y)*(2*np.sqrt(xi)-y)/(2*(1+z)),1/e,1/((1+z)*e)]
        self.sol=solve_ivp(ode,[0,self.zmax],[self.y0,0,0],rtol=2e-12,atol=2e-13,dense_output=True)
        assert self.sol.success
        assert abs(self.sol.y[0,-1])<1e-10
    def state(self,z):
        z=np.asarray(z)
        if np.any(z<0) or np.any(z>self.zmax):raise ValueError('outside physical branch')
        y,dc,tl=self.sol.sol(z);e=(1+z)**1.5*np.sqrt(1+y*y)/np.sqrt(1+self.y0**2)
        return y,e,dc,tl

def main():
    bao=json.loads((HERE/'bao-results.json').read_text());bz=np.array([r['z'] for r in bao['rows']])
    bf=np.array([r['F_AP'] for r in bao['rows']]);bc=np.array(bao['covariance_F_AP'])
    ccpath=HERE.parent/'set-chronometer-check'
    cz,ch,ce=np.loadtxt(ccpath/'data/HzTable_MM_BC03.dat',delimiter=',',usecols=(0,1,2),unpack=True)
    cc=np.loadtxt(ccpath/'covariance.txt')
    out=dict(fitted_parameters=0,protocol=(HERE/'causal-clock-protocol.txt').read_text(),branches={})
    for xi,label in [(1.,'boundary_burden'),(1.5,'central_uniform_burden')]:
        mod=Model(xi);yh=mod.y0;result=dict(xi=xi,u0=mod.u0,alpha0=np.sqrt(1-mod.u0),
            H0_km_s_Mpc=mod.h0*MPC/1000,zmax=mod.zmax,
            q0=.5*(1+yh*yh)-np.sqrt(xi)*yh,
            physical_age_since_zero_front_Gyr=mod.sol.y[2,-1]/mod.h0/(365.25*86400*1e9),
            fixed_point=dict(u_star=4*xi/(1+4*xi),alpha_star=1/np.sqrt(1+4*xi),
              H0_km_s_Mpc=H_B*np.sqrt(1+4*xi)*MPC/1000,q=.5,shape='source-volume dust curve'),
            supernova={},absolute_clock={})
        for name,fn in [('Pantheon+','pantheonplus-published_uncertainty-contrasts.npz'),('DES-Dovekie','des-dovekie-published_uncertainty-contrasts.npz')]:
            d=np.load(HERE/fn);z=d['z'];zh=d['zHEL'];L=d['L'];m=d['observed'];cv=d['covariance']
            outside=z>=mod.zmax;valid=np.all((L==0)|~outside[None,:],axis=1)
            pred=np.zeros(len(z));y,e,dc,_=mod.state(z[~outside]);pred[~outside]=5*np.log10((1+zh[~outside])*dc)
            res=L[valid]@(m-pred);sub=cv[np.ix_(valid,valid)]
            result['supernova'][name]=dict(n_full_contrasts=len(L),n_valid_contrasts=int(valid.sum()),
              complete_sample_domain_valid=bool(valid.all()),outside_source_rows=int(outside.sum()),
              valid_contrast_indices=np.where(valid)[0].tolist(),residuals_mag=res.tolist(),
              chi2_on_valid_fixed_contrasts=float(res@np.linalg.solve(sub,res)),
              warning=None if valid.all() else 'Restricted-domain diagnostic; not a full-sample result.')
        valid=bz<mod.zmax;y,e,dc,_=mod.state(bz[valid]);pf=e*dc;res=bf[valid]-pf
        result['BAO_AP']=dict(n_valid=int(valid.sum()),n_total=len(bz),z=bz[valid].tolist(),predicted_F_AP=pf.tolist(),
          chi2=float(res@np.linalg.solve(bc[np.ix_(valid,valid)],res)),complete_domain=bool(valid.all()))
        valid=cz<mod.zmax;y,e,dc,_=mod.state(cz[valid]);hp=mod.h0*MPC/1000*e;res=ch[valid]-hp
        result['absolute_clock']=dict(n_valid=int(valid.sum()),n_total=len(cz),predicted_H=hp.tolist(),
          chi2=float(res@np.linalg.solve(cc[np.ix_(valid,valid)],res)),complete_domain=bool(valid.all()))
        grid=np.array([0,.1,.2,.5,.7,1.,1.5,2.,2.33]);grid=grid[grid<mod.zmax]
        y,e,dc,tl=mod.state(grid)
        result['sample_predictions']=[dict(z=float(z),y=float(yy),u=float(yy*yy/(1+yy*yy)),
           H_km_s_Mpc=float(ee*mod.h0*MPC/1000),dimensionless_DL=float((1+z)*dd),
           q=float(.5*(1+yy*yy)-np.sqrt(xi)*yy)) for z,yy,ee,dd in zip(grid,y,e,dc)]
        if xi<=1:result['acceleration_bound']='q=0.5*(y-1)^2 >= 0 for xi=1.'
        else:
            yl=np.sqrt(xi)-np.sqrt(xi-1);yu=np.sqrt(xi)+np.sqrt(xi-1)
            result['acceleration_bound']=dict(q_min=(1-xi)/2,
                H0_if_accelerating_min=H_B*np.sqrt(1+yl*yl)*MPC/1000,
                H0_if_accelerating_max=H_B*np.sqrt(1+yu*yu)*MPC/1000,
                condition='For frozen baryon density and q0<0 in this exact trial class.')
        out['branches'][label]=result
    out['conclusion']='The causal clock normalization gives calculable no-fit shape changes, but not a simultaneous match of brightness, radial/angular geometry and absolute clock data.'
    out['limitations']=[
      'These are specified completions using source-volume motion, a preferred-clock assignment, and a uniform finite-domain burden. They are not consequences of Q alone.',
      'The uniform static burden is extrapolated to a moving causal boundary; retarded source integration has not been derived for this branch.',
      'The frozen R0 is a conventional cosmology-conditioned radius, not an independently measured SET horizon.',
      'The branch beginning at a nonzero minimum scale cannot describe already observed larger redshifts beyond zmax.',
      'A restricted comparison never discards out-of-domain points silently. Self-similar fixed points restore unlimited redshift but retain the dust distance shape.',
      'No input was optimized after seeing the residuals.'
    ]
    (HERE/'causal-clock-results.json').write_text(json.dumps(out,indent=2))
    for label,r in out['branches'].items():
        print(label,'H0',r['H0_km_s_Mpc'],'zmax',r['zmax'],'q0',r['q0'])
        print('SN',r['supernova']);print('BAO',r['BAO_AP']);print('CC',r['absolute_clock'])
        print('bound',r['acceleration_bound'])

if __name__=='__main__':main()
