"""Reproduce the retained brightness result without fitting any input.

This is an audit of the existing calculation, not a new choice of response.
Run with the bundled Python; the frozen source products remain in the workspace.
"""
from pathlib import Path
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RUN = HERE.parent / 'set-q-no-fit-investigation-2026-10-13'
sys.path.insert(0, str(ROOT / 'work/set-ngc3198-field-runtime'))
sys.path.insert(0, str(RUN))
import numpy as np
from calculate_causal_clock import Model
from calculate_contrasts import G, C, M, R, V, Q, H_B, MPC

mod = Model(1.5)
archived = json.loads((RUN / 'brightness-contrast-table.json').read_text())
source = json.loads((RUN / 'contrasts-published_uncertainty.json').read_text())
out = {'constants': dict(G=G, c=C, M0=M, R0=R, V0=V, Q0=Q, rho0=M/V,
       H_b0_km_s_Mpc=H_B*MPC/1000, u0=mod.u0, alpha0=np.sqrt(1-mod.u0),
       y0=mod.y0, H0_km_s_Mpc=mod.h0*MPC/1000, zmax=mod.zmax),
       'catalogues': {}, 'inputs': []}

for name, file in [('Pantheon+', 'pantheonplus'), ('DES-Dovekie', 'des-dovekie')]:
    path = RUN / (file + '-published_uncertainty-contrasts.npz')
    d = np.load(path)
    z, zh, L, m, cov = [d[k] for k in ['z','zHEL','L','observed','covariance']]
    y, E, dc, tl = mod.state(z)
    base = 2*(1+zh)*(1-(1+z)**-.5)
    trial = (1+zh)*dc
    dm_obs = L @ (m-5*np.log10(base))
    # Forward prediction uses redshifts and fixed model only, not brightness m.
    dm_trial = L @ (5*np.log10(trial/base))
    res = dm_obs-dm_trial
    obs, pred = 10**(-.4*dm_obs), 10**(-.4*dm_trial)
    old = archived['catalogues'][name]
    assert np.max(np.abs(obs-[r['observed'] for r in old])) < 1e-12
    assert np.max(np.abs(pred-[r['central_source_clock_prediction'] for r in old])) < 1e-12
    error0, error1 = 100*(1/obs-1), 100*(pred/obs-1)
    assert np.all(np.abs(error1)<np.abs(error0))
    sig = np.sqrt(np.diag(cov))
    rows = []
    for i, r in enumerate(old):
        rr = source['catalogues'][name]['rows'][i]
        rows.append(dict(r, z_lo=rr['z_lo'], z_hi=rr['z_hi'],
                         delta_m_observed=float(dm_obs[i]), delta_m_predicted=float(dm_trial[i]),
                         residual_mag=float(res[i]), sigma_mag=float(sig[i])))
    out['catalogues'][name] = dict(rows=rows,
        chi2_initial=float(dm_obs@np.linalg.solve(cov,dm_obs)),
        chi2_SET=float(res@np.linalg.solve(cov,res)),
        median_absolute_error_initial=float(np.median(np.abs(error0))),
        median_absolute_error_SET=float(np.median(np.abs(error1))),
        within_marginal_1sigma=int(np.sum(np.abs(res)<=sig)),
        n_improved=len(rows), n_target_objects=sum(r['n_objects'] for r in old),
        n_reference_objects=source['catalogues'][name]['anchor_n_objects'])
    out['inputs'].append(dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest()))

z = out['catalogues']['DES-Dovekie']['rows'][3]['z_mean']
y, E, dc, tl = mod.state(z)
out['worked_point'] = dict(z=z,a=1/(1+z), y=float(y),u=float(y*y/(1+y*y)),
    alpha=float(1/np.sqrt(1+y*y)),E=float(E),E_initial=float((1+z)**1.5),
    dimensionless_comoving_distance=float(dc),
    dimensionless_luminosity_distance_at_zHEL_equal_z=float((1+z)*dc))
out['checks'] = dict(all_15_forward_predictions_match_archive=True,
    all_15_absolute_central_discrepancies_improve=True,
    predictions_evaluated_at_each_catalogue_redshift=True,
    fitted_SET_parameters=0, extra_Qnormalized_factor=False)
(HERE/'verified-results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:{a:b for a,b in v.items() if a!='rows'} for k,v in out['catalogues'].items()},indent=2))
print('Worked point',out['worked_point'])
