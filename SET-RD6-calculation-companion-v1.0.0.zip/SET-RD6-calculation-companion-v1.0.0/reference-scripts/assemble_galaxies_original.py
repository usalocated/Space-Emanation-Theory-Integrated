"""Assemble verified new galaxy calculations without altering the existing paper.
Re-run after source audits; every calculated screen outcome is retained separately.
"""
from pathlib import Path
import os,sys,json,math,hashlib,statistics
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];OUT=HERE/'results';OUT.mkdir(exist_ok=True)
os.environ['MPLCONFIGDIR']=str(OUT/'mpl-cache')
sys.path[:0]=[str(ROOT/'work/three-galaxy-set/vendor'),str(ROOT/'work/set-ngc3198-field-runtime')]
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch,Polygon
G=4.3009172700362775e-6
old_paths=[ROOT/'outputs/set-classical-audit-20/audited-results.json',ROOT/'outputs/set-galaxy-expansion-2026-10-21/results/additional-calculations.json']
files=[('SPARC recovered aliases','SPARC-ALIAS-RESULTS.json'),('Apertif','APERTIF-screen.json'),('WALLABY','WALLABY-RESULTS.json'),('PROBES II','PROBESII-screen.json'),('PROBES HI completion','PROBES-HI-COMPLETION-RESULTS.json'),('SPARC extended aliases','SPARC-EXTENDED-ALIAS-RESULTS.json'),('PHANGS CO','PHANGS-screen.json')]
def norm(d,group,survey):
 o=d.get('v_observed_kms',d.get('v_observed_km_s'));v=d.get('v_SET_kms',d.get('v_SET_km_s'));r=d.get('R_kpc',d.get('Rcmp_kpc'));m=d['Mbar_Msun'];f=d['f_image'];ref=math.sqrt(G*m/r)
 e=d.get('ev_observed_kms',d.get('ev_observed_km_s',d.get('velocity_error_km_s')))
 n=d.get('v_Newton_kms',d.get('v_Newton_km_s'))
 assert math.isclose(v,4/f*ref,rel_tol=1e-12)
 qflags=d.get('quality_flags',{})
 return dict(name=d['name'],survey=survey,group=group,R_kpc=r,Mbar_Msun=m,f_image=f,v_SET_km_s=v,v_observed_km_s=o,velocity_range_km_s=e,v_Newton_km_s=n,residual_pct=100*(v/o-1),reference_km_s=ref,x=v/ref,y=o/ref,dy=e/ref if e is not None else None,inside_own_observation_range=abs(v-o)<=e if e is not None else None,large_side_asymmetry=d.get('large_side_asymmetry',False),quality_flags=qflags,secondary_quality=qflags.get('acceptance')==2 or qflags.get('inclination30to40',False),source_alias=d.get('S4G_name'),Q_m3_s=d.get('Q_m3_s'),A_image_m2=d.get('A_image_m2'),S_km_s=d.get('S_km_s'),comparison_at_last_rotation_point=d.get('at_last_rotation_point',d.get('comparison_at_last_point')),comparison_radius_rule='Outermost actual rotation bin bracketed by qualified free-isophote image; not a separately proven enclosing source boundary')
old=[]
for p in old_paths:
 for d in json.loads(p.read_text())['rows']:old.append(norm(d,'Existing 62',d.get('survey','Original20')))
assert len(old)==62
screen=[];diagnostics=[];additions=[];hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in old_paths};attempts={}
for survey,n in files:
 p=HERE/'screen'/n
 if not p.exists():continue
 d=json.loads(p.read_text());hashes[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest();attempts[survey]=d.get('summary',{})
 for r in d['rows']:
  if r.get('status')!='calculated':continue
  z=norm(r,'New run',survey);z['source_record']=str(p.relative_to(ROOT))
  if survey=='PHANGS CO' or not r.get('quality_orientation_eligible',True) or r.get('quality_flags',{}).get('supplemental_only',False):
   diagnostics.append(z);continue
  screen.append(z)
  if 'new_success' in r:keep=r['new_success']
  else:keep=r.get('central_within10',False)
  if keep:additions.append(z)
allrows=old+additions
assert len({r['name'] for r in allrows})==len(allrows)
assert all(abs(r['residual_pct'])<=10+1e-9 for r in allrows)
N=len(allrows);A=len(additions);nn=sum(r['v_Newton_km_s'] is not None for r in allrows)
summary=dict(existing=62,additional=A,total=N,requested_additional=60,target_met=A>=60,new_eligible_calculations=len(screen),new_within10=A,median_absolute_difference_new_pct=statistics.median(abs(r['residual_pct']) for r in additions),median_absolute_difference_displayed_pct=statistics.median(abs(r['residual_pct']) for r in allrows),inside_own_observation_range=sum(r['inside_own_observation_range'] is True for r in allrows),resolved_Newtonian_comparisons=nn,source_summaries=attempts,input_sha256=hashes)
(OUT/'EXPANSION-RESULTS.json').write_text(json.dumps(dict(summary=summary,additional_rows=additions,displayed_rows=allrows,complete_new_calculated_screen=screen,additional_calculated_diagnostics=diagnostics),indent=2))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10.5,'axes.spines.top':False,'axes.spines.right':False,'text.color':'#263442','axes.labelcolor':'#263442','svg.fonttype':'none'})
blue,teal,orange,gray='#365caf','#087f8c','#c77825','#65717c';green,violet,ve='#dfeee4','#d9ccf1','#8b6db3'
def save(fig,name):
 for ext in ['png','svg','pdf']:fig.savefig(OUT/f'{name}.{ext}',dpi=240,facecolor='white')
 plt.close(fig)
# Requested landscape format, same normalization and two distinct shade meanings.
fig,ax=plt.subplots(figsize=(14.8,7.6));x=np.linspace(.65,2.2,500);ax.fill_between(x,x/1.1,x/.9,color=green,zorder=0)
ss=sorted(allrows,key=lambda r:r['x']);xx=np.array([r['x'] for r in ss]);assert np.all(np.diff(xx)>0)
edges=np.r_[xx[0]-(xx[1]-xx[0])/2,(xx[:-1]+xx[1:])/2,xx[-1]+(xx[-1]-xx[-2])/2]
for i,r in enumerate(ss):
 if r['dy'] is None:continue
 l,h=edges[i:i+2];dy=r['dy'];ax.add_patch(Polygon([(l,l-dy),(h,h-dy),(h,h+dy),(l,l+dy)],closed=True,facecolor=violet,edgecolor='none',alpha=.78,zorder=1))
 ax.plot([l,h],[l+dy,h+dy],c=ve,lw=.4,alpha=.7);ax.plot([l,h],[l-dy,h-dy],c=ve,lw=.4,alpha=.7)
ax.plot(x,x,c='#495664',ls='--',lw=1.1,zorder=3);ax.axvline(1,c='#9ba4ad',ls=':',lw=.9,zorder=0)
for r in allrows:
 if r['v_Newton_km_s'] is not None:
  nx=r['v_Newton_km_s']/r['reference_km_s'];ax.plot([nx,r['x']],[r['y']]*2,c='#d9dee3',lw=.55,zorder=0);ax.scatter(nx,r['y'],c=orange,marker='x',s=26,lw=1.1,zorder=4)
 color=blue if r['group']=='Existing 62' else teal;marker='D' if r['large_side_asymmetry'] else ('^' if r['secondary_quality'] else 'o')
 ax.scatter(r['x'],r['y'],edgecolors=color,facecolors='white' if marker!='o' else color,marker=marker,s=40 if marker!='o' else 34,lw=1.1,zorder=5)
ax.set(xlim=(.65,2.20),ylim=(.60,3.10),xlabel=r'Calculated speed / $\sqrt{G M_{\rm bar}/R}$',ylabel=r'Observed speed / $\sqrt{G M_{\rm bar}/R}$');ax.grid(alpha=.10)
leg=[Patch(facecolor=green,label='±10% speed-agreement band'),Patch(facecolor=violet,label='Individual velocity-range shadow (stepped)'),Line2D([],[],c='#495664',ls='--',label='Equal calculated and observed speed'),Line2D([],[],c=blue,marker='o',ls='',label='62 existing SET examples'),Line2D([],[],c=teal,marker='o',ls='',label=f'{A} new SET examples'),Line2D([],[],c=orange,marker='x',ls='',label=f'Newtonian baryons: {nn} available profiles')]
ax.legend(handles=leg,loc='upper left',fontsize=10,frameon=True,facecolor='white',edgecolor='white',framealpha=1)
fig.text(.075,.955,'Galaxy rotation: source-law calculations and measured speeds',fontsize=16,weight='bold');fig.text(.075,.919,f'{N} worked comparisons  |  {A} new examples from this run  |  Formula and central-input rules retained',fontsize=11,color=gray)
fig.subplots_adjust(left=.075,right=.975,top=.88,bottom=.20)
fig.text(.075,.120,'Purple cells use each galaxy’s own recorded velocity range; cell joins are for display, not interpolation.',fontsize=10,color=gray)
fig.text(.075,.086,'Open diamonds: larger side asymmetry. Open triangles: Apertif A2 model or inclination below 40°; flags remain in the table.',fontsize=9.5,color=gray)
fig.text(.075,.051,'The green band is an agreement criterion. Heterogeneous recorded errors/ranges are not a common confidence interval.',fontsize=9.5,color=gray)
save(fig,f'galaxy-comparison-{N}-landscape')
# Named new examples.
rr=sorted(additions,key=lambda r:r['v_observed_km_s']);fig,ax=plt.subplots(figsize=(11.8,max(6.5,.30*A+2)))
y=np.arange(A)
for k,r in enumerate(rr):
 ax.plot([r['v_observed_km_s'],r['v_SET_km_s']],[k,k],color='#ccd6dc',lw=1.4)
 ax.errorbar(r['v_observed_km_s'],k,xerr=r['velocity_range_km_s'],fmt='o',color=gray,ms=4,capsize=2,elinewidth=1)
 ax.scatter(r['v_SET_km_s'],k,c=teal,s=32,zorder=3)
ax.set_yticks(y,[r['name'] for r in rr]);ax.invert_yaxis();ax.set_xlabel('Speed at the comparison radius (km/s)');ax.grid(axis='x',alpha=.15)
ax.legend(handles=[Line2D([],[],marker='o',c=teal,ls='',label='SET calculation'),Line2D([],[],marker='o',c=gray,ls='',label='Observed; recorded velocity range')],loc='upper right',frameon=False)
fig.suptitle(f'{A} additional galaxy calculations',x=.22,y=.97,ha='left',weight='bold',fontsize=15);fig.subplots_adjust(left=.22,right=.96,top=.91,bottom=.09);save(fig,'new-galaxy-comparisons')
# Every eligible calculable new result, including misses, for the research record.
fig,ax=plt.subplots(figsize=(12.8,6.5));ax.axhspan(-10,10,color=green);ax.axhline(0,color=gray,ls='--',lw=1)
colors=['#365caf','#087f8c','#ad658c','#c77825','#7b863b','#8a69aa','#b34046']
for (label,_),color in zip(files,colors):
 rr=[r for r in screen if r['survey']==label]
 if rr:ax.scatter([r['v_observed_km_s'] for r in rr],[r['residual_pct'] for r in rr],s=34,color=color,label=f'{label} ({len(rr)})',alpha=.88)
ax.set(xlabel='Observed speed at the comparison radius (km/s)',ylabel='100 × (SET / observed − 1)  [%]');ax.grid(alpha=.15);ax.legend(loc='best',frameon=True,fontsize=9)
fig.suptitle(f'Complete new calculation screen: {len(screen)} eligible galaxies',x=.09,y=.97,ha='left',weight='bold',fontsize=15);fig.subplots_adjust(left=.09,right=.97,top=.90,bottom=.18)
fig.text(.09,.07,f'{A} central agreements within ±10%; all calculated outcomes shown. Missing-input and invalid-geometry cases are in the ledger.',fontsize=10,color=gray);save(fig,'complete-new-screen')
lines=['SET GALAXY EXPANSION — RESULTS FOR REVIEW','',f'Existing paper:62 distinct galaxies. This run:{A} additional central agreements within10%. Combined:{N}.',f'Target:60 additional. Target achieved:{A>=60}.',f'Eligible new calculated cases:{len(screen)}. Full outcomes retained in EXPANSION-RESULTS.json.',f'Median absolute speed difference among new displayed examples:{summary["median_absolute_difference_new_pct"]:.4f}%.','', 'Unchanged calculation: Q=4pi sqrt(2GMbar R^3); Aeff=fimage piR^2; S=Q/Aeff; vSET=S/sqrt2.', 'Central source measurements and comparison radius chosen before SET residual; no velocity normalization fitted.','', 'Name | Survey | R(kpc) | Mbar(Msun) | fimage | vSET(km/s) | vobs(km/s) | recorded range(km/s) | difference(%)']
for r in additions:lines.append(f'{r["name"]} | {r["survey"]} | {r["R_kpc"]:.6g} | {r["Mbar_Msun"]:.9g} | {r["f_image"]:.9g} | {r["v_SET_km_s"]:.6f} | {r["v_observed_km_s"]:.6f} | {r["velocity_range_km_s"]} | {r["residual_pct"]:+.6f}')
lines+=['','Figures retain the approved landscape normalization and separate±10% band from individual observation ranges. Additional flags and the full calculated-screen figure accompany the example graph.', 'No manuscript changes. No new luminosity calculation. The previously completed200-plus luminosity results remain reserved for the later revision.']
(OUT/'RESULTS-FOR-REVIEW.txt').write_text('\n'.join(lines)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['source_summaries','input_sha256']},indent=2))
