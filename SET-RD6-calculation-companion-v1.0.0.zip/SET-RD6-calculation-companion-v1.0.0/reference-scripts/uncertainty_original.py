"""Source-input uncertainty preview; frozen calculations, no fitted values.

Reported marginal widths are Gaussian sensitivity inputs. Missing errors stay
fixed, not measured zero. Original twenty reproduce their archived source draws.
Independent observed-velocity noise is not sampled: its recorded ranges appear
separately. Shared distance/inclination transformations are applied exactly.
"""
from pathlib import Path
import csv
import hashlib
import json
import math
import os
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = HERE / 'results/source-uncertainty-preview'
OUT.mkdir(parents=True, exist_ok=True)
os.environ['MPLCONFIGDIR'] = str(HERE / 'results/mpl-cache')
sys.path[:0] = [str(ROOT/'work/three-galaxy-set/vendor'),
                str(ROOT/'work/set-ngc3198-field-runtime')]
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle

OLD = ROOT/'outputs/set-classical-audit-20/audited-results.json'
NEW = HERE/'results/additional-calculations.json'
REC = HERE/'protocol/original20-source-only-intervals.json'
PS = HERE/'screen/PROBES-SPARC-UNCERTAINTY-INPUTS.json'
GU = HERE/'sources/GHASP-UMA-UNCERTAINTY-INPUTS.json'
N = 250000
SEED = 20261021062
QKEYS = ['p025', 'p16', 'median', 'p84', 'p975']

def read(p):
    return json.loads(p.read_text())

def quant(a):
    return dict(zip(QKEYS, map(float, np.quantile(a, [.025,.16,.5,.84,.975]))))

def area(t):
    e = np.sqrt(1-t)
    kernel = np.divide(np.arcsinh(e/np.sqrt(t)), e,
                       out=np.ones_like(e), where=e>1e-10)
    return 2*(1+t*kernel)

new = {r['name']:r for r in read(NEW)['rows']}
records = []
inventory = []
original_intervals = {r['name']:r for r in read(REC)['rows']}
for r in read(OLD)['rows']:
    z = original_intervals[r['name']]
    records.append(dict(name=r['name'], group='Original 20', survey='Original',
        nominal_ratio=r['v_SET_kms']/r['v_observed_kms'],
        v_SET_km_s=r['v_SET_kms'], v_obs_km_s=r['v_observed_kms'],
        obs_range_km_s=r['ev_observed_kms'],
        obs_range_kind='Listed rotation-bin error',
        ratio_source_only=z['source_input_ratio'],
        geometry_acceptance=z['geometry_acceptance'],
        draws=65536, seed=2026092209,
        source_record=str(REC.relative_to(ROOT)),
        missing_errors=z['unreported_errors_held_fixed'],
        fixed_recipe='Archived original model: M/L, gas flux at fixed D and decomposition held fixed; unavailable errors held fixed.'))

for z in read(PS)['rows']:
    p=z['parameters']; r=new[z['name']]
    entry=dict(name=z['name'], survey=z['survey'],
        D=p['distance']['value'], eD=p['distance']['reported_uncertainty'],
        p=p['projected_axis_ratio']['value'], ep=p['projected_axis_ratio']['reported_uncertainty'],
        inc=p['inclination']['value'], einc=p['inclination']['reported_uncertainty'],
        star=r['Mstar_Msun'], gas=r['Mgas_Msun'],
        source_record=str(PS.relative_to(ROOT)), shared_inclination=True,
        missing_errors=z['held_fixed_unreported'])
    if z['survey']=='SPARC':
        lum=p['luminosity_3p6']
        entry.update(star_kind='linear', estar=lum['reported_uncertainty']/lum['value'],
                     gas_kind='fixed', egas=None)
    else:
        entry.update(star_kind='magnitude', estar=p['total_AB_magnitude_3p6']['reported_uncertainty'],
                     gas_kind='magnitude', egas=p['HI_magnitude']['reported_uncertainty'])
    inventory.append(entry)

for z in read(GU)['rows']:
    r=new[z['name']]
    inventory.append(dict(name=z['name'], survey=z['dataset'], D=z['D_Mpc'],
        eD=z['e_D_Mpc'], p=z['p'], ep=z['ep'], inc=z['inclination_deg'],
        einc=z['e_inclination_deg'], star=r['Mstar_Msun'], gas=r['Mgas_Msun'],
        star_kind='magnitude', estar=z['emag1'],
        gas_kind='magnitude' if z['HI_input_kind']=='m21' else 'linear',
        egas=z['e_m21'] if z['HI_input_kind']=='m21' else z['e_FHI_Jy_km_s']/z['FHI_Jy_km_s'],
        shared_inclination=z['shared_inclination_with_velocity'],
        source_record=str(GU.relative_to(ROOT)), missing_errors=z['missing_errors']))
assert len(inventory)==42 and len({r['name'] for r in inventory})==42

for z in sorted(inventory, key=lambda r:r['name']):
    r = new[z['name']]
    # Stable per-name seed; no ordering or selection based on the residual.
    seed = SEED + int(hashlib.sha256(z['name'].encode()).hexdigest()[:8],16)
    rng = np.random.default_rng(seed)
    D = rng.normal(z['D'], z['eD'] or 0, N)
    p = rng.normal(z['p'], z['ep'], N)
    ideg = rng.normal(z['inc'], z['einc'] or 0, N) % 180
    ideg = np.minimum(ideg, 180-ideg)  # equivalent plane orientations
    inc = np.deg2rad(ideg)
    t = (p*p-np.cos(inc)**2)/np.maximum(np.sin(inc)**2, 1e-300)
    star_delta = rng.normal(0, z['estar'] or 0, N)
    star_factor = 10**(-.4*star_delta) if z['star_kind']=='magnitude' else 1+star_delta
    gas_delta = rng.normal(0, z['egas'] or 0, N)
    gas_factor = 10**(-.4*gas_delta) if z['gas_kind']=='magnitude' else 1+gas_delta
    geometry = (p>0)&(p<=1)&(inc>1e-8)&(t>0)&(t<=1)
    domain = (D>0)&(star_factor>0)&(gas_factor>0)
    good = geometry & domain
    assert good.sum() > 10000
    d = D[good]/z['D']
    f = area(t[good])
    weighted_flux = (z['star']*star_factor[good]+z['gas']*gas_factor[good])/(z['star']+z['gas'])
    v = r['v_SET_km_s']*r['f_image']/f*np.sqrt(d*weighted_flux)
    obs = r['v_observed_km_s']*(np.sin(np.deg2rad(z['inc']))/np.sin(inc[good]) if z['shared_inclination'] else np.ones(good.sum()))
    ratio = v/obs
    # Independently recover speed through Q/area after the coupled rescaling.
    qratio = np.sqrt(d**5*weighted_flux)
    aratio = d*d*f/r['f_image']
    assert np.allclose(v/r['v_SET_km_s'], qratio/aratio, rtol=2e-14)
    t0=(z['p']**2-math.cos(math.radians(z['inc']))**2)/math.sin(math.radians(z['inc']))**2
    assert math.isclose(float(area(np.array([t0]))[0]), r['f_image'], rel_tol=1e-10)
    records.append(dict(name=z['name'], group='Additional 42', survey=z['survey'],
        nominal_ratio=r['v_SET_km_s']/r['v_observed_km_s'],
        v_SET_km_s=r['v_SET_km_s'], v_obs_km_s=r['v_observed_km_s'],
        obs_range_km_s=r['velocity_error_km_s'],
        obs_range_kind='Descriptive dispersion / side range' if z['survey'] in ['GHASP','PROBES'] else 'Listed rotation-bin error',
        ratio_source_only=quant(ratio), v_SET_source_only=quant(v),
        mass_source_only_Msun=quant((z['star']+z['gas'])*d*d*weighted_flux),
        radius_source_only_kpc=quant(r['Rcmp_kpc']*d),
        Q_source_only_m3_s=quant(r['Q_m3_s']*qratio),
        geometry_acceptance=float(geometry.mean()), valid_fraction=float(good.mean()),
        draws=N, accepted_draws=int(good.sum()), seed=seed,
        source_record=z['source_record'], missing_errors=z['missing_errors'],
        shared_inclination=z['shared_inclination'],
        fixed_recipe='Fixed M/L .5/.7, B/T, angular comparison radius, omitted error terms; no observed-speed sampling or tuning.'))

assert len(records)==62 and len({r['name'] for r in records})==62
for r in records:
    q=r['ratio_source_only']; e=r['obs_range_km_s']/r['v_obs_km_s']
    r.update(obs_relative_range=e,
        nominal_inside_obs_range=bool(abs(r['nominal_ratio']-1)<=e),
        source68_contains_equality=bool(q['p16']<=1<=q['p84']),
        source95_contains_equality=bool(q['p025']<=1<=q['p975']),
        source68_overlaps_obs_range=bool(q['p16']<=1+e and q['p84']>=1-e),
        source95_overlaps_obs_range=bool(q['p025']<=1+e and q['p975']>=1-e))
summary = {k:sum(r[k] for r in records) for k in [
    'nominal_inside_obs_range','source68_contains_equality','source95_contains_equality',
    'source68_overlaps_obs_range','source95_overlaps_obs_range']}
summary.update(objects=62,
    no_source95_obs_overlap=[r['name'] for r in records if not r['source95_overlaps_obs_range']],
    no_source68_obs_overlap=[r['name'] for r in records if not r['source68_overlaps_obs_range']],
    minimum_geometry_acceptance=min(r['geometry_acceptance'] for r in records),
    source_only_not_statistical_confirmation=True,
    interpretation='Overlap of partial conditional input-propagation segments with heterogeneous listed/descriptive velocity ranges. Not a common-confidence test, a fitted central improvement or catalogue-wide coverage.')
assert summary['nominal_inside_obs_range']==41

payload=dict(summary=summary, new_input_ledger=inventory, rows=records,
    input_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [OLD,NEW,REC,PS,GU]},
    method='Original20 unchanged archived source draws; new42 independent Gaussian reported marginal widths, conditioned on positive source inputs and valid oblate shape. Shared D used in both masses and radius. Shared i used in shape and observed deprojection only when same measurement; UGC06894 uses distinct global/ring i. Missing errors fixed. M/L fixed. Velocity-error ranges separate, not resampled.')
(OUT/'source-uncertainty-results.json').write_text(json.dumps(payload,indent=2)+'\n')
ordered=sorted(records,key=lambda r:(r['group']!='Original 20',r['name']))
with (OUT/'source-uncertainty-table.csv').open('w',newline='') as f:
    fields=['name','group','survey','v_SET_km_s','v_obs_km_s','obs_range_km_s','nominal_ratio',*QKEYS,'geometry_acceptance','source68_contains_equality','source95_contains_equality','source68_overlaps_obs_range','source95_overlaps_obs_range']
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for r in ordered:w.writerow({k:r['ratio_source_only'][k] if k in QKEYS else r[k] for k in fields})

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
    'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none',
    'text.color':'#253442','axes.labelcolor':'#253442'})
blue,teal,green,purple,gray='#365caf','#087f8c','#e5f1e9','#d8c8ef','#627180'
fig,axes=plt.subplots(1,2,figsize=(16.5,11.4),sharex=True)
for ax,chunk in zip(axes,[ordered[:31],ordered[31:]]):
    ax.axvspan(-10,10,color=green,zorder=0)
    for j,r in enumerate(chunk):
        y=len(chunk)-1-j
        e=100*r['obs_relative_range'];q=r['ratio_source_only']
        color=blue if r['group']=='Original 20' else teal
        formal=r['obs_range_kind']=='Listed rotation-bin error'
        ax.add_patch(Rectangle((-e,y-.31),2*e,.62,facecolor=purple,
            edgecolor='#b6a0d0' if formal else 'none',linewidth=.5,
            alpha=.80 if formal else .48,zorder=1))
        ax.plot([100*(q['p025']-1),100*(q['p975']-1)],[y,y],c=color,lw=1.0,zorder=3)
        ax.plot([100*(q['p16']-1),100*(q['p84']-1)],[y,y],c=color,lw=3.0,solid_capstyle='butt',zorder=4)
        ax.scatter(100*(r['nominal_ratio']-1),y,s=25,c=color,edgecolors='white',linewidths=.55,zorder=5)
    ax.axvline(0,c='#334656',ls='--',lw=.9,zorder=2)
    ax.set_yticks(range(len(chunk)))
    ax.set_yticklabels([r['name'] for r in chunk[::-1]],fontsize=8.5)
    ax.tick_params(axis='y',length=0,pad=6)
    ax.set(xlim=(-65,65),ylim=(-.8,len(chunk)-.2),xlabel=r'$100\,(v_{\rm SET}/v_{\rm obs}-1)$  (%)')
    ax.set_xticks([-60,-40,-20,0,20,40,60]);ax.grid(axis='x',alpha=.12)
fig.subplots_adjust(left=.09,right=.98,top=.82,bottom=.18,wspace=.26)
fig.text(.045,.965,'Galaxy rotation: uncertainty in SET’s calculation inputs',fontsize=20,weight='bold')
fig.text(.045,.931,'62 worked examples  •  Original central calculations preserved  •  Mass, radius and shape propagated together',fontsize=11.7,color=gray)
handles=[Line2D([],[],c=blue,marker='o',lw=3,label='Original 20: SET input range'),
         Line2D([],[],c=teal,marker='o',lw=3,label='Additional 42: SET input range'),
         Patch(facecolor=purple,alpha=.8,label='Recorded observational range'),
         Patch(facecolor=green,label='±10% agreement region')]
fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.52,.904),ncol=2,
    fontsize=10.8,frameon=False,columnspacing=3.2)
fig.text(.52,.837,
    f"Overlap with recorded observation ranges: {summary['source68_overlaps_obs_range']}/62 (thick segments), "
    f"{summary['source95_overlaps_obs_range']}/62 (thin segments)",
    ha='center',fontsize=11.0,color='#314b59')
fig.text(.09,.125,'Dots: unchanged nominal results. Thick / thin segments: central 68% / 95% of conditional source-input draws.',fontsize=10.5,color=gray)
fig.text(.09,.098,'Purple rows show each object’s own velocity range: outlined = listed error; pale = descriptive dispersion / side range.',fontsize=10.3,color=gray)
fig.text(.09,.071,'Distance changes mass and radius together; shared inclination changes both geometry and velocity deprojection.',fontsize=10.3,color=gray)
fig.text(.09,.044,'Unreported errors and mass-to-light ratios remain fixed. Source intervals are partial and conditioned on valid oblate geometry.',fontsize=10.3,color=gray)
for ext in ['png','svg']:
    fig.savefig(OUT/f'galaxy-input-uncertainty-landscape.{ext}',dpi=260,facecolor='white')
plt.close(fig)
(OUT/'README.txt').write_text('''SOURCE-INPUT UNCERTAINTY REVIEW PREVIEW

No manuscript, central calculation, original approved plot, radius choice or source value changed.

The new figure shows all62 existing worked examples. Dots preserve the original nominal ratios. The thick and thin intervals are the central68% and95% quantiles of conditional source-input draws. Purple bands separately show each object's recorded velocity error or descriptive dispersion/side range. An overlap is an overlap of these specified ranges, not a calibrated significance test or a claim of exact equality.

The mass/radius distance covariance is exact: Mbar scales as D^2, R as D, and vSET as sqrt(D) at fixed angular bin and source fluxes. Inclination is shared between image deprojection and observed velocity where it is the same measurement. UGC06894 has different global image and outer-ring inclinations; its image inclination error is not applied to the observed speed. Source Q and effective area are recalculated consistently; their ratio exactly reproduces the propagated speed.

For42 additions,250000 draws per object use reported marginal widths as Gaussian sensitivity inputs, with no fitted error scale. Invalid oblate draws are counted and excluded, never forced to zero thickness. Folded inclinations represent equivalent plane orientations, matching the original20 protocol. Source intervals may be asymmetric and may not be centered at the nominal point. Original20 source draws are recovered exactly from the archived65536-draw model, removing only independent velocity noise.

Availability limits:30PROBES galaxies lack quoted inclination error;10GHASP plusUGC06894 lack uncertainty on their adopted distances; originalNGC4565 lacks several reported source errors. Other missing covariance, decomposition and calibration errors are documented in the inventories. M/L, B/T and angular bins remain fixed, as in the central calculation. Thus these are partial input-propagation intervals, not a claim to include every systematic. Broader covariance or new M/L distributions were not invented to achieve overlap. Observation ranges are not converted into Gaussian draws.

The full screen remains separate from these62 worked examples. Their displayed overlap count is descriptive for these examples, not an unbiased catalogue test.

The JSON supplies all inputs, intervals, valid fractions, seeds, file hashes and overlap flags. The CSV is the plotted table. Source files are traced through the two inventory JSONs and the recovered original20 archive. The drawing is a review preview and has not been inserted into the paper.

''' + json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
