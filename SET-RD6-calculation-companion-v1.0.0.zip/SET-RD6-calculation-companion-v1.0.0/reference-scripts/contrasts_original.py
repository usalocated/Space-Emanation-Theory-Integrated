"""Fixed, unoptimised distance laws against predeclared redshift contrasts.

No intercept, shape parameter, or source parameter is estimated here.
The input magnitudes already contain the surveys' published standardisation.
"""
from pathlib import Path
import os, sys, json, hashlib
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[1]
os.environ['OPENBLAS_NUM_THREADS']='1'; os.environ['OMP_NUM_THREADS']='1'
sys.path.insert(0,str(ROOT/'work/set-ngc3198-field-runtime'))
import numpy as np
from scipy.linalg import cho_factor,cho_solve
from scipy.integrate import quad

DATA=HERE.parent/'set-dark-energy-observations-2026-10-13/prepared'
BINS=[.10,.20,.35,.50,.65,.80,1.,1.3,2.4]
G=6.67430e-11; C=299792458.; MPC=3.0856775814913673e22
M=1.5005279083130905e53; R=4.399239669750072e26
V=4*np.pi*R**3/3; Q=4*np.pi*np.sqrt(2*G*M*R**3)
H_B=Q/(3*V); H_CC=67.591866/MPC*1000 # archived rate control; its history was SN-conditioned
OMEGA_B=(H_B/H_CC)**2

def equal_object_weights(ids, mask, variance=None):
    out=np.zeros(len(ids)); selected=ids[mask]
    unique,count=np.unique(selected,return_counts=True)
    for cid,n in zip(unique,count):
        take=mask&(ids==cid)
        out[take]=1/n if variance is None else 1/(n*variance[take])
    out/=out.sum()
    return out

def distances(z,zh):
    """dimensionless H0*dL/c; heliocentric correction applied once."""
    y=1+z; pref=1+zh
    eds=2*pref*(1-y**-.5)
    empty=.4*pref*(y-y**-1.5)
    # Archived control, not independent: this rate's earlier history was
    # conditioned on supernovae. The separate measured-motion test uses masers.
    om=OMEGA_B
    mattig=2/om**2*(om*z+(om-2)*(np.sqrt(1+om*z)-1)) * pref/y
    # Fixed conventional reference, never fitted to this catalogue.
    reference=pref*np.array([quad(lambda q:1/np.sqrt(.3*(1+q)**3+.7),0,t,
                                 epsabs=2e-11,epsrel=2e-11)[0] for t in z])
    return {'source_volume_export':eds,
            'source_volume_export_empty_beam':empty,
            'constant_Q_volume_export':.5*pref*(1-y**-2),
            'coasting_flat':pref*np.log1p(z),
            'ballistic_Milne':pref*np.sinh(np.log1p(z)),
            'open_baryon_dust_external_rate':mattig,
            'constant_H':pref*z,
            'fixed_reference_Omega_m_0.3':reference}

def main():
    output={'protocol':(HERE/'protocol.txt').read_text(),
            'fitted_parameters':0,
            'constants':dict(G=G,c=C,M=M,R=R,V=V,Q=Q,H_source_km_s_Mpc=H_B*MPC/1000,
                             H_archived_SN_conditioned_control_km_s_Mpc=H_CC*MPC/1000,Omega_b_archived_control=OMEGA_B),
            'catalogues':{}}
    mode=sys.argv[1] if len(sys.argv)>1 else 'equal_object'
    assert mode in ['equal_object','published_uncertainty']
    output['weighting_mode']=mode
    for name,fn in [('Pantheon+','pantheon-observations.npz'),('DES-Dovekie','des-dovekie-observations.npz')]:
        path=DATA/fn; d=np.load(path)
        mask=d['published_SN_only_mask'] if name=='Pantheon+' else np.ones(len(d['CID']),bool)
        ids=d['CID'][mask];z=d['zHD'][mask];zh=d['zHEL'][mask]
        m=d['m_b_corr'][mask] if name=='Pantheon+' else d['MU'][mask]
        variance=None
        if mode=='published_uncertainty':
            variance=np.diag(d['covariance_stat_sys'])[mask] if name=='Pantheon+' else d['MUERR'][mask]**2
        anchor=(z>.025)&(z<.10);wa=equal_object_weights(ids,anchor,variance)
        rows=[];weights=[]
        for lo,hi in zip(BINS[:-1],BINS[1:]):
            b=(z>=lo)&(z<hi)
            if not b.any():continue
            w=equal_object_weights(ids,b,variance);weights.append(w-wa)
            rows.append(dict(z_lo=lo,z_hi=hi,z_mean=float(w@z),n_rows=int(b.sum()),
                             n_objects=len(np.unique(ids[b])), observed_magnitude_contrast=float((w-wa)@m)))
        L=np.array(weights)
        assert np.allclose(L@np.ones(len(m)),0,atol=1e-14)
        if name=='Pantheon+':
            C0=d['covariance_stat_sys'][np.ix_(mask,mask)];C0=(C0+C0.T)/2
            cov=L@C0@L.T
        else:
            P=d['precision_stat_sys'];P=(P+P.T)/2
            cov=L@cho_solve(cho_factor(P,lower=True),L.T)
        cf=cho_factor(cov,lower=True)
        errors=np.sqrt(np.diag(cov));pred=distances(z,zh)
        baseline=5*np.log10(pred['source_volume_export']);data_delta=L@(m-baseline)
        for row,err,delta in zip(rows,errors,data_delta):
            row.update(sigma_mag=float(err),delta_mag_vs_source_export=float(delta),
                       required_flux_factor=float(10**(-.4*delta)),
                       required_flux_factor_1sigma_low=float(10**(-.4*(delta+err))),
                       required_flux_factor_1sigma_high=float(10**(-.4*(delta-err))))
        models={}
        for key,dl in pred.items():
            expected=L@(5*np.log10(dl));res=L@m-expected
            models[key]=dict(expected_magnitude_contrasts=expected.tolist(),residual_mag=res.tolist(),
                             chi2_binned=float(res@cho_solve(cf,res)),n_contrasts=len(res),
                             rms_residual_mag=float(np.sqrt(np.mean(res**2))))
        output['catalogues'][name]=dict(n_rows=len(m),n_objects=len(np.unique(ids)),
            anchor_n_rows=int(anchor.sum()),anchor_n_objects=len(np.unique(ids[anchor])),
            anchor_mean_z=float(wa@z),input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            rows=rows,covariance_contrasts=cov.tolist(),models=models)
        np.savez_compressed(HERE/(name.lower().replace('+','plus')+'-'+mode+'-contrasts.npz'),
                            L=L,z=z,zHEL=zh,CID=ids,observed=m,covariance=cov)
        print(name,'anchor',anchor.sum(), 'bins',len(rows))
        for key,r in models.items():print(key,round(r['chi2_binned'],3),round(r['rms_residual_mag'],4))
        for r in rows:print(r['z_lo'],r['z_hi'],r['n_objects'],round(r['delta_mag_vs_source_export'],4),round(r['sigma_mag'],4),round(r['required_flux_factor'],4))
    output['limitations']=[
        'Equal-object anchor and bins were declared before this calculation; they discard within-bin shape information.',
        'Full published covariance is used for contrasts; the surveys still share calibration and supernovae.',
        'The fitted observational standardisation in released m/MU is retained; this is not raw-photon inference.',
        'Open baryon dust uses an archived chronometer-rate control whose history was SN-conditioned; it is not an independent source normalization. Separate tests use the maser H0 instead.',
        'Empty-beam propagation is conditional on the homogeneous dust background and metric optical coupling.',
        'Constant-Q export keeps a different quantity fixed from fixed-M source-volume export; these are distinct assumptions.',
        'The conventional reference is fixed at Omega_m=0.3 only as a scale of the residual, not as a SET result.'
    ]
    (HERE/('contrasts-'+mode+'.json')).write_text(json.dumps(output,indent=2))

if __name__=='__main__':main()
