"""Verify the mass tables and recover the surface moments from the exported angular quadrature, with Python alone."""
from collections import defaultdict
import csv
import gzip
import math
from pathlib import Path
import sys
D=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent

def records(name):
    with (D/name).open() as src:
        yield from csv.DictReader(src)

def main():
    model={r['id']:r for r in records('SET surface moments 389.csv')}
    cross={r['id']:r for r in records('Source profile crosswalk 389.csv')}
    shells=defaultdict(lambda: [0.,0.,0])
    ids_d={r['id'] for r in records('Stellar profiles 389.csv')}
    ids_g={r['id'] for r in records('Gas profiles 389.csv')}
    with gzip.open(D/'SET mass quadrature 389.csv.gz','rt') as f:
        for r in csv.DictReader(f):
            g=r['id'];x=float(r['radius_over_stellar_contour']);st=float(r['stellar_fraction_of_total_mass_at_node']);ga=float(r['gas_including_helium_fraction_of_total_mass_at_node'])
            assert 0<x and min(st,ga)>=0
            shells[g][0]+=st;shells[g][1]+=ga;shells[g][2]+=1
    angular=defaultdict(list)
    for r in records('SET surface integration points 389.csv'):
        assert 0<float(r['mu'])<1
        angular[r['id']].append((float(r['area_quadrature_weight_m2']),float(r['normalized_surface_loading_m_s'])))
    assert len(model)==389 and set(model)==set(cross)==set(shells)==set(angular)==ids_d==ids_g
    maxdev=0
    for g,row in model.items():
        areas,loads=zip(*angular[g])
        assert len(areas)==96 and min(areas)>0 and min(loads)>0
        surf=math.fsum(areas)
        m1=math.fsum(a*s for a,s in zip(areas,loads))
        m2=math.fsum(a*s*s for a,s in zip(areas,loads))
        ae=m1*m1/m2
        assert ae<=surf*(1+1.e-12)
        for value,key in [(surf,'geometric_area_m2'),(m1,'first_moment_Q_m3_s'),(m2,'second_moment_I_m4_s2'),(ae,'effective_area_m2'),(m2/m1/1000,'effective_burden_kms'),(m2/m1/1000/math.sqrt(2),'nominal_boundary_speed_kms')]:
            d=abs(value/float(row[key])-1);assert d<=2.e-12,(g,key,d)
            maxdev=max(d,maxdev)
        st,gas,n=shells[g]
        assert n==int(cross[g]['shell_node_count']) and math.isclose(st+gas,1.,abs_tol=1.e-11,rel_tol=0)
    print(f'{len(model)} galaxy identities, {sum(v[2] for v in shells.values())} mass nodes and {sum(len(v) for v in angular.values())} angular nodes checked. Maximum fractional error in six reconstructed quantities was {maxdev:.3g}.')
if __name__=='__main__':
    main()
