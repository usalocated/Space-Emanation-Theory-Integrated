"""Rebuild 389 nominal SET predictions from the mass nodes, oblate geometry and source law, using NumPy."""
from collections import defaultdict
from pathlib import Path
import csv
import gzip
import math
import sys
import numpy as np

GMSUN=1.3271244e20
KPC=3.085677581491367e19

def main():
    root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
    with (root/'SET surface moments 389.csv').open() as f:
        records=list(csv.DictReader(f))
    nodes=defaultdict(list)
    with gzip.open(root/'SET mass quadrature 389.csv.gz','rt') as f:
        for row in csv.DictReader(f):
            nodes[row['id']].append((float(row['radius_over_stellar_contour']),float(row['stellar_fraction_of_total_mass_at_node'])+float(row['gas_including_helium_fraction_of_total_mass_at_node'])))
    assert len(records)==len(nodes)==389
    leg_x,leg_w=np.polynomial.legendre.leggauss(96)
    mu=(1+leg_x)/2
    maxerr=np.zeros(4)
    for row in records:
        shell_r,weight=np.asarray(nodes[row['id']]).T
        q=float(row['intrinsic_axis_ratio'])
        R=float(row['nominal_reference_radius_kpc'])*KPC
        m=float(row['nominal_mass_msun'])
        # The oblate-shell potential depends on T=a²+tau. The positive exterior
        # root solves R_cyl²/T + z²/(T-k²)=1 with k²=a²(1-q²); an interior
        # point sees the constant interior potential (T=a²). Radii here use Rb=1.
        a=shell_r[:,None];k2=a*a*(1-q*q)
        z2=(q*mu)**2; rcyl2=1-mu**2
        v=rcyl2+z2
        T=np.maximum(a*a,(v+k2+np.sqrt((v-k2)**2+4*z2*k2))/2)
        f=np.sqrt(k2/T)
        theta=np.arcsin(np.clip(f,0.,1.))
        single=np.divide(theta,f,out=np.ones_like(theta),where=f>0)/np.sqrt(T)
        # Move from relative shell potential to loading amplitude via the source law.
        relative_s=np.sqrt(weight@single)
        area=(2*np.pi*R*R)*leg_w*np.sqrt(q*q+(1-q*q)*mu*mu)
        Q=4*np.pi*np.sqrt(2*GMSUN*m*R**3)
        s=relative_s*(Q/(area@relative_s))
        I=area@(s*s)
        Ae=Q*Q/I
        speed=(I/Q)/(1000*math.sqrt(2))
        ref=np.array([float(row[k]) for k in ['first_moment_Q_m3_s','second_moment_I_m4_s2','effective_area_m2','nominal_boundary_speed_kms']])
        delta=np.abs(np.array([Q,I,Ae,speed])/ref-1)
        maxerr=np.maximum(delta,maxerr)
        assert np.all(delta<1e-10),(row['id'],delta)
    print('Recovered all 389 nominal predictions from the shell masses. Max relative differences for Q, I, effective area and nominal speed:',*(f'{e:.3g}' for e in maxerr))

if __name__=='__main__':
    main()
