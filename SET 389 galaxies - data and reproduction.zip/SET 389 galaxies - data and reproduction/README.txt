SPACE EMANATION THEORY — THE SOURCE LAW AND GALAXY ROTATION AT THE STELLAR BOUNDARY
389-galaxy data and reproduction companion | Erik Echeverria | November 2026

The paper compares one matched boundary speed per physical galaxy. Start with
Tables/Galaxy results.csv and its column dictionary. One row gives the measured
stellar radius, source properties, measured speed, primary forecasts, errors,
quality information and identifiers. Tables/Model predictions and uncertainty.csv
lists all five forecasts, including both alternative fixed-halo calibrations.

Reproducing the paper
---------------------
After extracting this archive, open a terminal in the folder containing Tables,
Notes and Selection. The first four commands below use Python 3.9 or later and
its standard library. The last two additionally require NumPy.

python3 Notes/replay_geometry_and_draw.py
python3 Notes/check_primary.py
python3 Tables/verify_profile_tables.py
python3 Notes/replay_two_radii.py
python3 Tables/reconstruct_boundary_speeds.py
python3 Notes/replay_pooled_interval.py

The first script ranks all 294 original eligible canonical identifiers by
quality and seeded SHA-256 priority, checks the random 200 identities, scores
the three nominal geometry readings, and re-creates the 306-galaxy diagnostic.
The 189 additions are all distinct eligible additions accepted in the extension.

The next scripts reproduce all 389 target interpolations from 4,720 measured
rings, the released forecast scores, all surface moments from 37,344 surface
nodes, and the measured two-radius comparison. The NumPy shell reconstruction
then recovers each nominal speed directly from the 338,844 mass quadrature
nodes and intrinsic shape. It uses source data only. The final NumPy script
repeats the 30,000 whole-galaxy paired resamples with the archived seed and
ordering, verifying the pooled 95% intervals for all five models.

Nominal and scored speeds
-------------------------
The spherical, uniform oblate and two-moment comparisons use identical nominal
mass and equatorial radius. For the primary head-to-head comparison each galaxy
is represented by its released median forecast from 32,768 source-input draws.
The scripts rescore these released forecast medians. The full historical
three-model Monte Carlo runs and survey reductions are indexed in Notes/
Historical calculations and replay index.csv and held in Complete research
archive.zip. The compact package also supplies the original export and
worktree-preparation scripts under Notes for users with the complete archive.
See Tables/Reading the radial sources and integrations.txt for replay details.

Where the measurements came from
--------------------------------
Tables/Measurements and references by galaxy.csv gives each galaxy's
photometry, gas and kinematic sources. Tables/Galaxy imaging index.csv maps
each identifier to its infrared panel and original data reference. The Figures
folder preserves the historical atlases (200 and 189), six revised WALLABY
panels, and the two original residual-study graphics. Use the final-atlas
columns of the index for the audited distances. Thirteen galaxies have
Spitzer radial-profile panels. For all others the atlas uses infrared sky
fields. The earlier and later atlases use their original release file names.

The radio catalogues include Apertif, WALLABY, SPARC, WHISP and the smaller
observing programs identified in the per-galaxy references. Spitzer/S4G,
Spitzer archive products and unWISE provide infrared measurements. Retain
the corresponding survey credits when reusing a panel or measurement. The
stellar-to-halo relation is from Moster et al. and the fixed concentrations
are from Klypin et al. and Dutton & Macciò. The method note for baryonic and
halo forecasts identifies the force calculation and source publications.

Archive integrity
-----------------
SHA256SUMS.txt lists each delivered file except itself. From the extracted
root, run:

shasum -a 256 -c SHA256SUMS.txt
