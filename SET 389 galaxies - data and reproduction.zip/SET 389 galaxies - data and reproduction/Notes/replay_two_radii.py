"""Rebuild and check the two-radius table from the compact paper-writer packet.

Python 3.9+ standard library. From the packet's root, run:

    python3 Notes/replay_two_radii.py

Alternatively supply --packet PATH to the directory containing Tables.
Use --output PATH for an additional reconstructed CSV at a new filename.
"""
import argparse
import bisect
import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path


def records(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def grouped(rows):
    groups = defaultdict(list)
    for row in rows:
        groups[row["id"]].append(row)
    return groups


def interpolate(pairs, target):
    radii = [r for r, _ in pairs]
    if not radii[0] <= target <= radii[-1] or len(set(radii)) != len(radii):
        raise ValueError("The target must be bracketed by distinct radii.")
    i = bisect.bisect_left(radii, target)
    if radii[i] == target:
        return pairs[i], pairs[i], pairs[i][1]
    low, high = pairs[i - 1 : i + 1]
    fraction = (target - low[0]) / (high[0] - low[0])
    return low, high, low[1] + fraction * (high[1] - low[1])


def compute(tables):
    galaxies = records(tables / "Galaxy results.csv")
    rings = grouped(records(tables / "Observed rotation rings.csv"))
    if set(rings) != {r["id"] for r in galaxies}:
        raise ValueError("Ring and source tables must cover the same galaxies.")
    if len(galaxies) != 389 or len({r["id"] for r in galaxies}) != 389:
        raise ValueError("Expected the frozen 389 distinct galaxy records.")
    result = []
    for galaxy in galaxies:
        name, cohort, survey = (galaxy[k] for k in ("id", "cohort", "survey"))
        pairs = sorted((float(v["r_arcsec"]), float(v["observed_speed_kms"])) for v in rings[name])
        a = float(galaxy["a_arcsec"])
        lo, hi, v = interpolate(pairs, a)
        if not math.isclose(v, float(galaxy["observed_kms"]), abs_tol=1e-6):
            raise ValueError(f"{name}: failed to reproduce the primary observed speed")
        if pairs[-1][0] < 2 * a:
            continue
        lo2, hi2, v2 = interpolate(pairs, 2 * a)
        row = dict(
            galaxy=name, cohort=cohort, survey=survey, boundary_radius_arcsec=a,
            last_radius_arcsec=pairs[-1][0], observed_at_boundary_kms=v,
            observed_at_twice_boundary_kms=v2, observed_speed_ratio=v2/v,
            fixed_shape_inverse_radius_speed_ratio=1/math.sqrt(2),
            modeled_baryonic_mass_fraction_beyond_boundary=galaxy["baryons_outside_fraction"],
        )
        for tag, low, high in [("boundary", lo, hi), ("twice_boundary", lo2, hi2)]:
            row[f"{tag}_lower_ring_arcsec"], row[f"{tag}_lower_ring_kms"] = low
            row[f"{tag}_upper_ring_arcsec"], row[f"{tag}_upper_ring_kms"] = high
        row["distinct_brackets_both_widths_at_most_25pct_of_local_radius"] = (
            hi[0] < lo2[0] and hi[0] - lo[0] <= a/4 and hi2[0] - lo2[0] <= a/2
        )
        result.append(row)
    return result


def verify(result, path):
    with path.open(newline="", encoding="utf-8-sig") as f:
        ref = list(csv.DictReader(f))
    if len(ref) != len(result):
        raise ValueError(f"Different numbers of eligible galaxies ({len(ref)}, {len(result)})")
    for actual, old in zip(result, ref):
        if actual.keys() != old.keys():
            raise ValueError("Column headings differ.")
        for key, value in actual.items():
            if str(value) == old[key]:
                continue
            try:
                equal = math.isclose(float(value), float(old[key]), rel_tol=1e-12, abs_tol=1e-12)
            except ValueError:
                equal = False
            if not equal:
                raise ValueError(f"{old['galaxy']}, {key}: {value} versus {old[key]}")
    print(f"Verified all {len(ref)} rows and {len(ref[0])} columns.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--packet", type=Path, default=Path(__file__).resolve().parents[1],
                    help="Directory containing Tables (default: parent of Notes).")
    ap.add_argument("--output", type=Path, help="Write to a new CSV file.")
    args = ap.parse_args()
    tables = args.packet / "Tables"
    result = compute(tables)
    verify(result, tables / "Observed speed at one and two stellar contour radii.csv")
    if args.output:
        with args.output.open("x", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, result[0].keys())
            writer.writeheader()
            writer.writerows(result)
    for label, subset in [("All eligible", result), ("Distinct narrow brackets", [
        r for r in result if r["distinct_brackets_both_widths_at_most_25pct_of_local_radius"]
    ])]:
        values = [r["observed_speed_ratio"] for r in subset]
        print(f"{label}: {len(values)} galaxies, median {statistics.median(values):.6f}, "
              f"{sum(v > 1/math.sqrt(2) for v in values)} central ratios above 1/sqrt(2).")


if __name__ == "__main__":
    main()
