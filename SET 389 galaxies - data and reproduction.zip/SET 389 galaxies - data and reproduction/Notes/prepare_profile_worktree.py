"""Extract the 88 verified archive members needed to rebuild the 389 source and surface data tables.

Usage: python prepare_profile_worktree.py --package-root PATH --destination SCRATCH
Optional: add --rebuild-to GENERATED_TABLE_DIRECTORY with scipy and numpy installed.
The destination contains a work directory. Only existing identical files are reused.
"""
import argparse
import hashlib
from pathlib import Path
from zipfile import ZipFile
import subprocess
import sys

EXTENSION = 'outputs/RD8x additional galaxies/Data and reproducible calculations.zip'
POOLED = 'outputs/RD8x 389 galaxy residual study/Residual study data and calculations.zip'
SOURCES = {
    'work/389_patterns_root/analysis_data.csv': (POOLED, '9302d4d185a7742e629f94c07d835276cee40ca6724022eda5e7c0018232684f'),
    'work/consensus_gas/measured_fields.py': (EXTENSION, '07564e6607e7efa15f669aa26aeb3507c51683953dfe389b92208d74c25d4fa9'),
    'work/consensus_photometric/contour_uncertainty.py': (EXTENSION, '12657f9d2ec01c2b8e89d481a8a9950cfcf7d04107dc36ccd4b85b195e11c1cb'),
    'work/consensus_photometric/photometric_radii.py': (EXTENSION, 'e457f9bbeca2eb9b30fc04b266a4da123bd5eb9ebb459db61f9535d1ff3b5d8b'),
    'work/consensus_photometric/preferred_shells.py': (EXTENSION, '4888c42c88875d62a4c28d0a2a13a64fa23577293bde5eed6358577cdac9100b'),
    'work/consensus_review/revisit.py': (EXTENSION, 'b68c5e23e470f6ddf5938de5503d00eb0c2a63eb3ba2ade7d2df48781ea5d5d2'),
    'work/extra400_literature/hi_radial_profiles.csv': (EXTENSION, '45bac7ac814b1dc8c326f9bf7a3af114bb44aec5dbb770fa693e3446cf6528bb'),
    'work/extra400_literature/radio_sources.csv': (EXTENSION, 'aa8fe0e5503a963af9667406a5d7fb77f2b840d10fcd4ccee1438571c4e657c2'),
    'work/extra400_literature/ring_geometry.csv': (EXTENSION, 'cbe1e53715b80cf4c9079afe1e30fee3e5b9c2e74cc819a29ac28acf55540abe'),
    'work/extra400_literature/rotation_targets.csv': (EXTENSION, 'b65956d41b63f064828e35ca4c473f7bf9c99589a493aae29f1dd3c3485d57c2'),
    'work/extra400_photo/photometry.csv': (EXTENSION, '54769358af90e4c94b0e24de4031d1ca02685eadad06629f1d7fef23a48bd315'),
    'work/extra400_photo/sparc/annuli.csv': (EXTENSION, '3e08768fd8f264a7643313f0027586bf66eadb067e552b60ad1b32b4517ae6e7'),
    'work/extra400_photo/sparc/inputs.csv': (EXTENSION, 'c308e7a93759b85ac6d1d8c6d87b88ea5fd5beeae804fe11ffe02280138224ee'),
    'work/extra400_photo/sparc/model_audit.csv': (EXTENSION, 'd4f314a760793b08196ccecac240096a9b14347a34ea7b9fe7920a53569ac0a5'),
    'work/extra400_photo/stars.csv': (EXTENSION, '00ff5dcdd327da9a76a85366653f577f9dedf29ae798e0af5effa90548aaf424'),
    'work/extra400_radio/amiga_hi_radial_profiles.csv': (EXTENSION, '60f1c26b440b302c28cc49d4da0866432bb31353c3c85a783ad490b208b6a3ab'),
    'work/extra400_radio/amiga_ring_geometry.csv': (EXTENSION, '3b937c3d71f56b87c74af3bd4ac695f11e568e55f5a0fbfcf0e4da2ea2f4867f'),
    'work/extra400_radio/amiga_rotation_targets.csv': (EXTENSION, '6b2a1f278cab04cbc86823568b31975624db63dccfc4c5c32405731d3427d1f5'),
    'work/extra400_radio/amiga_sources.csv': (EXTENSION, '7f691cf26532e994d6935727af17cf2f94d963ca006ec13c11afb35e91dc0d43'),
    'work/extra400_radio/garcia_hi_radial_profiles.csv': (EXTENSION, 'c1870721bc5eee9401e1d4137265e097416b829fd0b6214d107310765b80cd52'),
    'work/extra400_radio/garcia_ring_geometry.csv': (EXTENSION, 'e9ac6183d98aeab80c8592de6036f43820ce7f5f01ebbe3d534b7bafbf656316'),
    'work/extra400_radio/garcia_rotation_targets.csv': (EXTENSION, 'cbd39f10e8b578e041be64e99e934f758fa6c585e300c9547ebd5c989c9e948a'),
    'work/extra400_radio/garcia_sources.csv': (EXTENSION, 'ad424c0349ebe3c48826cb69bc08bbd798e7e7f6a514dccaab8bc94e9e38fffb'),
    'work/extra400_radio/kur_hi_radial_profiles.csv': (EXTENSION, '51d0556a0648dc390c76418748fc290fc138420666bc04cab40755ea3a1de475'),
    'work/extra400_radio/kur_ring_geometry.csv': (EXTENSION, 'd83045f5ffc2d4313e285f9c3339049397b8527885288ce08290a3c04b2507ed'),
    'work/extra400_radio/kur_rotation_targets.csv': (EXTENSION, '4b56bec6e7569d43a1f2179c72a2d3b45ffd7eebec904e1fde955a0d4aa98ba1'),
    'work/extra400_radio/kur_sources.csv': (EXTENSION, '6adce3afbde384255ca5f812c711f926acb40e41db37c1ae7b98d569d3ceb9a5'),
    'work/extra400_radio/mh_hi_radial_profiles.csv': (EXTENSION, 'a59b080e68b173cf74f8461ddbef81aaede270c7f8fddbba836a9f0c9000c7f4'),
    'work/extra400_radio/mh_ring_geometry.csv': (EXTENSION, '25578f32eef7085d385869ed5ba4686e3ede513313cef82b48a7fcc07e0130f1'),
    'work/extra400_radio/mh_rotation_targets.csv': (EXTENSION, 'c24e85e97c7f8d4a945768d76072a16b3c296598e89998e5c4cee576f98334ba'),
    'work/extra400_radio/mh_sources.csv': (EXTENSION, 'ca63e0274e2efc5d099185d9e5eea472042fe24055191a0775c803b1c2ea3fae'),
    'work/extra400_radio/mightee_hi_radial_profiles.csv': (EXTENSION, 'a4e42a461c6e75f74de6f4aa0248bcd020c5a1f91ec0203880d2ea1cca966880'),
    'work/extra400_radio/mightee_ring_geometry.csv': (EXTENSION, '50a48f508821ffb5706b5533e718aea3680efdfd66a531e90abbcd8d4ae120f3'),
    'work/extra400_radio/mightee_rotation_targets.csv': (EXTENSION, '1d1d1ab35c02f24fb9f27800a24a3139c5d28972b6129435509848787b5551b2'),
    'work/extra400_radio/mightee_sources.csv': (EXTENSION, '4a3c461ea2c3d98349d0dd6148cefbfc49e785542bad5469f27db1328d08c09d'),
    'work/extra400_radio/rings_hi_radial_profiles.csv': (EXTENSION, '1c34ea2a37c791706a300ec688d398d436388f9c775d31fddb395c09c76f31ed'),
    'work/extra400_radio/rings_ring_geometry.csv': (EXTENSION, '3e6bae935044f336ca986f32c154d1ebd1f9cec375eee63e7d0253c8c41b9c63'),
    'work/extra400_radio/rings_rotation_targets.csv': (EXTENSION, 'd4c87452183ada9600f0d99a3fc678f488f416a276793bfc06758bd75f2540b2'),
    'work/extra400_radio/rings_sources.csv': (EXTENSION, '7bef77006bb34e96515414381c47fd43d9b0af8ceee5153afeb5a039ab78d0b6'),
    'work/extra400_radio/starburst_hi_radial_profiles.csv': (EXTENSION, '55cf3bed6fb698d88127aff7a9f3bb7bb8294e6193a9e93cadc5d94423ffcc90'),
    'work/extra400_radio/starburst_ring_geometry.csv': (EXTENSION, '21ecc37abbf142683d65eb8ea7f353953257d3a00b2d335eda479333c4290632'),
    'work/extra400_radio/starburst_rotation_targets.csv': (EXTENSION, 'fce80beec92554762b1f9dbc785cd7238694725e3fe3eaec472ebfc771fc6caf'),
    'work/extra400_radio/starburst_sources.csv': (EXTENSION, '77b5705df2a3cb7d2566683e5a59a9652fb0d0566fce99723cd38193e7e40612'),
    'work/extra400_radio/uma_hi_radial_profiles.csv': (EXTENSION, 'cdeada3812ceee3136971bc29116627523bb0457bd70febec837a19d03c63e6f'),
    'work/extra400_radio/uma_ring_geometry.csv': (EXTENSION, '7e8ca6a04d5bcb6d7f4e74b62ff6897e7c35458d1ea554507587485c6762ed4a'),
    'work/extra400_radio/uma_rotation_targets.csv': (EXTENSION, '58747e568edb4419dc62d2a35cabb1be117b4f709ac2c1ce0235a80c6398c2c1'),
    'work/extra400_radio/uma_sources.csv': (EXTENSION, '18ca01189a3c2ebe29a82d3f699740e28656193312f0e4537db73c773292178a'),
    'work/extra400_radio/ve_hi_radial_profiles.csv': (EXTENSION, '7498afade9d9b622eb4172c210589d4ee4e25869659c29cc1cdf4405a4c9a909'),
    'work/extra400_radio/ve_ring_geometry.csv': (EXTENSION, '384998e4ceeeb9fe1f6f20f13a4fe0213df349d767a03c15ff9b03741b36c104'),
    'work/extra400_radio/ve_rotation_targets.csv': (EXTENSION, 'c12073b6f818f98874809eac6d57b2bc8eed86b8ce91ec74e6db392bf308b253'),
    'work/extra400_radio/ve_sources.csv': (EXTENSION, '5fd44be14e64ac863f00da42b4d6d27925584068c9aa9307f05208cc5df5ea21'),
    'work/extra400_root/forecast.py': (EXTENSION, 'c6d21a39daf86ff8266e6274f047ab55e332a91ffd1b0ce9e5f8e1fcf5a14a0c'),
    'work/extra400_root/heritage/photometry.csv': (EXTENSION, '7eb70257593da06f682a3ddda54a9d260d4fc514f645237f5ca74b08f8da61a6'),
    'work/extra400_root/heritage/stars.csv': (EXTENSION, '7eb70257593da06f682a3ddda54a9d260d4fc514f645237f5ca74b08f8da61a6'),
    'work/extra400_root/neo11/photometry.csv': (EXTENSION, '5264390940ec3a55ff5c95bbf16b7d3727a03125e46ccee6be94067c82eb2b6f'),
    'work/extra400_root/neo11/stars.csv': (EXTENSION, 'e680f2c68de129b610208b237addbd180238a4ea548b7bce114065c5b6c9e8c4'),
    'work/extra400_root/recovery/photometry.csv': (EXTENSION, 'b6db25f83b4b7ea92f743972ede5dfc14adae6708825bd005b98ba06c43940f9'),
    'work/extra400_root/recovery/stars.csv': (EXTENSION, '16d6140f9255408a1a8706e411cefb9d65da05860262f0db1b71453ee67fcaa2'),
    'work/extra400_root/study.py': (EXTENSION, '3b1aa788ba65065a2d81187ad0f70d8477b3a6bbefa6fe78fc6ba35156d786cc'),
    'work/forty_halo.py': (EXTENSION, '06453de7c02b7ef5564179a6b93eb3b3e2d50ece3a83d11aea6fd9de01a3d2a5'),
    'work/forty_native_mc.py': (EXTENSION, '2ea82a63bf3d38513dbae3da085c870a28fee83566efb63cf35cf795181d736e'),
    'work/forty_sample/raw/Bulges.mrt': (EXTENSION, '5af4fb0706df8cd097eded2ca7749fe3fb3240314afed333f84ab8c00b662a84'),
    'work/forty_sample/raw/Rotmod_LTG.zip': (EXTENSION, '0a80cc90714828cc28b7dd57923576714d209f2490328c087c4a4ad607faf588'),
    'work/forty_sample/raw/SPARC_Lelli2016c.mrt': (EXTENSION, '5aa0501f6b0d881fa579030e315e7b5b6ef561a5bd3a07472f9929c7e5728243'),
    'work/large200_model/external.py': (EXTENSION, '9c6636b0541a720f4d0a28f757f6fac8c0ee77ca5ce8832dfe7f31acf423d39a'),
    'work/large200_model/gas_annuli.csv': (EXTENSION, 'c0f0416ba6d99b095817006685800d0de688f7374fb5970ad267db802122da00'),
    'work/large200_model/native_aux/forecasts.csv': (EXTENSION, '7339a275483c6b83040befc60fae7cc3546b71f0df3bc5dba4b1a918a807c467'),
    'work/large200_model/old/model_audit.csv': (EXTENSION, '98fcdcb420bf5b16e22bef878636f73c8337dc1a80bdf12d9796241f21e4d1e8'),
    'work/large200_model/old_input.csv': (EXTENSION, 'a8d037ee78dc99a319436881fecee284896489659034a32aef3ae00b47da9dc4'),
    'work/large200_model/subsequent/model_audit.csv': (EXTENSION, 'cf902aa43e754e4f4a0bd2e69bb94d2c66b4d4dfc84a40d765bc984116dbd233'),
    'work/large200_model/subsequent_input.csv': (EXTENSION, 'a89d9c68bc90f7091f71b3dbdb02dc2247233726568511b897a1d04b70b4cd9b'),
    'work/large200_radio/combined/hi_radial_profiles.csv': (EXTENSION, 'b8ae5a529597f63a7ac4dff08b58bf39f040af62efbb4c9935c0626f2cf834ef'),
    'work/large200_radio/combined/radio_sources.csv': (EXTENSION, 'fb9dd3ab5bb8b210975994f8cdea93ec6377d2f34ede61614a22231c98746da3'),
    'work/large200_radio/combined/ring_geometry.csv': (EXTENSION, '60c492d9601e2142c3f79f04296a03b97ba20a5344999aa1ebd72a85d85968d1'),
    'work/large200_radio/combined/rotation_targets.csv': (EXTENSION, '02596802401d092149b8dece267bfd0042f57eb46dbec50d11704619f8797018'),
    'work/large200_root/photometry.csv': (EXTENSION, 'e3b49fdff68fae63df1fbd5adf95fa2461834b518436422ce78ee58a0d6c1e2f'),
    'work/large200_root/stars.csv': (EXTENSION, '16d6140f9255408a1a8706e411cefb9d65da05860262f0db1b71453ee67fcaa2'),
    'work/new40_frame/flux_sigma.csv': (EXTENSION, '6286ac1ae0968ae4e29c9422d359ebf73bb83b50763d5dd3d121f90f08ccc6ff'),
    'work/new40_model/combined_inclinations.csv': (EXTENSION, '84cba256f8ddd23f33f477a59068aff8b5304237555f275f928de97989ffe4de'),
    'work/new40_model/predict.py': (EXTENSION, '5991447061047a9150e36c48a8b038fe0b3324a481f5ecb49fecf5ecc963055c'),
    'work/shape_sparc/BulgeDiskDec_LTG.zip': (EXTENSION, '0733de0d357cbd45c673fd4321a3b339e160abf68530684c09d28e413855fb6d'),
    'work/uncertainty_cauchy/field_uncertainty.py': (EXTENSION, 'a642676862573dc2875c4a92249ddb03322bee17d8c51ccf5ee750ced96485ed'),
    'work/uncertainty_cauchy/moments.py': (EXTENSION, 'f1f541ba2db148d588588e1982d4d80b19218a9bb9f2291195ccf45ccda2d2fb'),
    'work/uncertainty_cauchy/things_field.py': (EXTENSION, '7fa34c1ef882ddefb8160bc69e73f677303db7c48474c4c354829a9708063c51'),
    'work/uncertainty_lit_b/VS01_ring_data.csv': (EXTENSION, 'e67344aab6288dee80c3285b7fa6ba5772c1fa39e7c07267c01f9355e0354ef7'),
    'work/uncertainty_speeds/iorio_profiles.py': (EXTENSION, '03ac25aaa7c7f63d7cb435ef7762af940243c34b5ca72c51e8eb67418b9c042f'),
    'work/uncertainty_speeds/observer_inputs.csv': (EXTENSION, 'ff5ef0c5a36e4ee29194aad55cf597c608e66a5f2b1047b1b0fbe90356f455ff'),
    'work/uncertainty_speeds/predict_intervals.py': (EXTENSION, '79efac39c1b7ede9be11d1c3c190d7dfc17489c23f12caccde6575fa7c8eec43'),
}

def locate_root(request):
    if request is not None:
        root=Path(request).resolve()
        if (root/EXTENSION).is_file() and (root/POOLED).is_file():
            return root
        raise SystemExit('The specified package root must contain both original release ZIPs in outputs/.')
    checked=set()
    for location in (Path.cwd().resolve(),Path(__file__).resolve().parent):
        for root in (location,*location.parents):
            if root in checked: continue
            checked.add(root)
            if (root/EXTENSION).is_file() and (root/POOLED).is_file():
                return root
    raise SystemExit('Pass --package-root pointing to the extracted handoff directory that contains outputs/.')

def prepare(package_root,destination):
    from contextlib import ExitStack
    destination=destination.resolve()
    target=destination/'work'
    if (package_root/'work').resolve()==target:
        raise SystemExit('Use a separate scratch destination, outside the original work tree.')
    with ExitStack() as stack:
        archives={name:stack.enter_context(ZipFile(package_root/name)) for name in (EXTENSION,POOLED)}
        for member,(name,expected) in SOURCES.items():
            blob=archives[name].read(member)
            if hashlib.sha256(blob).hexdigest()!=expected:
                raise ValueError(f'Original release bytes failed SHA-256 verification: {member}')
            path=destination/member
            if path.exists():
                if not path.is_file() or path.read_bytes()!=blob:
                    raise ValueError(f'Destination already has a different file: {path}')
                continue
            path.parent.mkdir(parents=True,exist_ok=True)
            with path.open('xb') as f: f.write(blob)
    return target

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package-root',type=Path)
    parser.add_argument('--destination',type=Path,required=True)
    parser.add_argument('--rebuild-to',type=Path,help='Run the adjacent export_profiles.py and write the six tables here.')
    args=parser.parse_args()
    root=locate_root(args.package_root)
    directory=prepare(root,args.destination)
    print(f'Prepared {len(SOURCES)} verified original files in {directory}',flush=True)
    if args.rebuild_to:
        out=args.rebuild_to.resolve()
        if out.exists() and any(out.iterdir()):
            raise SystemExit('Use a new or empty --rebuild-to directory.')
        subprocess.run([sys.executable,str(Path(__file__).with_name('export_profiles.py')),str(directory),str(out)],check=True)
if __name__=='__main__':
    main()
