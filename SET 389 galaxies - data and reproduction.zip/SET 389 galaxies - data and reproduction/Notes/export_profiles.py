"""Collect the original normalized radial measurements and SET source quadrature for every scored galaxy.

By default the parent of this script's directory is the merged historical work
tree. Pass that tree as the first argument and an output directory as the
second argument if using the paper-writer distribution layout.
"""
import csv
import gzip
import io
from pathlib import Path
import sys
import numpy as np

D = Path(__file__).resolve().parent
W = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else D.parent
if len(sys.argv)>2:
    D = Path(sys.argv[2]).resolve()
    D.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(W / 'extra400_root'))
import forecast as model

def read(p):
    with p.open() as f:
        return list(csv.DictReader(f))

def dump(p, rows, header):
    with p.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=header)
        w.writeheader()
        w.writerows(rows)

def path_of_stars():
    old = W / 'large200_root'
    origin = {r['id']: old for r in read(old/'photometry.csv')}
    old_keys = set(origin)
    for name in ['extra400_root/recovery','extra400_photo','extra400_root/etg',
                 'extra400_root/heritage','extra400_root/neo11']:
        folder = W / name
        phot = model.idx(folder/'photometry.csv')
        stars = {r['id'] for r in model.rd(folder/'stars.csv')}
        for g in stars & phot.keys():
            if name == 'extra400_photo' and g in old_keys: continue
            if name in ('extra400_root/heritage','extra400_root/neo11') and g in origin: continue
            origin[g] = folder
    return origin

def main():
    model.init()
    s = read(W/'389_patterns_root/analysis_data.csv')
    extra_annuli = {r['galaxy'] for r in model.rd(W/'extra400_photo/sparc/annuli.csv')}
    st_path = path_of_stars()
    original_stars = model.grouping(W/'large200_root/stars.csv')
    def profile_numbers(rows):
        return [(float(r['r_arcsec']),float(r['disk']),float(r['bulge'])) for r in rows]
    stellar, gas, ledger, moments, angles = [], [], [], [], []
    angular_nodes, angular_w = np.polynomial.legendre.leggauss(96)
    mu, w = (1+angular_nodes)/2, angular_w/2
    n_shells=0
    with gzip.open(D/'SET mass quadrature 389.csv.gz', 'wt', newline='') as f:
        out = csv.writer(f)
        out.writerow(['id','radius_over_stellar_contour','stellar_fraction_of_total_mass_at_node','gas_including_helium_fraction_of_total_mass_at_node'])
        for row in s:
            g=row['id']
            a=float(row['a_arcsec'])
            mass=np.array([float(row['mstar_disk_msun']),float(row['mstar_bulge_msun']),1.33*float(row['mhi_msun'])])
            if row['survey']=='SPARC':
                cat = model.cat[g]
                dens=np.loadtxt(io.BytesIO(model.denszip.read(g+'.dens')))
                used_annuli=model.natann[g]
                assert used_annuli
                stellar_path='work/shape_sparc/BulgeDiskDec_LTG.zip!'+g+'.dens'
                gas_path='work/extra400_photo/sparc/annuli.csv' if g in extra_annuli else 'work/large200_model/gas_annuli.csv'
                for phys,disk,bulge in dens:
                    stellar.append(dict(id=g,r_arcsec=phys/(cat['d']*1000*model.pr.ARCSEC),native_radius_kpc=phys,disk=disk,bulge=bulge,units='Lsun/pc^2',source_path=stellar_path))
                for r in used_annuli:
                    gas.append(dict(id=g,lo_arcsec=r['lo_arcsec'],hi_arcsec=r['hi_arcsec'],gas_mass_fraction=r['mass_fraction'],source_path=gas_path,native_source=r['source']))
                gas_ref=' | '.join(dict.fromkeys(r['source'] for r in used_annuli))
                kin_ref='https://doi.org/10.3847/0004-6256/152/6/157'
                x,ws,wg=model.pr.shell_components(dens,a*cat['d']*1000*model.pr.ARCSEC,cat['rhi'],mass,a,used_annuli)
            else:
                star_rows=model.stars[g]; gas_rows=model.gas[g]
                if row['cohort']=='Earlier 200':
                    assert profile_numbers(original_stars[g])==profile_numbers(star_rows)
                    stellar_path='work/large200_root/stars.csv'
                else:
                    stellar_path=str((st_path[g]/'stars.csv').relative_to(W.parent))
                source='work/'+model.prov[g]
                prefix=source[:-len('radio_sources.csv')] if source.endswith('/radio_sources.csv') else source[:-len('sources.csv')]
                gas_path=prefix+'hi_radial_profiles.csv'
                assert (W.parent/gas_path).exists()
                for r in star_rows:
                    stellar.append(dict(id=g,r_arcsec=r['r_arcsec'],disk=r['disk'],bulge=r['bulge'],units='exported profile amplitude, component normalized to mass',source_path=stellar_path))
                for r in gas_rows:
                    gas.append(dict(id=g,r_arcsec=r['r_arcsec'],hi_surface_density_msun_pc2=r['sigma_hi_faceon_msun_pc2'],
                                    hi_surface_density_error_msun_pc2=r.get('e_sigma_hi_msun_pc2',''),hi_surface_density_inclination_error_msun_pc2=r.get('e_sigma_hi_inc_msun_pc2',''),
                                    source_path=gas_path,native_source=r.get('profile_source') or r.get('source_page','')))
                src=model.radio[g]
                default_kin={'AWES':'https://doi.org/10.1051/0004-6361/202661305','WALLABY':'https://doi.org/10.25919/7w8n-9h19'}
                kin_ref=src.get('reference_kin') or src.get('source_url') or default_kin.get(row['survey'],'')
                gas_ref=src.get('reference_hi') or src.get('profile_reference') or src.get('source_url') or kin_ref
                prof=[]
                for mass_c,rset,key in zip(mass,(star_rows,star_rows,gas_rows),('disk','bulge','sigma_hi_faceon_msun_pc2')):
                    prof.append(model.e.prepare_profile([float(r['r_arcsec']) for r in rset],[float(r[key]) for r in rset],key)[0] if mass_c else None)
                x,ws,wg=model.e.get_shells(prof,mass,a,12)
            assert abs(sum(ws)+sum(wg)-1)<5e-11,g
            assert abs(sum(wg)-float(row['gas_fraction']))<5e-11,g
            assert abs(sum((ws+wg)[x>=1])-float(row['baryons_outside_fraction']))<5e-10,g
            assert abs(sum(ws[x>=1])/sum(ws)-float(row['stars_outside_fraction']))<5e-10,g
            assert abs(sum(wg[x>=1])/sum(wg)-float(row['gas_outside_fraction']))<5e-10,g
            # Re-evaluate the same source surface at the actual nominal distance, never using a target speed.
            q=float(row['q']); radius_m=float(row['R_kpc'])*model.e.fm.KPC
            h=np.sqrt(q*q+(1-q*q)*mu*mu)
            potential,_=model.e.fm.oblate_kernel(x,ws+wg,q,mu,w)
            d_area=4*np.pi*radius_m**2*w*h
            raw_loading=np.sqrt(potential)
            q_ref=4*np.pi*np.sqrt(2*model.e.fm.GMSUN*sum(mass)*radius_m**3)
            loading=raw_loading*(q_ref/np.dot(raw_loading,d_area))
            moment1=np.dot(loading,d_area);moment2=np.dot(loading**2,d_area)
            area_eff=moment1**2/moment2
            for field,value in [('Q_m3s',q_ref),('A_geom_m2',sum(d_area)),('A_eff_m2',area_eff)]:
                assert np.isclose(value,float(row[field]),rtol=2e-8,atol=0),(g,field,value,float(row[field]))
            moments.append(dict(id=g,intrinsic_axis_ratio=q,nominal_reference_radius_kpc=row['R_kpc'],nominal_mass_msun=mass.sum(),first_moment_Q_m3_s=moment1,second_moment_I_m4_s2=moment2,geometric_area_m2=sum(d_area),effective_area_m2=area_eff,effective_burden_kms=moment2/moment1/1000,nominal_boundary_speed_kms=moment2/moment1/np.sqrt(2)/1000,scored_monte_carlo_median_kms=row['set_kms']))
            angles.extend(dict(id=g,mu=u,area_quadrature_weight_m2=aw,normalized_surface_loading_m_s=ss) for u,aw,ss in zip(mu,d_area,loading))
            out.writerows((g,rr,ss,gg) for rr,ss,gg in zip(x,ws,wg))
            ledger.append(dict(id=g,survey=row['survey'],cohort=row['cohort'],stellar_profile=stellar_path,gas_profile=gas_path,kinematic_reference=kin_ref,gas_profile_reference_or_source_label=gas_ref,shell_node_count=len(x)))
            n_shells+=len(x)
    dump(D/'Stellar profiles 389.csv',stellar,['id','r_arcsec','native_radius_kpc','disk','bulge','units','source_path'])
    dump(D/'Gas profiles 389.csv',gas,['id','r_arcsec','hi_surface_density_msun_pc2','hi_surface_density_error_msun_pc2','hi_surface_density_inclination_error_msun_pc2','lo_arcsec','hi_arcsec','gas_mass_fraction','source_path','native_source'])
    dump(D/'SET surface moments 389.csv',moments,list(moments[0]))
    dump(D/'SET surface integration points 389.csv',angles,list(angles[0]))
    dump(D/'Source profile crosswalk 389.csv',ledger,list(ledger[0]))
    assert len(ledger)==len({r['id'] for r in stellar})==len({r['id'] for r in gas})==389
    print(len(stellar),len(gas),n_shells)
if __name__=='__main__':
    main()
