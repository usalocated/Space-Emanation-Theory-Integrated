"""Reproduce the original quality-prioritized draw and the paper's geometry test."""
import csv
from hashlib import sha256
from math import pi, sqrt
from pathlib import Path
from statistics import median

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    with (ROOT / path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def check_draw(galaxies):
    frame = read("Selection/ranked_eligible.csv")
    seed = "SET-RD8x-200-20261121-v1|"
    priority = {}
    for row in frame:
        key = row["canonical_id"]
        digest = sha256((seed + key).encode()).hexdigest()
        assert digest == row["sample_priority"]
        priority[key] = (-int(row["high_quality"]), digest)
    assert len(priority) == 294
    assert sum(row["high_quality"] == "1" for row in frame) == 215
    selected = sorted(priority, key=priority.get)[:200]
    assert set(selected) == {
        row["canonical_id"] for row in galaxies if row["cohort"] == "Earlier 200"
    }
    print("Verified the seeded draw of 200 from 294 eligible galaxies.")


def check_geometry(galaxies):
    ablation_errors = [[], [], []]
    closer = []
    others = []
    for row in galaxies:
        radius = float(row["R_kpc"]) * 3.085677581491367e19
        q_source = float(row["Q_m3s"])
        observed = float(row["observed_kms"])
        areas = (4 * pi * radius**2, float(row["A_geom_m2"]), float(row["A_eff_m2"]))
        errors = [
            abs(q_source / (sqrt(2) * area * 1000) / observed - 1) * 100
            for area in areas
        ]
        for column, value in zip(ablation_errors, errors):
            column.append(value)
        (closer if errors[1] < errors[0] else others).append(row)
    assert len(closer) == 306 and len(others) == 83
    nominal = [median(group) for group in ablation_errors]
    assert [round(x, 2) for x in nominal] == [37.56, 12.56, 12.50]
    print("Median nominal errors (sphere, uniform oblate, effective), %:", *nominal)
    for label, group in (("All", galaxies), ("Geometry improves", closer),
                         ("Other", others)):
        keys = ("set_kms", "gr_kms", "klypin_all_kms")
        error = {key: [100 * abs(float(row[key])/float(row["observed_kms"]) - 1)
                       for row in group] for key in keys}
        wins = [sum(a < b for a, b in zip(error["set_kms"], error[key]))
                for key in keys[1:]]
        print(label, len(group), "scored median errors (SET, baryons, primary halo), %:",
              *(round(median(error[key]), 4) for key in keys),
              "SET closer than baryons / primary halo:", *wins)


if __name__ == "__main__":
    rows = read("Tables/Galaxy results.csv")
    assert len(rows) == 389
    check_draw(rows)
    check_geometry(rows)
