"""Reproduce the pooled paired interval using its archived seed, order and NumPy."""
import csv
from hashlib import sha256
from pathlib import Path
import numpy as np

tables = Path(__file__).resolve().parents[1] / "Tables"


def rows(filename):
    with (tables / filename).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


galaxies = rows("Galaxy results.csv")
cohort = "Pooled distinct galaxies"
models = ("set", "gr", "klypin_all", "klypin_relaxed", "dutton_maccio")
predictions = {
    (row["id"], row["model"]): float(row["absolute_percentage_error"])
    for row in rows("Model predictions and uncertainty.csv")
}
errors = np.array([[predictions[(row["id"], model)] for row in galaxies]
                   for model in models])
assert errors.shape == (5, 389)
archived = {row["model"]: row for row in rows("Model comparison by cohort and scenario.csv")
            if row["cohort"] == cohort and row["scenario"] == "Direct host audit"}
seed = sha256(("RD8x paired new|" + cohort).encode()).digest()[:8]
rng = np.random.default_rng(int.from_bytes(seed, "big"))
draws = int(archived["set"]["paired_resamples"])
resampled = np.empty((len(models), draws))
for start in range(0, draws, 1000):
    stop = min(start + 1000, draws)
    indices = rng.integers(len(galaxies), size=(stop-start, len(galaxies)), dtype=np.int32)
    for i, arr in enumerate(errors):
        resampled[i, start:stop] = np.median(arr[indices], axis=1)
for i, model in enumerate(models):
    lo, hi = np.percentile(resampled[0] - resampled[i], [2.5, 97.5])
    reference = [float(archived[model][k]) for k in ("ci_low_pp", "ci_high_pp")]
    assert np.allclose([lo, hi], reference, rtol=0.0, atol=1e-8), (model, lo, hi, reference)
    print(f"SET minus {model}: 95% paired interval [{lo:.3f}, {hi:.3f}] percentage points")
