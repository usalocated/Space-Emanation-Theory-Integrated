"""Check the primary comparison directly from the paper-writer tables. No library dependencies."""
import csv
import math
from bisect import bisect_left
from collections import defaultdict
from pathlib import Path
from statistics import median
P=Path(__file__).resolve().parents[1]/'Tables'
def rows(name):
    with (P/name).open(encoding='utf-8-sig') as file:
        return list(csv.DictReader(file))
def index(series):
    out={r['id']:r for r in series}
    assert len(out)==len(series)
    return out
def close(x,y):
    assert math.isclose(float(x),float(y),abs_tol=2e-7,rel_tol=2e-8),(x,y)
def main():
    galaxies=index(rows('Galaxy results.csv'))
    moments=index(rows('SET surface moments 389.csv'))
    risks=rows('Subgroups by cohort.csv')
    modelrows=rows('Model predictions and uncertainty.csv')
    assert len(galaxies)==len(set(r['canonical_id'] for r in galaxies.values()))==389
    assert len(modelrows)==389*5
    bygal=defaultdict(dict)
    for r in modelrows:
        m=r['model'];g=r['id'];assert m not in bygal[g];bygal[g][m]=r
        obs=float(galaxies[g]['observed_kms']);v=float(r['median_prediction_kms'])
        close(obs,r['observed_kms']);close(100*abs(v/obs-1),r['absolute_percentage_error'])
        assert float(r['p16_kms'])<=v<=float(r['p84_kms'])
    rings=defaultdict(list)
    for row in rows('Observed rotation rings.csv'):
        rings[row['id']].append((float(row['r_arcsec']),float(row['observed_speed_kms'])))
    assert set(rings)==set(galaxies)==set(moments)==set(bygal)
    assert sum(map(len,rings.values()))==4720
    for g,r in galaxies.items():
        obs=float(r['observed_kms'])
        for m in ['set','gr','klypin_all']:close(r[m+'_kms'],bygal[g][m]['median_prediction_kms'])
        for m in ['set','gr','klypin_all','dutton_maccio']:close(r[m+'_error_pct'],bygal[g][m]['absolute_percentage_error'])
        a=float(r['a_arcsec']);data=sorted(rings[g]);xx=[x[0] for x in data];j=bisect_left(xx,a)
        if a==xx[j]:v=data[j][1]
        else:
            assert 0<j<len(xx)
            w=(a-xx[j-1])/(xx[j]-xx[j-1]);v=(1-w)*data[j-1][1]+w*data[j][1]
        close(v,obs)
        close(moments[g]['nominal_boundary_speed_kms'],r['set_nominal_kms'])
        close(moments[g]['scored_monte_carlo_median_kms'],r['set_kms'])
    for label in ['All 389','Earlier 200','Additional 189']:
        rr=[v for v in galaxies.values() if label=='All 389' or v['cohort']==label]
        sub=next(x for x in risks if x['cohort']==label and x['group']=='Full sample')
        med=[median(float(z[m+'_error_pct']) for z in rr) for m in ['set','gr','klypin_all']]
        wins=sum(float(z['set_error_pct'])<float(z['klypin_all_error_pct']) for z in rr)
        assert len(rr)==int(sub['n']) and wins==int(sub['wins']);close(med[0],sub['median_set']);close(med[2],sub['median_halo'])
        print(label,len(rr),'median absolute errors (SET, baryonic, fixed halo)',*[round(x,4) for x in med],'SET closer',wins)
    print('Verified 389 galaxies, 4,720 rings and 1,945 model forecasts.')
if __name__=='__main__':main()
