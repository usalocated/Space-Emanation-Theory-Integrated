"""Frozen magnetic candidate: temporal, upper-limit and energy controls.

No regression or adjusted field coefficient. All diagnostic ratios are outputs.
"""
from pathlib import Path
import json, math, hashlib

HERE = Path(__file__).resolve().parent
OUT = HERE.parent
OLD = OUT.parent / 'set-magnetic-correction-audit-2026-11-06'
INPUT = json.loads((OLD/'inputs/FROZEN-INPUT-ALTERNATIVES.json').read_text())
OLD_COMP = json.loads((OUT.parent/'set-boundary-clock-magnetic-selection-2026-11-06/further_planets/comparison.json').read_text())
G, c, mu0 = [INPUT['constants'][k] for k in ('G','c','mu0')]

def candidate(M,R,P):
    omega=2*math.pi/P
    v=omega*R
    alpha=math.sqrt(1-2*G*M/(R*c*c))
    beta=math.sqrt(alpha*alpha-v*v/(c*c))
    gap=(v/c)**2/(alpha+beta)
    rho=3*M/(4*math.pi*R**3)
    b=c*math.sqrt(mu0*rho)*gap
    ustar=M*c*c*gap*gap
    assert math.isclose(ustar,4*math.pi*R**3*b*b/(3*mu0),rel_tol=1e-14)
    return dict(b_T=b,b_nT=b*1e9,b_microT=b*1e6,alpha=alpha,beta=beta,
                clock_gap=gap,Ustar_J=ustar,omega_rad_s=omega,v_m_s=v,
                M_kg=M,R_m=R,P_s=P)

planet_energy=[]
for row in OLD_COMP['planet_comparisons']:
    name=row['object']; x=INPUT['objects'][name]
    p=candidate(x['M_kg'],x['R_m'],x['P_s'])
    assert math.isclose(p['b_microT'],float(row['candidate_microT']),rel_tol=2e-14)
    bobs=float(row['observed_dipole_microT'])*1e-6
    Uobs=4*math.pi*x['R_m']**3*bobs*bobs/(3*mu0)
    ratio=bobs/p['b_T']
    # Inverse quantities below do not supply prediction inputs.
    planet_energy.append(dict(object=name,**p,observed_b_T=bobs,
        observed_dipole_U_J=Uobs,observed_U_over_Ustar=Uobs/p['Ustar_J'],
        observed_U_over_Mc2=Uobs/(x['M_kg']*c*c),
        observed_U_over_boundary_K0=Uobs/(0.5*x['M_kg']*p['v_m_s']**2),
        required_amplitude_factor=ratio,
        required_mass_fraction_at_fixed_R_Omega_weak=ratio**2,
        largest_source_radius_fraction_for_nondecreasing_enclosed_mean_density_weak=ratio**.2,
        required_spin_factor_same_M_R_weak=math.sqrt(ratio),
        required_period_days_same_M_R_weak=x['P_s']/86400/math.sqrt(ratio),
        can_be_explained_by_efficiency_below_one=ratio<=1))

# Additional controls were fixed in PROTOCOL.txt before this evaluation.
upper=[]
new_inputs=[('Mars',0.641691e24,3389.50e3,1.02595676*86400),
            ('Venus',4.86731e24,6051.8e3,-243.018*86400)]
for name,M,R,P in new_inputs:
    p=candidate(M,R,P)
    limit=0.5e-9 if name=='Mars' else 8.4e10/R**3
    upper.append(dict(object=name,**p,published_dipole_upper_limit_T=limit,
        candidate_over_published_limit=p['b_T']/limit,
        observed_not_detected=True,
        source=('https://mgs-mager.gsfc.nasa.gov/publications/grl_28_connerney/grl_28_connerney_paper.html'
                if name=='Mars' else 'https://doi.org/10.1029/JA092iA03p02253'),
        limit_is_not_gaussian_error_bar=True))

# Use every actual epoch in the coefficient file; leave the SV forecast separate.
raw=(OUT/'earth_history/igrf14coeffs.txt').read_text()
lines=raw.splitlines()
header=next(l for l in lines if l.startswith('g/h'))
epochs=[float(x) for x in header.split()[3:-1]]
coeffs={}
sv={}
for line in lines:
    ss=line.split()
    if len(ss)>3 and ss[0] in ('g','h') and ss[1]=='1':
        key=(ss[0],int(ss[2]))
        coeffs[key]=list(map(float,ss[3:-1]));sv[key]=float(ss[-1])
        assert len(coeffs[key])==len(epochs)
ex=INPUT['objects']['Earth']; earth=candidate(ex['M_kg'],ex['R_m'],ex['P_s'])
radius_ratio=(6371.2e3/ex['R_m'])**3
earth_epochs=[]
for i,t in enumerate(epochs):
    g10,g11,h11=[coeffs[k][i] for k in [('g',0),('g',1),('h',1)]]
    b=math.sqrt(g10*g10+g11*g11+h11*h11)*radius_ratio*1e-9
    earth_epochs.append(dict(year=t,g10_nT=g10,g11_nT=g11,h11_nT=h11,
        dipole_microT=b*1e6,candidate_microT=earth['b_microT'],
        candidate_over_model=earth['b_T']/b,
        absolute_log_error=abs(math.log(earth['b_T']/b))))
crossings=[]
for a,b in zip(earth_epochs,earth_epochs[1:]):
    da=a['dipole_microT']-earth['b_microT']; db=b['dipole_microT']-earth['b_microT']
    if da*db<0:
        crossings.append(dict(epoch_bracket=[a['year'],b['year']],
             note='No interpolated matching year is adopted; all epochs retained.'))

sun=json.loads((OLD/'RESULTS.json').read_text())['solar_trial']['all_five_WSO_minima']
solar_amplitudes=[r['observed_axial_equivalent_b_G'] for r in sun]
solar_ratio=max(solar_amplitudes)/min(solar_amplitudes)
result=dict(
    fixed_planetary_energy_comparisons=planet_energy,
    new_upper_limit_controls=upper,
    Earth_IGRF14=dict(source='https://www.ngdc.noaa.gov/IAGA/vmod/coeffs/igrf14coeffs.txt',
        SHA256=hashlib.sha256(raw.encode()).hexdigest(),epoch_rows=earth_epochs,
        candidate_crossings=crossings,
        field_change_1900_to_2025_percent=100*(earth_epochs[-1]['dipole_microT']/earth_epochs[0]['dipole_microT']-1),
        interpretation='One modern reconstruction of real secular evolution, not older estimates converging to a true constant field.'),
    solar_state_control=dict(max_to_min_axial_amplitude=solar_ratio,
        required_rotation_rate_ratio_if_only_rotation_changes=math.sqrt(solar_ratio),
        required_mass_or_radius_ratio_if_only_that_changes=solar_ratio**2,
        selected_five_minima=solar_amplitudes,
        note='These are inverse requirements, not derived or adjusted source data.'),
    numerical_checks=['Stable clock rationalization reproduces all four original amplitudes.',
        'Dipole exterior energy equals Ustar only under the tested b=b0 identification.',
        'All26 IGRF14 five-year historical epochs retained; future SV not mixed in.',
        'Mars and Venus results compared with upper limits; neither treated as a detection.'])
(HERE/'controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(upper_limit_controls=upper,
    energy_ratios={r['object']:r['observed_U_over_Ustar'] for r in planet_energy},
    Earth_selected_epochs=[r for r in earth_epochs if r['year'] in [1900,1950,2000,2005,2010,2015,2020,2025]],
    Earth_crossings=crossings,solar_state_control=result['solar_state_control']),indent=2))
