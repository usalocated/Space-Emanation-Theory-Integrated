from pathlib import Path
import json,csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

P=Path(__file__).resolve().parent.parent
controls=json.loads((P/'coordinator/controls.json').read_text())
giants=list(csv.DictReader((P/'history_giants/historical_models.csv').open()))
ms=json.loads((P/'history_mercury_sun/measurement_comparisons.json').read_text())
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig=plt.figure(figsize=(12,10))
gs=fig.add_gridspec(2,2,height_ratios=[1.15,1],hspace=.49,wspace=.24)
ax=fig.add_subplot(gs[0,:])
colors={'Jupiter':'#b16b23','Saturn':'#724f9b','Mercury':'#146b78'}
for name in ['Jupiter','Saturn']:
    rows=sorted([r for r in giants if r['body']==name and r['category']=='published_model'],key=lambda r:float(r['publication_year']))
    ax.plot([float(r['publication_year']) for r in rows],[float(r['prediction_over_observation']) for r in rows],
            'o-',color=colors[name],label=name,lw=1.4,ms=5)
mr=[r for r in ms['mercury'] if str(r['publication_year']).isdigit()]
ax.scatter([float(r['publication_year']) for r in mr],[1/r['observed_over_SET'] for r in mr],
           color=colors['Mercury'],label='Mercury (including alternative models)',s=32,zorder=3)
ax.axhline(1,color='#333333',ls='--',lw=1.2,label='Exact agreement')
ax.set_yscale('log');ax.set_ylim(.002,400);ax.set_xlim(1976,2025)
ax.set_ylabel('Unchanged candidate / measured-model dipole')
ax.set_xlabel('Model publication year; data epochs and methods differ')
ax.set_title('A. Better field maps have not closed the large amplitude gaps',loc='left',fontsize=13,pad=12)
ax.grid(axis='y',alpha=.2);ax.legend(loc='center left',bbox_to_anchor=(.015,.39),frameon=True,facecolor='white',edgecolor='none',framealpha=1,fontsize=10)
ax.text(.98,.65,'Above 1: candidate too large\nBelow 1: candidate too small',transform=ax.transAxes,ha='right',va='top',fontsize=10)

ax=fig.add_subplot(gs[1,0])
er=controls['Earth_IGRF14']['epoch_rows']
ax.plot([r['year'] for r in er],[r['dipole_microT'] for r in er],'o-',ms=3,color='#146b78',label='IGRF14 dipole history')
ax.axhline(er[0]['candidate_microT'],color='#a34c3e',ls='--',label='Unchanged SET trial: 29.963')
ax.set_title('B. Earth: actual magnetic state changes',loc='left',fontsize=12,pad=12)
ax.set_xlabel('Physical epoch (one IGRF14 reconstruction)');ax.set_ylabel('Dipole amplitude (µT)')
ax.grid(alpha=.18);ax.legend(frameon=False,fontsize=9,loc='upper right')
ax.set_ylim(29.4,32.6)
ax.text(.03,.05,'2010 difference: 0.034%\n2025 difference: 0.764%',transform=ax.transAxes,fontsize=10)

ax=fig.add_subplot(gs[1,1])
for instr,col,marker in [('WSO','#b16b23','o'),('MWO','#724f9b','s')]:
    rows=[r for r in ms['sun'] if r['instrument']==instr]
    years=[int(r['epoch'][:4])+(int(r['epoch'][5:7])-1)/12 for r in rows]
    ax.scatter(years,[r['equivalent_axial_equatorial_G'] for r in rows],color=col,marker=marker,s=40,label=instr,zorder=3)
ax.axhline(ms['frozen_predictions']['sun_G'],color='#a34c3e',ls='--',label='Unchanged SET trial: 2.789')
ax.set_title('C. Sun: five minima and two instruments',loc='left',fontsize=12,pad=12)
ax.set_xlabel('Solar-minimum epoch');ax.set_ylabel('Axial dipole equivalent (G)')
ax.set_ylim(.6,3.05);ax.grid(alpha=.18);ax.legend(frameon=False,fontsize=9,loc='lower left')
fig.suptitle('Measurement uncertainty and source evolution are different tests',fontsize=16,x=.08,ha='left',y=.97)
fig.text(.08,.035,'All comparisons use the original magnetic candidate. Model revisions are not independent trials.\n'
         'Earth and solar panels show different physical epochs, not errors around one constant field.\n'
         'Solar points are axial-harmonic equivalents averaged over 13 Carrington rotations.',fontsize=10,color='#555555')
fig.subplots_adjust(top=.9,bottom=.17,left=.08,right=.98)
fig.savefig(P/'measurement_and_state_controls.png',dpi=180)
fig.savefig(P/'measurement_and_state_controls.svg')
print(P/'measurement_and_state_controls.png')
