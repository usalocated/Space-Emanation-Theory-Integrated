"""Frozen-input test of the attachment's gravito-rotational cross energy.

No fitting, no input replacement, no chosen solar epoch. The new cross term
is an algebraic trial energy, not assumed to be a selected magnetic reservoir.
Use python3 -B; all output stays in this audit directory.
"""
from pathlib import Path
from decimal import Decimal, getcontext
import hashlib,json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
getcontext().prec=75
D=lambda x:Decimal(str(x))
pi=D('3.141592653589793238462643383279502884197169399375105820974944592307816406286')
inp_path=ROOT/'outputs/set-magnetic-correction-audit-2026-11-06/inputs/FROZEN-INPUT-ALTERNATIVES.json'
old_path=ROOT/'outputs/set-boundary-clock-magnetic-selection-2026-11-06/further_planets/comparison.json'
shape_path=ROOT/'outputs/set-magnetic-measurement-vs-organization-2026-11-06/source_structure/source_structure_results.json'
# The supplied commentary motivates the test but is not a numerical input.
commentary_sha256='54e19e65afd9788a451480cdf2f85257f513acc3a7b8805882472bc72b43e51e'
inputs=json.loads(inp_path.read_text());old=json.loads(old_path.read_text());shape=json.loads(shape_path.read_text())
G,c,mu=[D(inputs['constants'][k]) for k in ('G','c','mu0')]
checks={}
def close(label,x,y,tol=D('1e-60')):
    residual=abs(x-y)/max(abs(x),abs(y),D('1e-100'))
    assert residual<tol,(label,residual)
    checks[label]=str(residual)

def model(name):
    row=inputs['objects'][name];M,R,P=[D(row[k]) for k in ('M_kg','R_m','P_s')]
    om=2*pi/P;v=om*R;rho=3*M/(4*pi*R**3)
    u=2*G*M/(R*c*c);w=(v/c)**2
    a=(1-u).sqrt();b=(1-u-w).sqrt()
    dg=u/(1+a);dv=w/(a+b)  # cancellation-free clock deficits
    rest=M*c*c
    Ugg=rest*dg*dg;Ux=2*rest*dg*dv;Us=rest*dv*dv
    Wreq=rest*dg/(1+a)
    bs=c*(mu*rho).sqrt()*dv
    bx=c*(2*mu*rho*dg*dv).sqrt()
    bx_direct=M*abs(om)/(R*c)*(3*mu*G/(pi*(1+a)*(a+b))).sqrt()
    bx_weak=M*abs(om)/(2*R*c)*(3*mu*G/pi).sqrt()
    close(name+'_clock_sum_square',rest*(1-b)**2,Ugg+Ux+Us)
    close(name+'_UGG_equals_u_Wreq',Ugg,u*Wreq)
    close(name+'_cross_ratio',Ux/Us,2*u*(a+b)/(w*(1+a)))
    close(name+'_cross_field_formula',bx,bx_direct)
    close(name+'_exterior_cross_energy',4*pi*R**3*bx*bx/(3*mu),Ux)
    close(name+'_original_exterior_energy',4*pi*R**3*bs*bs/(3*mu),Us)
    close(name+'_cross_to_Wreq',Ux/Wreq,2*(1+a)*dv)
    result=dict(object=name,M_kg=M,R_m=R,P_s=P,rotation_speed_m_s=v,
      S_m_s=(u*c*c).sqrt(),u=u,w=w,alpha=a,beta=b,gravity_deficit=dg,rotation_deficit=dv,
      original_b_microT=bs*D('1e6'),cross_b_microT=bx*D('1e6'),cross_b_G=bx*D('1e4'),
      cross_plus_star_b_microT=(bx*bx+bs*bs).sqrt()*D('1e6'),
      full_deficit_square_b_microT=c*(mu*rho).sqrt()*(dg+dv)*D('1e6'),
      Ustar_J=Us,Ucross_J=Ux,UGG_J=Ugg,Wreq_J=Wreq,
      Ucross_over_Ustar=Ux/Us,b_cross_over_original=bx/bs,
      UGG_over_Wreq=Ugg/Wreq,Ucross_over_Wreq=Ux/Wreq,
      cross_field_exact_over_weak=bx/bx_weak)
    return result

rows={name:model(name) for name in ('Mercury','Earth','Sun','Jupiter','Saturn')}
observed={r['object']:r for r in old['planet_comparisons']}
for name,r in rows.items():
    if name=='Sun':continue
    ob=D(observed[name]['observed_dipole_microT'])
    close(name+'_original_baseline_retained',r['original_b_microT'],D(observed[name]['candidate_microT']),D('3e-14'))
    r.update(observed_dipole_microT=ob,
      original_over_observed=r['original_b_microT']/ob,
      cross_over_observed=r['cross_b_microT']/ob,
      observed_Uout_over_Ucross=(ob/r['cross_b_microT'])**2,
      observed_Uout_percent_of_Ucross=100*(ob/r['cross_b_microT'])**2,
      original_absolute_log_error=float(abs((r['original_b_microT']/ob).ln())),
      cross_absolute_log_error=float(abs((r['cross_b_microT']/ob).ln())))
close('Sun_original_baseline_retained',rows['Sun']['original_b_microT'],D(old['solar_prediction']['derived']['candidate_microT']),D('3e-14'))
solar=[]
for ob in old['solar_comparison']['comparison_rows']:
    B=D(ob['observed_axial_vacuum_equivalent_b_G'])
    r=rows['Sun'];solar.append(dict(instrument=ob['instrument'],epoch=ob['epoch'],
       observed_axial_equatorial_G=B,original_G=r['original_b_microT']/100,
       cross_G=r['cross_b_G'],original_over_observed=r['original_b_microT']/100/B,
       cross_over_observed=r['cross_b_G']/B,observed_Uout_over_Ucross=(B/r['cross_b_G'])**2))

# Independent/predeclared source radii are reused only for geometric conversion.
# The trial keeps the WHOLE-BODY cross number fixed. It does not silently
# recalculate its material mass, internal lapse or local rotational weighting.
geometries=[]
def geometry(name,label,a,qualification):
    r=rows[name];R=r['R_m'];a=D(a);x=a/R;atten=x**3
    close(name+'_'+label+'_depth_energy',
          (4*pi*R**3/(3*mu))*(a/R)**6,
          (4*pi*a**3/(3*mu))*atten)
    out=dict(object=name,label=label,source_outer_radius_m=a,source_outer_fraction=x,
      field_amplitude_ratio_bR_over_ba=x**3,local_field_squared_ratio=x**6,
      integrated_exterior_energy_ratio_UoutR_over_Uouta=atten,
      minimum_UB_over_UoutR=3/atten,
      literal_field_relabeling_diagnostic_bR_microT=r['cross_b_microT']*atten,
      literal_field_relabeling_implicit_Uouta_over_Ucross=atten,
      trial_bR_microT_if_Ucross_equals_Uouta=r['cross_b_microT']*atten.sqrt(),
      upper_bR_microT_if_UB_total_le_Ucross=r['cross_b_microT']*(atten/3).sqrt(),
      scope=qualification)
    if name!='Sun':
        ob=r['observed_dipole_microT'];out.update(
          trial_over_observed=out['trial_bR_microT_if_Ucross_equals_Uouta']/ob,
          total_budget_upper_over_observed=out['upper_bR_microT_if_UB_total_le_Ucross']/ob,
          minimum_UB_required_over_Ucross=3/atten*r['observed_Uout_over_Ucross'])
    geometries.append(out)

geometry('Earth','PREM_core_outer',3480000,'Independently specified PREM outer-core boundary. Frozen JPL whole-body energy inputs unchanged.')
for rr in shape['Mercury']:
    geometry('Mercury',rr['label'],rr['a_m'],'Previously retained gravity/radar core-radius sensitivity box; not a joint posterior or fitted dynamo radius.')
for rr in shape['giant_ball_bounds']:
    if rr['object']=='Jupiter':
        # Key structure is checked below against the saved record.
        geometry('Jupiter','predeclared_'+str(rr['x']),rows['Jupiter']['R_m']*D(rr['x']),
          'Previously retained conditional conducting-ball radius slice, not a measured dynamo boundary or confidence interval.')
for rr in shape['Saturn_shell']:
    geometry('Saturn',rr['mapping'],rows['Saturn']['R_m']*D(rr['outer_x']),
      'Previously retained model metallic-shell outer radius; mean and equatorial mappings both retained. Material model, not direct dynamo-radius measurement.')
geometry('Sun','convection_zone_outer',rows['Sun']['R_m'],
         'The convection zone extends from0.713R toR: its BASE is not the enclosing current radius. No attenuation by0.713 is applied.')

def encode(v):
    if isinstance(v,Decimal):return str(v)
    raise TypeError(type(v).__name__)
record=dict(protocol='Frozen M,R,P,G,c,mu0 and original observed definitions; new Ucross trial openly introduced after residuals were known; no fits, optimized radius, new phase or solar epoch selection.',
 commentary_sha256=commentary_sha256,
 source_files=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in (inp_path,old_path,shape_path)],
 constants=inputs['constants'],objects=list(rows.values()),solar_all_original_epochs=solar,
 geometry_only_trials=geometries,checks=checks,
 claims_not_established=['Ucross is an actual complete-energy reservoir','Ucross is transferred to magnetism','A prescribed fraction saturates','Whole-body cross energy belongs to a selected interior domain'],
 scope='Uout refers to the isolated quasistatic dipole continuation; solar data are the same axial vacuum-equivalent equatorial component as before. Wreq is the retained supported-shell expression evaluated algebraically at the same M and alpha, not a claim that it equals each filled planet actual field or binding energy.')
(HERE/'attachment-cross-energy-results.json').write_text(json.dumps(record,indent=2,default=encode)+'\n')
print(json.dumps(dict(objects=list(rows.values()),solar=solar,geometries=geometries,check_count=len(checks)),indent=2,default=encode))
