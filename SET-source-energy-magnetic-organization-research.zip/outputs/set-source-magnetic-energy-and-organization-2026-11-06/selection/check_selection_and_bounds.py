"""Independent exact and quadrature checks; no observational fitting.

Run from the workspace with python3 -B <this-file>. Uses the already present
pure-Python SymPy vendor. Numerical controls use only the standard library.
"""
from pathlib import Path
import json
import math
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / 'outputs/set-invariant-library/vendor'))
import sympy as s

checks = {}
def zero(name, expression):
    checks[name] = s.simplify(expression) == 0
    assert checks[name], (name, s.simplify(expression))

x, r, R, k, w, mu, lam = s.symbols('x r R k w mu lam', positive=True)
i0 = lambda z: s.sinh(z)/z
i1 = lambda z: (z*s.cosh(z)-s.sinh(z))/z**2
i2 = lambda z: ((z*z+3)*s.sinh(z)-3*z*s.cosh(z))/z**3
g = s.simplify(i2(x)/i0(x))
F = 1/g
zero('bessel_ratio_closed_form', g-(1+3/x**2-3/(x*s.tanh(x))))
zero('bessel_recurrence', i2(x)-i0(x)+3*i1(x)/x)
zero('moment_integral_primitive', s.diff(r**3*i2(k*r)/k,r)-r**3*i1(k*r))
aa = lam*s.Rational(1,2)*(r-3*i1(k*r)/(k*i0(k*R)))
jj = 3*lam*i1(k*r)/(2*w*k*i0(k*R))
zero('current_euler_equation', w*jj+aa-lam*r/2)
zero('ampere_equation', (s.diff(aa,r,2)+2*s.diff(aa,r)/r-2*aa/r**2+mu*jj).subs(mu,w*k*k))
zero('no_surface_current_matching', (s.diff(aa,r)+2*aa/r).subs(r,R))
moment = 2*s.pi*lam*R**3/mu * i2(k*R)/i0(k*R)
zero('potential_dipole_matching', (aa.subs(r,R)-mu*moment/(4*s.pi*R**2)))
zero('moment_from_current', (4*s.pi/3)*(3*lam/(2*w*k*i0(k*R)))*(R**3*i2(k*R)/k)-moment.subs(mu,w*k*k))
zero('regular_vector_potential_at_origin', s.limit(aa,r,0))
zero('regular_current_at_origin', s.limit(jj,r,0))
zero('small_x_uniform_kinetic_cost', s.limit(x*x*F,x,0)-15)
zero('small_x_uniform_magnetic_cost', s.limit(F+x*s.diff(F,x)/2,x,0)-s.Rational(10,7))
zero('small_x_external_magnetic_fraction', s.limit(1/(3*(F+x*s.diff(F,x)/2)),x,0)-s.Rational(7,30))
zero('large_x_shell_total_cost', s.limit(F,x,s.oo)-1)
zero('large_x_shell_magnetic_cost', s.limit(F+x*s.diff(F,x)/2,x,s.oo)-1)

# The boundary harmonic is B_r(R)=q_l Y_lm, with integral |Y_lm|^2 dOmega=1.
ell, q = s.symbols('ell q', positive=True)
Uin = R**3*q**2/(2*mu*ell)
Uout = R**3*q**2/(2*mu*(ell+1))
zero('multipole_interior_exterior_ratio', Uin/Uout-(ell+1)/ell)
zero('multipole_exterior_fraction', Uout/(Uin+Uout)-ell/(2*ell+1))
zero('dipole_exterior_fraction', (Uout/(Uin+Uout)).subs(ell,1)-s.Rational(1,3))

# Full pointwise Maxwell stress is invariant under the neutral initial-data
# duality family, not just its scalar energy.
bx, by, bz, t = s.symbols('bx by bz t', real=True)
B0 = s.Matrix([bx,by,bz])
e_scaled = s.sin(t)*B0  # E/c
B = s.cos(t)*B0
zero('duality_energy', (e_scaled.dot(e_scaled)+B.dot(B))-B0.dot(B0))
zero('duality_poynting', e_scaled.cross(B).dot(e_scaled.cross(B)))
stress = e_scaled*e_scaled.T+B*B.T-B0*B0.T
for a in range(3):
    for b in range(3):
        zero(f'duality_stress_{a}_{b}',stress[a,b])

# A concrete non-diagonal positive Hessian and linear constraints verify the
# general constrained selector and the residual-energy projection formula.
K = s.Matrix([[4,1,0],[1,3,1],[0,1,2]])
C = s.Matrix([[1,1,0]])
datum = s.Matrix([2])
Ki = K.inv()
P = Ki-Ki*C.T*(C*Ki*C.T).inv()*C*Ki
minimum = Ki*C.T*(C*Ki*C.T).inv()*datum
assert C*minimum == datum
assert C*P == s.zeros(1,3)
assert P*K*P == P
checks.update(constrained_minimum_satisfies_invariant=True,
              constrained_projector_annihilates_invariant=True,
              constrained_projector_metric_identity=True)
probe = s.Matrix([0,0,1])
direction = P*probe
zero('sharp_mode_direction_norm', (direction.T*K*direction)[0]-(probe.T*P*probe)[0])

def simpson(f, a, b, n=20000):
    h=(b-a)/n
    return h/3*(f(a)+f(b)+4*sum(f(a+(2*i-1)*h) for i in range(1,n//2+1))
                +2*sum(f(a+2*i*h) for i in range(1,n//2)))

def ni0(z):
    if abs(z)<1e-3:
        return 1+z*z/6+z**4/120+z**6/5040
    return math.sinh(z)/z
def ni1(z):
    if abs(z)<1e-3:
        return z/3+z**3/30+z**5/840+z**7/45360
    return (z*math.cosh(z)-math.sinh(z))/(z*z)
def ng(z):
    if z<0.01:
        return z*z/15-2*z**4/315+z**6/1575
    return 1+3/z**2-3/(z*math.tanh(z))

trials=[]
for kval in (0.1,0.3,1.0,3.0,10.0,30.0):
    # mu=R=m=1; w=1/k^2. This is an algebra/shape check, not a physical
    # preparation with an assumed relativistic speed.
    wval=1/kval**2
    ratio=ng(kval)
    lval=1/(2*math.pi*ratio)
    n0=ni0(kval)
    def pot(rr):
        return lval/2*(rr-3*ni1(kval*rr)/(kval*n0))
    def cur(rr):
        return 3*lval*ni1(kval*rr)/(2*wval*kval*n0)
    def deriv(rr):
        if rr==0:
            return lval/2*(1-1/n0)
        return lval/2*(1-3*(ni0(kval*rr)-2*ni1(kval*rr)/(kval*rr))/n0)
    moment_num=4*math.pi/3*simpson(lambda rr:rr**3*cur(rr),0,1)
    Erel=4*math.pi*wval/3*simpson(lambda rr:rr**2*cur(rr)**2,0,1)
    Uin=simpson(lambda rr:(4*math.pi/3*(2*pot(rr))**2+8*math.pi/3*(pot(rr)+rr*deriv(rr))**2)/2,0,1)
    Uout=1/(12*math.pi)
    UB=Uin+Uout
    half_jA=4*math.pi/3*simpson(lambda rr:rr**2*cur(rr)*pot(rr),0,1)
    total=Erel+UB
    predicted=1/(4*math.pi*ratio)
    residuals={
        'moment':abs(moment_num-1),
        'total_energy_relative':abs(total/predicted-1),
        'field_equals_half_jA_relative':abs(UB/half_jA-1),
        'boundary_derivative':abs(deriv(1)+2*pot(1)),
        'boundary_potential':abs(pot(1)-1/(4*math.pi)),
    }
    assert max(residuals.values())<2e-8, (kval,residuals)
    assert 0<ratio<1
    assert predicted <= (15/kval**2+10/7)/(4*math.pi)*(1+1e-10)
    assert 7/30-1e-7 <= Uout/UB <= 1/3+1e-7
    trials.append(dict(x=kval,minimum_energy=total,relative_carrier_energy=Erel,
      magnetic_energy=UB,exterior_dipole_energy=Uout,exterior_fraction_of_magnetic=Uout/UB,
      exterior_fraction_of_total=Uout/total,geometric_material_factor=ratio,
      uniform_trial_energy=(15/kval**2+10/7)/(4*math.pi),residuals=residuals))

result=dict(symbolic_checks=checks,number_exact_checks=len(checks),
  bessel_ratio=str(g),small_x_minimum_cost=str(s.series(F,x,0,5)),
  dimensionless_trials=trials,
  maximum_numerical_residual=max(max(t['residuals'].values()) for t in trials),
  qualification='Checks verify the declared static, constant-density, slow-relative-motion current class; no planetary fit and no proof of spontaneous relaxation or full nonlinear source selection.')
(HERE/'selection-and-bounds-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
