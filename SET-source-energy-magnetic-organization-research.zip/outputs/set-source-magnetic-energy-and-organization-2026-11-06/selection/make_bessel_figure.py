"""Static scientific figure; uses existing Python3.12-compatible vendor."""
from pathlib import Path
import os, sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
os.environ['MPLCONFIGDIR']=str(HERE/'mpl-cache')
sys.path.insert(0,str(ROOT/'outputs/set-capacity-continuation/vendor'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':10,
 'axes.titlesize':11,'axes.spines.top':False,'axes.spines.right':False,
 'axes.edgecolor':'#556878','text.color':'#142534','axes.labelcolor':'#142534',
 'xtick.color':'#425565','ytick.color':'#425565','figure.facecolor':'white',
 'savefig.facecolor':'white'})
def i1(x):
    x=np.asarray(x)
    z=np.maximum(x,1e-15)
    regular=(z*np.cosh(z)-np.sinh(z))/z**2
    return np.where(x<.001,x/3+x**3/30+x**5/840,regular)
def i2(x):
    return ((x*x+3)*np.sinh(x)-3*x*np.cosh(x))/x**3
rr=np.linspace(0,1,600)
x=np.geomspace(.01,100,700)
g=1+3/x**2-3/(x*np.tanh(x))
gp=-6/x**3+3/(x*x*np.tanh(x))+3/(x*np.sinh(x)**2)
small=x<.05
g[small]=x[small]**2/15-2*x[small]**4/315+x[small]**6/1575
gp[small]=2*x[small]/15-8*x[small]**3/315+6*x[small]**5/1575
rel=x*gp/(2*g)
fig,axs=plt.subplots(1,2,figsize=(10.2,4.1),layout='constrained')
for xx,col in zip((.3,3,10),('#246b9b','#ba7542','#267c6c')):
    axs[0].plot(rr,xx*i1(xx*rr)/i2(xx),color=col,lw=2.2,label=f'$x={xx:g}$')
axs[0].plot(rr,5*rr,color='#7d8892',ls='--',lw=1.4,label='rigid-rotation limit')
axs[0].set(xlabel='$r/R$',ylabel=r'$4\pi R^4 J(r)/(3m)$',
 title='Current profiles at the same dipole moment',xlim=(0,1),ylim=(0,14))
axs[0].legend(frameon=False,loc='upper left',fontsize=9)
axs[1].semilogx(x,1-rel,lw=2.2,color='#246b9b',label=r'magnetic $U_B/E_{\min}$')
axs[1].semilogx(x,rel,lw=2.2,color='#ba7542',label=r'carrier $E_{\rm rel}/E_{\min}$')
axs[1].semilogx(x,g/3,lw=2.2,color='#267c6c',label=r'exterior dipole $U_{\rm out}/E_{\min}$')
axs[1].axhline(1/3,color='#a1adb7',lw=1,ls=':')
axs[1].set(xlabel=r'$x=R\sqrt{\mu_0 n e^2/m_{\rm red}}$',ylabel='Energy fraction',
 title='Allocation in the constrained minimum',ylim=(-.02,1.04),xlim=(.01,100))
axs[1].legend(frameon=False,loc='center left',fontsize=9)
for ax in axs:
    ax.grid(alpha=.17,color='#6b8293')
fig.savefig(HERE/'bessel-current-and-energy.png',dpi=220)
fig.savefig(HERE/'bessel-current-and-energy.svg')
print(HERE/'bessel-current-and-energy.png')
