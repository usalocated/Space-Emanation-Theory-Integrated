"""Collect existing final numerical exports without rerunning or refitting them."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SOURCES = {
    "published_baseline": "set-retained-results-synthesis-2026-11-05/github-publication.json",
    "dynamical_final_controls": "set-dynamical-em-source-closure-2026-11-06/FINAL-METRICS.json",
    "independent_core_material": "set-earth-core-forward-material-2026-11-06/SESSION-RESULTS.json",
    "matched_core_and_global_control_status": "set-earth-core-mantle-coupled-2026-11-06/SESSION-RESULTS.json",
    "original_earth_clock_scalar": "set-earth-magnetic-algebra-target-2026-11-06/clock_amplitude_candidate.json",
    "earth_algebra_and_spatial_results": "set-earth-magnetic-algebra-target-2026-11-06/RESULTS.json",
    "boundary_and_jupiter_results": "set-boundary-clock-magnetic-selection-2026-11-06/RESULTS.json",
    "correction_and_multipole_audit": "set-magnetic-correction-audit-2026-11-06/RESULTS.json",
    "earth_epochs_and_mars_venus_controls": "set-magnetic-measurement-vs-organization-2026-11-06/coordinator/controls.json",
    "mercury_and_solar_history": "set-magnetic-measurement-vs-organization-2026-11-06/history_mercury_sun/measurement_comparisons.json",
    "giant_planet_history": "set-magnetic-measurement-vs-organization-2026-11-06/history_giants/historical_results.json",
    "independent_source_domain_trials": "set-magnetic-measurement-vs-organization-2026-11-06/source_structure/source_structure_results.json",
}


def main():
    result = {
        "assembled_date": "2026-11-07",
        "purpose": "Exact carry-forward of existing numerical exports, with provenance; no new fit, no new physical test.",
        "reading_guide": {
            "dynamic_controls": "Internal mathematical controls, not observational validations. Preserve accepted/rejected and model-premise distinctions from [N6].",
            "material_models": "Independent input branches, not uniquely measured Earth states. The early map/core interface mismatches temperatures; the later matched branch is explicit.",
            "global_solver": "Matched finite thermal feedback not installed; no Earth amplitude or Earth-regime saturation predicted.",
            "earth_clock_scalar": "Exact normalized scalar and known-target arithmetic near-match, not a blind discovery.",
            "magnetic_observables": "Same-radius degree-one norm; full exterior-energy equivalent and solar axial-only equivalent are distinct observables.",
            "history": "Model revisions, shared-data inversions and physical epoch changes must not be pooled as independent statistical trials.",
            "upper_limits": "Mars global intrinsic dipole is distinct from crustal fields; Venus bound is not a detection or an assigned sigma rejection.",
        },
        "exports": {},
    }
    for name, rel in SOURCES.items():
        path = ROOT / "outputs" / rel
        raw = path.read_bytes()
        result["exports"][name] = {
            "source": str(path.relative_to(ROOT)),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "data": json.loads(raw),
        }
    out = HERE / "NUMERICAL-CARRYFORWARD.json"
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"output": str(out), "exports": len(SOURCES), "bytes": out.stat().st_size}))


if __name__ == "__main__":
    main()
