"""Convert published IGRF dipole coefficients into their vacuum-equivalent energy.

This is an observed-model energy diagnostic, not a prediction of core power.
Magnetospheric interference, higher harmonics and electric/radiative energy
are not part of this explicitly isolated quasistatic dipole component.
"""
from pathlib import Path
import json, math
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
source=ROOT/'outputs/set-magnetic-measurement-vs-organization-2026-11-06/coordinator/controls.json'
old=json.loads(source.read_text())
R=6371008.4
mu0=1.25663706127e-6
c=299792458.0
G=6.67430e-11
V=4*math.pi*R**3/3
M=5.97217e24
rows=[]
for e in old['Earth_IGRF14']['epoch_rows']:
    b=e['dipole_microT']*1e-6
    U=V*b*b/mu0
    rows.append({'year':e['year'],'B_microT':e['dipole_microT'],
      'U_dip_out_J':U,'minimum_total_magnetic_J':3*U,
      'U_dip_out_over_Mc2':U/(M*c*c)})
intervals=[]
byyear={x['year']:x for x in rows}
for start,end in [(1900.,2025.),(2000.,2025.),(2010.,2025.),(2020.,2025.)]:
    u1,u2=byyear[start]['U_dip_out_J'],byyear[end]['U_dip_out_J']
    dt=(end-start)*365.25*86400
    intervals.append({'start':start,'end':end,'delta_U_dip_out_J':u2-u1,
       'mean_dU_dip_out_dt_W':(u2-u1)/dt,
       'fractional_dipole_energy_change':u2/u1-1,
       'hypothetical_source_fraction_if_uncompensated':(u2-u1)/(M*c*c),
       'not_total_core_work':True})
record={'source':old['Earth_IGRF14']['source'],'input_SHA256':old['Earth_IGRF14']['SHA256'],
  'radius_m':R,'energy_definition':'U_dip,out = (4 pi R^3/(3 mu0)) B_eq^2',
  'rows':rows,'intervals':intervals,
  'physical_scope':'The dipole component energy outside a reference sphere in the quasistatic vacuum continuation. Its derivative measures net energy change of this component, not Ohmic dissipation, convection power, total magnetic energy or radiation. Internal transfers can preserve complete source energy and Q.'}
(HERE/'earth-external-energy-results.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'selected_epochs':[byyear[y] for y in (1900,2010,2025)],'intervals':intervals},indent=2))
