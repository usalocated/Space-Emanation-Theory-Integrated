"""Package only the specified scientific records, calculations and inputs."""
from pathlib import Path
import hashlib,json,re,zipfile

BASE=Path(__file__).resolve().parents[1]
ROOT=BASE.parents[1]
OUT=ROOT/'output/pdf'
selected=set()
for folder in ['root','corpus','selection','evolution','audit']:
    for p in (BASE/folder).rglob('*'):
        if not p.is_file() or any(x in p.parts for x in ['__pycache__','equation-preview','mpl-cache']):continue
        if p.suffix in {'.py','.txt','.json','.csv','.png','.svg','.npz'}:selected.add(p)
for name in ['RESEARCH-SYNTHESIS.txt','equation-audit.json','section-index.json','READ-FIRST.txt']:
    selected.add(BASE/name)
provenance=(BASE/'corpus/PROVENANCE-MAP.txt').read_text()
for item in re.findall(r'outputs/[^\s]+/RESEARCH-RECORD\.txt',provenance):selected.add(ROOT/item)
carry=json.loads((BASE/'corpus/NUMERICAL-CARRYFORWARD.json').read_text())
for item in carry['exports'].values():
    p=ROOT/item['source']
    if p.exists():selected.add(p)
for item in json.loads((BASE/'selection/INPUT-PROVENANCE.json').read_text())['input_files']:
    p=ROOT/item['path']
    if p.exists() and p.suffix in {'.txt','.json','.py'}:selected.add(p)
for item in [
 'outputs/set-magnetic-correction-audit-2026-11-06/inputs/FROZEN-INPUT-ALTERNATIVES.json',
 'outputs/set-boundary-clock-magnetic-selection-2026-11-06/further_planets/comparison.json',
 'outputs/set-magnetic-measurement-vs-organization-2026-11-06/source_structure/source_structure_results.json',
 'outputs/set-magnetic-measurement-vs-organization-2026-11-06/coordinator/controls.json',
 'outputs/set-magnetic-measurement-vs-organization-2026-11-06/earth_history/igrf14coeffs.txt',
 'outputs/set-magnetic-measurement-vs-organization-2026-11-06/measurement_and_state_controls.png',
 'outputs/set-magnetic-measurement-vs-organization-2026-11-06/coordinator/plot_research.py',
 'outputs/set-magnetic-measurement-vs-organization-2026-11-06/history_giants/sources.json',
 'outputs/set-magnetic-measurement-vs-organization-2026-11-06/history_giants/historical_models.csv',
 'outputs/set-magnetic-measurement-vs-organization-2026-11-06/history_giants/historical_results.json',
 'outputs/set-magnetic-measurement-vs-organization-2026-11-06/history_mercury_sun/measurement_comparisons.json',
 'outputs/set-dynamical-em-source-closure-2026-11-06/constraints/EXPLICIT-Q-SOURCE-FUNCTIONAL-AND-SCALAR-EVOLUTION.txt',
 'outputs/set-dynamical-em-source-closure-2026-11-06/constraints/CHARGED-COMPLETE-SOURCE-POSITIVE-CLOCK-SPLIT.txt',
 'outputs/set-dynamical-em-source-closure-2026-11-06/constraints/FINAL-ADVERSARIAL-SELECTION-AUDIT.txt',
 'outputs/set-dynamical-em-source-closure-2026-11-06/constraints/NONCOMMUTING-SQUARE-ROOT-CLOCK-BOUND.txt',
 'outputs/set-dynamical-em-source-closure-2026-11-06/shells/UNIFORM-MAGNETIC-MOTION-AND-QUANTUM-CLOCK.txt',
 'outputs/set-dynamical-em-source-closure-2026-11-06/shells/NONUNIFORM-LAPSE-PACKET-AND-CLOCK-ENERGY.txt',
 'outputs/set-dynamical-em-source-closure-2026-11-06/root/POSITIVE-SOURCE-ENERGY-SPLIT-WITH-DEFORMATION.txt',
 'outputs/set-dynamical-em-source-closure-2026-11-06/root/CAPACITY-ADMISSIBILITY-AND-CHARGED-SOURCE-DOMAINS.txt',
]:selected.add(ROOT/item)

readme='''SET SOURCE ENERGY AND MAGNETIC ORGANIZATION — RESEARCH COMPANION
7 November 2026

The accompanying PDF develops the retained post-publication derivations and
the new magnetic-organization calculations. Start with its results and the
corpus/RETENTION-DEPENDENCIES.txt map. Local [N1]–[N14] notes are research
records, not independently peer-reviewed sources.

DIRECTORY AND INPUT CONVENTIONS
The archive preserves outputs/<research-directory>/... paths. Unpack into a
working directory, then run commands from that root. Absolute original
workspace prefixes have been replaced by '.' in textual archive copies;
the original source hash and bundled hash are both recorded in MANIFEST.json.
Original local vendor folders are optional import fallbacks. Standard Python
packages installed in a normal environment also work. The source commentary
that prompted the additional cross-term test is not included and is not a
numerical input. Its hash is retained as provenance.

NEW CALCULATIONS
Let B denote outputs/set-source-magnetic-energy-and-organization-2026-11-06.
With Python3.12 or later and SymPy, NumPy, SciPy, Matplotlib and Pillow:
  python B/root/check_uniform_current_mode.py
  python B/root/check_earth_external_energy.py
  python B/selection/check_selection_and_bounds.py
  python B/selection/make_bessel_figure.py
  python B/evolution/check_exact_nested_energy.py
  python B/evolution/evolve_finite_inductive_driver.py
  python B/evolution/plot_finite_driver.py
  python B/audit/check_attachment_cross_energy.py
Replace B with the literal directory above. The scalar Earth and cross-term
scripts use the Python standard library. The symbolic/quadrature scripts
check identities; the driver script evolves a declared dimensionless test
material. None optimizes against a measured magnetic field.

PDF BUILD
Install ReportLab and the listed scientific packages. Then run
  python B/root/build_paper.py
It writes output/pdf/SET-source-energy-electromagnetic-evolution-and-magnetic-
organization.pdf. The builder obtains DejaVu/STIX fonts from Matplotlib and
uses the included figures and chapter sources. Byte-identical PDF hashes are
not expected across ReportLab versions, timestamps or font rasterizers.

RETAINED CORPUS
The fourteen research records, selected detailed derivations, input summaries
and numerical carry-forward records preserve the reported earlier results.
The archive does not bundle every previous large simulation checkpoint,
third-party solver or vendor environment. Re-running a full Earth material
simulation requires the independently cited material sources and software;
the PDF identifies its accepted regime and refinement limits. The new
finite-driver and constrained-current tests are reproducible here.

DATA AND UNITS
Keep each observable's radius and component convention. Solar axial-equivalent
fields, planetary dipole norms and total exterior-energy equivalents differ.
IGRF14 coefficient data are from NOAA/IAGA and retain their source metadata;
US Government data are not subject to US copyright. Other numerical summaries
are our calculated outputs with their primary-source links. Third-party
articles, private browser content and the supplied commentary are not bundled.

SCIENTIFIC SCOPE
The charged/canonical completion, material profiles and preparations are
declared. A constrained minimum is not assumed to be a dynamical attractor.
The finite-driver calculation is a magnetoquasistatic test, with omitted
electric/radiative scales audited. Planetary near matches and failures are
retained. No universal planetary magnetic amplitude is claimed.
'''
(BASE/'READ-FIRST.txt').write_text(readme)
OUT.mkdir(parents=True,exist_ok=True)
archive=OUT/'SET-source-energy-magnetic-organization-research.zip'
manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('READ-FIRST.txt',readme)
    for p in sorted(selected):
        if not p.exists():raise FileNotFoundError(p)
        raw=p.read_bytes();data=raw
        if p.suffix in {'.py','.txt','.json','.csv','.svg'}:
            text=raw.decode('utf-8')
            text=text.replace(str(ROOT),'.')
            text=text.replace('[user-supplied commentary; not a numerical input]','[user-supplied commentary; not a numerical input]')
            data=text.encode('utf-8')
        name=str(p.relative_to(ROOT));z.writestr(name,data)
        manifest.append({'path':name,'source_sha256':hashlib.sha256(raw).hexdigest(),'bundled_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
    z.writestr('MANIFEST.json',json.dumps({'date':'2026-11-07','normalization':'Original workspace prefix replaced by dot in text copies; source and bundle hashes retained.','files':manifest},indent=2))
report={'archive':str(archive.relative_to(ROOT)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(manifest)+2}
(BASE/'archive-manifest.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
