"""Build the retained-results synthesis with numbered, auditable derivations."""
from pathlib import Path
import os, sys, json, hashlib, html, importlib.util, re
BASE=Path(__file__).resolve().parents[1]
ROOT=BASE.parents[1]
os.environ['MPLCONFIGDIR']=str(BASE/'tmp/mpl-cache')
sys.path[:0]=[str(ROOT/'work/set-ngc3198-field-runtime'),str(ROOT/'work/three-galaxy-set/vendor')]
import matplotlib
matplotlib.use('Agg')
from matplotlib.mathtext import math_to_image
from matplotlib.font_manager import FontProperties
from PIL import Image as PILImage
from reportlab.platypus import BaseDocTemplate,PageTemplate,Frame,Paragraph,Spacer,Image,Table,TableStyle,PageBreak,KeepTogether,CondPageBreak
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER

OUT=BASE/'output/pdf'; OUT.mkdir(exist_ok=True,parents=True)
ASSETS=BASE/'tmp/pdfs/equations'; ASSETS.mkdir(exist_ok=True,parents=True)
FONT=Path(matplotlib.get_data_path())/'fonts/ttf'
for name,file in [('Body','DejaVuSerif.ttf'),('BodyBold','DejaVuSerif-Bold.ttf'),('BodyItalic','DejaVuSerif-Italic.ttf'),('Sans','DejaVuSans.ttf'),('SansBold','DejaVuSans-Bold.ttf'),('MathInline','STIXGeneral.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(FONT/file)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='BodyBold',italic='BodyItalic',boldItalic='BodyBold')
ST=getSampleStyleSheet()
for spec in [dict(name='P',fontName='Body',fontSize=10.1,leading=15,spaceAfter=8,allowWidows=0,allowOrphans=0),dict(name='H1',fontName='SansBold',fontSize=14,leading=18,spaceBefore=17,spaceAfter=10,keepWithNext=True),dict(name='H2',fontName='SansBold',fontSize=10.8,leading=15,spaceBefore=11,spaceAfter=7,keepWithNext=True),dict(name='Title',fontName='SansBold',fontSize=25,leading=31,spaceAfter=13),dict(name='Subtitle',fontName='Sans',fontSize=15.5,leading=21,spaceAfter=13),dict(name='Small',fontName='Sans',fontSize=8.5,leading=12,spaceAfter=8),dict(name='Cell',fontName='Sans',fontSize=8.3,leading=11.7),dict(name='Note',fontName='Body',fontSize=9.3,leading=14),dict(name='EqNum',fontName='Sans',fontSize=8.5,leading=12,alignment=2),dict(name='TOC',fontName='Sans',fontSize=9.2,leading=13.4,leftIndent=0,firstLineIndent=0,spaceBefore=4)]:
    spec['name']='SET'+spec['name'];spec['textColor']=colors.HexColor('#142534')
    ST.add(ParagraphStyle(**spec))
ST['SETTOC'].fontSize=8.7
ST['SETTOC'].leading=12
ST['SETTOC'].spaceBefore=0
ST['SETTOC'].spaceAfter=0
ST.add(ParagraphStyle(name='SETReference',parent=ST['SETP'],fontSize=9.1,leading=13,spaceAfter=6))
WIDTH=6.9*inch
def clean(t):
    t=str(t).replace('\u2011','-').replace('\u2010','-').replace('\u2013','-').replace('\u2014',' - ')
    t=t.replace('〈','⟨').replace('〉','⟩').replace('⁻⁴ᐟ³','<super>-4/3</super>').replace('¹ᐟ²','<super>1/2</super>').replace('ᐟ','/')
    t=re.sub(r'<(?!/?(?:b|i|u|font|sub|super|br|a|strong|em|para)(?:\s|>|/))','&lt;',t)
    for ch,repl in {'𝒟':'D','𝒢':'G','𝒮':'S','𝔪':'m'}.items():t=t.replace(ch,'<i>'+repl+'</i>')
    for ch in 'ℓℰ':t=t.replace(ch,'<font name="MathInline">'+ch+'</font>')
    return t

class PDF(BaseDocTemplate):
    def __init__(self,path):
        super().__init__(str(path),pagesize=(8.5*inch,11*inch),leftMargin=.8*inch,rightMargin=.8*inch,topMargin=.72*inch,bottomMargin=.72*inch,title='Space Emanation Theory - Source Energy, Electromagnetic Evolution and Magnetic Organization',author='Space Emanation Theory research',pageCompression=1)
        self.addPageTemplates(PageTemplate(id='main',frames=[Frame(self.leftMargin,self.bottomMargin,self.width,self.height,id='normal',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=self.decorate))
    def decorate(self,c,doc):
        c.saveState();c.setStrokeColor(colors.HexColor('#bfd0db'));c.setLineWidth(.45)
        c.line(.8*inch,.51*inch,7.7*inch,.51*inch)
        c.setFont('Sans',7.1);c.setFillColor(colors.HexColor('#4c6373'))
        c.drawString(.8*inch,.35*inch,'SET  /  SOURCE ENERGY AND MAGNETIC ORGANIZATION')
        c.drawRightString(7.7*inch,.35*inch,str(doc.page));c.restoreState()
    def afterFlowable(self,f):
        if isinstance(f,Paragraph) and hasattr(f,'bookmark'):
            self.canv.bookmarkPage(f.bookmark)
            self.canv.addOutlineEntry(f.getPlainText(),f.bookmark,0,False)
            self.notify('TOCEntry',(0,f.getPlainText(),self.page,f.bookmark))

class Draft:
    def __init__(self): self.story=[];self.plain=[];self.n=0;self.en=0;self.audit=[];self.sections=[]
    def p(self,text,keep=False):
        text=clean(text);p=Paragraph(text,ST['SETP']);self.story.append(KeepTogether([p]) if keep else p);self.plain.append(text)
    def h1(self,text,key=None):
        self.n+=1;key=key or 'section-'+str(self.n)
        text=f'{self.n}. {clean(text)}';p=Paragraph(text,ST['SETH1']);p.bookmark=key
        self.story.extend([CondPageBreak(85),p]);self.plain.append('\n'+text+'\n');self.sections.append({'number':self.n,'title':text,'key':key})
    def h2(self,text):
        self.story.append(Paragraph(clean(text),ST['SETH2']));self.plain.append('\n'+clean(text))
    def eq(self,latex,key=None):
        if self.story and isinstance(self.story[-1],Paragraph):
            self.story[-1].keepWithNext=True
        self.en+=1;lines=[latex] if isinstance(latex,str) else list(latex);flows=[]
        lines=[re.sub(r'\\(mathcal|mathbf)\s+([A-Za-z])',r'\\\1{\2}',part) for part in lines]
        lines=[re.sub(r'\\sqrt(?![\{\[])\s*([A-Za-z0-9])',r'\\sqrt{\1}',part) for part in lines]
        for part in lines:
            name=hashlib.sha256(part.encode()).hexdigest()[:20]+'.png';path=ASSETS/name
            if not path.exists(): math_to_image('$'+part+'$',str(path),prop=FontProperties(size=13),dpi=300,format='png',color='#101d27')
            with PILImage.open(path) as im:w,h=im.size
            scale=min(72/300,(WIDTH-48)/w);flows.append(Image(str(path),width=w*scale,height=h*scale))
            self.audit.append({'eq':self.en,'latex':part,'width_pt':w*scale,'height_pt':h*scale,'font_effective_pt':13*scale/(72/300)})
        inner=Table([[f] for f in flows],colWidths=[WIDTH-48]);inner.setStyle(TableStyle([('ALIGN',(0,0),(-1,-1),'CENTER'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),0),('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2)]))
        outer=Table([[inner,Paragraph(f'({self.en})',ST['SETEqNum'])]],colWidths=[WIDTH-38,38]);outer.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),0),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),10)]))
        self.story.append(outer);self.plain.append('\n('+str(self.en)+') '+'\n'.join(lines)+'\n')
    def table(self,headers,rows,widths=None,padding=7):
        allrows=[headers]+rows
        cells=[[Paragraph(clean(html.escape(str(c))),ST['SETCell']) for c in row] for row in allrows]
        widths=[WIDTH*w/sum(widths) for w in widths] if widths else [WIDTH/len(headers)]*len(headers)
        tb=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
        tb.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e8f0f5')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.65,colors.HexColor('#7691a5')),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#d8e0e6')),('TOPPADDING',(0,0),(-1,-1),padding),('BOTTOMPADDING',(0,0),(-1,-1),padding),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7)]))
        self.story.extend([tb,Spacer(1,10)]);self.plain.extend([' | '.join(map(str,r)) for r in allrows])
    def note(self,title,text):
        tb=Table([[Paragraph('<b>'+clean(title)+'</b><br/>'+clean(text),ST['SETNote'])]],colWidths=[WIDTH])
        tb.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),colors.HexColor('#eff4f7')),('BOX',(0,0),(-1,-1),.4,colors.HexColor('#c5d3dd')),('TOPPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),10),('LEFTPADDING',(0,0),(-1,-1),11),('RIGHTPADDING',(0,0),(-1,-1),11)]))
        self.story.extend([tb,Spacer(1,10)]);self.plain.extend([clean(title),clean(text)])
    def fig(self,path,caption,width=1):
        path=Path(path)
        if not path.is_absolute():path=BASE/'figures'/path
        with PILImage.open(path) as im:w,h=im.size
        maxwidth=WIDTH*width;maxheight=6.4*inch;ratio=min(maxwidth/w,maxheight/h)
        im=Image(str(path),width=w*ratio,height=h*ratio);im.hAlign='CENTER'
        self.story.append(KeepTogether([Spacer(1,7),im,Paragraph(clean(caption),ST['SETSmall']),Spacer(1,5)]));self.plain.append('[Figure] '+clean(caption))
    def pagebreak(self):self.story.append(PageBreak())

def module(name,path,d):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.add(d)



def main():
    d=Draft()
    d.story.append(Spacer(1,36))
    d.story.append(Paragraph('SPACE EMANATION THEORY',ST['SETSubtitle']))
    d.story.append(Paragraph('Source Energy, Electromagnetic Evolution and Magnetic Organization',ST['SETTitle']))
    d.story.append(Paragraph('Research synthesis · Rough Draft 1 · 7 November 2026',ST['SETSmall']))
    d.story.append(Spacer(1,18))
    d.p('From capacity and complete source accounting to signed currents, material work and a calculated magnetic allocation.')
    d.p('The same energy that generates clocks and material motion must account for the field those sources establish. This research follows that requirement into the electromagnetic sector, tests the planetary rotational-clock candidate, and derives organized-field energies in explicitly supplied material states.')
    d.note('Principal result','A finite charged-material preparation can calculate its magnetic share through reciprocal evolution. The field geometry and driver recoil determine the allocation. A separate positive variational calculation determines the least energy needed to sustain a specified dipole.')
    d.p('The development retains source identities, conditional field selections, numerical checks and empirical comparisons in one sequence. Every additional material input and approximation is stated. The work continues the published <i>Source, Clock and Interacting-Field Energy</i> synthesis.')
    d.pagebreak()
    d.story.append(Paragraph('Contents',ST['SETH1']))
    toc=TableOfContents();toc.levelStyles=[ST['SETTOC']];d.story.append(toc);d.pagebreak()
    spec=importlib.util.spec_from_file_location('synthesis',BASE/'root/synthesis_chapters.py');syn=importlib.util.module_from_spec(spec);spec.loader.exec_module(syn)
    syn.opening(d)
    module('post_baseline',BASE/'corpus/post_baseline_chapters.py',d)
    module('material',BASE/'root/material_chapters.py',d)
    module('observations',BASE/'root/observation_chapters.py',d)
    module('selection',BASE/'selection/chapter.py',d)
    module('uniform',BASE/'root/uniform_chapter.py',d)
    module('evolution',BASE/'evolution/chapter.py',d)
    if (BASE/'root/attachment_chapter.py').exists():module('adjacent',BASE/'root/attachment_chapter.py',d)
    syn.closing(d)
    def reference_p(text,keep=False):
        text=clean(text);p=Paragraph(text,ST['SETReference']);d.story.append(KeepTogether([p]) if keep else p);d.plain.append(text)
    d.p=reference_p
    module('references',BASE/'corpus/reference_chapter.py',d)
    path=OUT/'SET-source-energy-electromagnetic-evolution-and-magnetic-organization.pdf'
    PDF(path).multiBuild(d.story)
    (BASE/'RESEARCH-SYNTHESIS.txt').write_text('\n\n'.join(d.plain))
    (BASE/'equation-audit.json').write_text(json.dumps(d.audit,indent=2))
    (BASE/'section-index.json').write_text(json.dumps(d.sections,indent=2))
    final=ROOT/'output/pdf'/path.name;final.parent.mkdir(parents=True,exist_ok=True);final.write_bytes(path.read_bytes())
    print(json.dumps({'pdf':str(final),'bytes':final.stat().st_size,'sections':d.n,'equations':d.en,'smallest_equation_font':min(x['font_effective_pt'] for x in d.audit)},indent=2))

if __name__=='__main__':main()
