"""Exact regular current geometry and conditional common-energy allocation.

This is a weak-motion, quasistatic, supported two-fluid test. Charge labels,
common coupling, profiles and preparation are specified; no measured planetary
field appears as an input. The fields are regular inside a ball. The material
profiles have a sharp boundary but there is no magnetic surface-current sheet.
"""
from pathlib import Path
import json, math, sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / 'outputs/set-invariant-library/vendor'))
import sympy as sp

r, a, mu0, rhoq, om, q = sp.symbols('r a mu0 rhoq om q', positive=True)
f = mu0*rhoq*om*(a*a*r/6-r**3/10)
br = 2*f/r
bt = -(f+r*sp.diff(f,r))/r
m = 4*sp.pi*rhoq*om*a**5/15
fout = mu0*m/(4*sp.pi*r**2)
uin = sp.integrate(r**2*(4*sp.pi*br**2/3+8*sp.pi*bt**2/3)/(2*mu0),(r,0,a))
uout = mu0*m**2/(12*sp.pi*a**3)
utotal = sp.simplify(uin+uout)
ujA = sp.integrate(4*sp.pi*rhoq*om*r**3*f/3,(r,0,a))
expected = mu0*q*q*a*om*om/(70*sp.pi)
checks = {
 'ampere_radial_equation': sp.simplify(sp.diff(f,r,2)+2*sp.diff(f,r)/r-2*f/r**2+mu0*rhoq*om*r)==0,
 'potential_continuity': sp.simplify(f.subs(r,a)-fout.subs(r,a))==0,
 'tangential_field_continuity': sp.simplify(bt.subs(r,a)+((fout+r*sp.diff(fout,r))/r).subs(r,a))==0,
 'field_energy_equals_half_jA': sp.simplify(utotal-ujA)==0,
 'uniform_ball_total_energy': sp.simplify(utotal.subs(rhoq,3*q/(4*sp.pi*a**3))-expected)==0,
 'external_dipole_fraction_7_over_30': sp.simplify(uout/utotal-sp.Rational(7,30))==0,
}
Ip, Im, Op, Om, L, delta = sp.symbols('Ip Im Op Om L delta', positive=True)
sol = sp.solve([Ip*Op+Im*Om-L,Op-Om-delta],(Op,Om))
kin = (Ip*Op**2+Im*Om**2)/2
Ir = Ip*Im/(Ip+Im)
checks['centre_relative_kinetic_split'] = sp.simplify(kin.subs(sol)-L**2/(2*(Ip+Im))-Ir*delta**2/2)==0
IB, P = sp.symbols('IB P', positive=True)
H = P**2/(2*(Ir+IB))
w = sp.diff(H,P)
checks['canonical_energy_allocation'] = sp.simplify(H-(Ir+IB)*w*w/2)==0
checks['magnetic_share'] = sp.simplify((IB*w*w/2)/H-IB/(Ir+IB))==0
checks['positive_hamiltonian_hessian'] = sp.simplify(sp.diff(H,P,2)-1/(Ir+IB))==0
assert all(checks.values()), checks

# NIST CODATA 2022, with measured charge/mass and vacuum calibration as inputs.
e=1.602176634e-19
me=9.1093837139e-31
mp=1.67262192595e-27
c=299792458.0
G=6.67430e-11
mu=1.25663706127e-6
reduced=me*mp/(me+mp)
def trial(n, radius=.01, excitation=1e-18):
    V=4*math.pi*radius**3/3
    N=n*V
    charge=e*N
    Irel=2*N*reduced*radius**2/5
    Imag=mu*charge**2*radius/(35*math.pi)
    Itot=Irel+Imag
    domega=math.sqrt(2*excitation/Itot)
    dipole=charge*radius**2*domega/5
    B=mu*dipole/(4*math.pi*radius**3)
    UB=Imag*domega**2/2
    Uout=mu*dipole**2/(12*math.pi*radius**3)
    K=Irel*domega**2/2
    Hrest=N*(me+mp)*c*c
    Qbase=math.sqrt(24*math.pi*G*V*Hrest/c**2)
    # Use exact differential of Q^2, not near-cancelling Q subtraction.
    dQ2=24*math.pi*G*V*excitation/c**2
    # Coordinate-independent weak common rotation is removed: L_mechanical=0.
    op=me/(me+mp)*domega
    oe=-mp/(me+mp)*domega
    return dict(n_m3=n,R_m=radius,N_each_species=N,excitation_J=excitation,
      species_charge_abs_C=charge,I_relative_kg_m2=Irel,I_magnetic_kg_m2=Imag,
      inertia_ratio=Imag/Irel,magnetic_fraction=UB/excitation,
      exterior_fraction_of_magnetic=Uout/UB,exterior_fraction_of_excitation=Uout/excitation,
      delta_omega_rad_s=domega,positive_omega_rad_s=op,negative_omega_rad_s=oe,
      max_surface_speed_over_c=max(abs(op),abs(oe))*radius/c,
      B_equator_T=B,dipole_Am2=dipole,U_B_J=UB,U_out_J=Uout,K_relative_J=K,
      ledger_relative_error=(UB+K-excitation)/excitation,
      bulk_mass_kg=N*(me+mp),rest_energy_J=Hrest,Q_base_m3_s=Qbase,
      delta_Q_squared_m6_s2=dQ2,
      interpretation='Specified ideal current-mode excitation; not a planetary prediction or a charge-origin derivation.')
trials=[trial(10.0**k) for k in (12,14,16,18,20,22,24)]
result={'symbolic_checks':checks,'symbolic_total_energy':str(utotal),
        'symbolic_external_fraction':str(sp.simplify(uout/utotal)),
        'constants_source':'https://physics.nist.gov/cuu/pdf/wall_2022.pdf',
        'inputs':'R=1 cm; E_excitation=1e-18 J; one species each of proton/electron masses; equal uniform number densities; ideal quasistatic supported relative rotation.',
        'trials':trials}
(HERE/'uniform-current-mode-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':checks,'representative_n1e20':trials[4]},indent=2))
