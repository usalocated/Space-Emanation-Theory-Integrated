"""A regular, explicitly calculated current mode and its source-energy split."""
import json
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]

def add(d):
    d.h1('A regular current mode with a calculated magnetic share','uniform-current')
    d.p('A concrete example shows how source energy can be allocated once the signed material state is supplied. Take equal uniform number densities n of positive and negative carriers inside a supported sphere of radius a. Their charges are +e and -e, and their masses are m₊ and m₋. Each population is restricted to a rigid angular mode about the same axis. The profiles, mode restriction and preparation are explicit test data; the electromagnetic coupling and field energy are the retained ones.')
    d.p('Let N_p=4πna³/3 be the particle count of each species and q_e=eN_p the magnitude of each population\'s charge. The total local charge vanishes. The relative angular velocity ω=Ω₊-Ω₋ nevertheless gives')
    d.eq([r'j_\varphi(r,\theta)=\rho_e\omega r\sin\theta,\qquad \rho_e=en,',r'\mathfrak{m}=\frac{4\pi}{3}\int_0^a\rho_e\omega r^4\,dr=\frac{q_ea^2\omega}{5}.'])
    d.p('The spherical current is divergence-free and tangent to the boundary. Write Aφ=f(r)sinθ. Ampere\'s equation becomes a radial equation with a regular origin and the decaying exterior dipole:')
    d.eq([r'f^{\prime\prime}+\frac{2}{r} f^{\prime}-\frac{2f}{r^2}=-\mu_0\rho_e\omega r,',r'f(r)=\mu_0\rho_e\omega\left(\frac{a^2r}{6}-\frac{r^3}{10}\right),\quad 0\leq r\leq a,',r'f(r)=\frac{\mu_0\mathfrak{m}}{4\pi r^2},\quad r\geq a.'])
    d.p('Both the normal and tangential magnetic fields match at a. There is no magnetic surface-current sheet in this example. Integrating the field energy, or independently evaluating one half of the current-potential integral, gives')
    d.eq([r'U_B=\int\frac{B^2}{2\mu_0}\,dV=\frac{1}{2}\int\mathbf j\!\cdot\mathbf A\,dV=\frac{\mu_0q_e^2a\omega^2}{70\pi},',r'U_{d,\rm out}(a)=\frac{\mu_0\mathfrak{m}^2}{12\pi a^3}=\frac{7}{30}U_B.'])
    d.p('The factor 7/30 has been calculated from the actual current geometry. It was not selected from the observed field. This gives a regular-volume example below the sharp one-third exterior bound.')
    d.h2('Material backreaction determines the rest of the partition')
    d.p('Separate the common rotation from the signed relative mode. The material inertias are I₊=2N_pm₊a²/5 and I₋=2N_pm₋a²/5. At fixed total material angular momentum, the quadratic kinetic energy splits into common rotation and a relative contribution.')
    d.eq([r'K=\frac{L^2}{2(I_++I_-)}+\frac{1}{2} I_r\omega^2,',r'I_r=\frac{I_+I_-}{I_++I_-}=\frac{2}{5}N_pm_{\rm red}a^2,\qquad m_{\rm red}=\frac{m_+m_-}{m_++m_-}.'])
    d.p('The field contributes an inductive inertia I_B. In the retained magnetoquasistatic reduction, eliminating the field consistently from the Lagrangian gives the canonical relative momentum P=(I_r+I_B)ω and its common Hamiltonian:')
    d.eq([r'I_B=\frac{\mu_0q_e^2a}{35\pi},\qquad P=(I_r+I_B)\omega,',r'H_{\rm mode}=\frac{P^2}{2(I_r+I_B)}=\frac{1}{2}(I_r+I_B)\omega^2.'])
    d.p('The positive Hessian is 1/(I_r+I_B). A finite impulse must supply the canonical momentum including the induced field response. Computing the material speed from I_r alone while also adding the magnetic energy would overcount the delivered energy. Within this specified mode, the shares are now fixed:')
    d.eq([r'\frac{U_B}{H_{\rm mode}}=\frac{I_B}{I_r+I_B},\qquad \frac{K_r}{H_{\rm mode}}=\frac{I_r}{I_r+I_B},',r'\frac{U_{d,\rm out}}{H_{\rm mode}}=\frac{7}{30}\frac{I_B}{I_r+I_B}.'])
    d.p('This is an actual allocation formula. Its ingredients are the specified carrier masses, density, geometry and charged coupling. There is no free magnetic efficiency. A different material mode has a different calculable response; the complete source energy by itself does not prescribe this mode.')
    d.h2('A numerical calculation without an observed magnetic target')
    d.p('Choose a=1 cm, n=10²⁰ m⁻³ and a supplied mode excitation of 10⁻¹⁸ J. Use measured proton and electron masses and the standard vacuum calibration. This is an ideal supported two-fluid verification problem, not a planet or a prediction of an independently observed laboratory plasma. [D12.]')
    x=json.loads((BASE/'root/uniform-current-mode-results.json').read_text())['trials'][4]
    d.table(['Calculated quantity','Result'],[
      ['Relative material inertia','1.52546 × 10⁻²⁰ kg m²'],
      ['Inductive inertia','5.14742 × 10⁻¹⁹ kg m²'],
      ['Relative angular speed','1.94258 rad/s'],
      ['Magnetic share of the excitation','0.971218'],
      ['Exterior dipole share of the excitation','0.226617'],
      ['Equatorial field at a','0.260740 nT'],
      ['Largest surface speed divided by c','6.48 × 10⁻¹¹']], [.62,.38])
    d.p('The field, carrier kinetic energy and source work balance exactly in the reduced model. Ten symbolic checks verify the field equation, boundary matching, energy integral, kinetic split and common generator. The source-law conversion remains available for a specified complete reference volume: Δ(Q_s²/V_ref)=(24πG/c²)ΔH_complete. During an internal transfer from a finite driver, its energy loss must be included; the complete source Q_s can remain constant while H_mode grows.')
    d.p('The magnetic field is quasistatic here. Its finite-frequency electric storage and outgoing radiation are higher-order corrections, not hidden reservoirs counted as zero in a supposedly exact relativistic solution. The next experiment retains an actual finite driver, reciprocal feedback and heat production, and checks the size of the omitted quasistatic terms.')
