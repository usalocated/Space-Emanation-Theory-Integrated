"""Finite mechanical drivers -> organized magnetic energy, no field target.

Two neutral pairs of rotating spherical shells, fixed radii, exact quasistatic
self/mutual inductance, finite torsional drivers and resistive heat return.
This is a dimensionless, nonrelativistic, magnetoquasistatic verification
problem. The geometry, inertias, springs, resistance and preparations are new
explicit test data, not terrestrial measurements or a planetary dynamo model.
"""
from pathlib import Path
import json
import sys
sys.dont_write_bytecode=True
import numpy as np
from scipy.linalg import expm, block_diag, eigvalsh
from scipy.optimize import minimize_scalar

OUT=Path(__file__).resolve().parent
A_RAD=np.array([.55,1.])
Q_CHARGE=np.array([1.,1.])
I_REL=np.array([.20,.40])
J_DRIVER=np.array([.70,1.10])
K_SPRING=np.array([.80,1.20])
R_DRAG=np.array([.03,.05])
ANGLE=.20
END=80.
C_DIMENSIONLESS=1.e4
N=2
L=np.outer(Q_CHARGE,Q_CHARGE)*np.minimum.outer(A_RAD,A_RAD)**2/np.maximum.outer(A_RAD,A_RAD)
DIPOLE=Q_CHARGE*A_RAD**2
L_OUT=np.outer(DIPOLE,DIPOLE)/3

def quadratic_matrix(fn,size=8):
    """Recover a symmetric form from independently supplied scalar evaluation."""
    basis=np.eye(size); q=np.zeros((size,size))
    for i in range(size): q[i,i]=fn(basis[i])
    for i in range(size):
        for j in range(i):
            q[i,j]=q[j,i]=(fn(basis[i]+basis[j])-q[i,i]-q[j,j])/2
    return q

def matrices(resistance=R_DRAG,feedback=1.):
    effective=block_diag(np.diag(I_REL)+feedback*L,np.diag(J_DRIVER))
    kk=np.diag(K_SPRING)
    stiffness=np.block([[kk,-kk],[-kk,kk]])
    damping=np.diag(np.r_[resistance,np.zeros(N)])
    linear=np.block([[np.zeros((4,4)),np.eye(4)],
                     [-np.linalg.solve(effective,stiffness),-np.linalg.solve(effective,damping)]])
    return effective,stiffness,linear

def preparation(sign):
    # Same device, driver energy, zero current and bulk state; only the
    # two finite driver displacements differ in relative sign.
    return np.r_[np.zeros(N),ANGLE*np.array([1.,sign]),np.zeros(2*N)]

def energies(y):
    th,ph,om,nu=y[:2],y[2:4],y[4:6],y[6:8]
    material=.5*np.dot(I_REL*om,om)
    driver=.5*np.dot(J_DRIVER*nu,nu)+.5*np.dot(K_SPRING*(th-ph),th-ph)
    magnetic=.5*om@L@om
    outside=.5*om@L_OUT@om
    return np.array([material,driver,magnetic,outside])

def magnetic_radial_integral(om):
    """Integrate exact piecewise Br and Btheta independently of L.

    In the selected units mu0/(18*pi)=1 and m_i=q_i*a_i²*omega_i/3.
    The angular integration is exact; these are analytic radial integrals.
    """
    moment=DIPOLE*om/3
    mu0=18*np.pi
    total=0.;regions=[]
    cuts=np.r_[0.,A_RAD]
    for j,(lo,hi) in enumerate(zip(cuts[:-1],cuts[1:])):
        enclosed=np.sum(moment[:j])
        outer=np.sum(moment[j:]/A_RAD[j:]**3)
        piece=mu0/(12*np.pi)*((enclosed**2*(lo**-3-hi**-3) if lo else 0.)
                                     +2*outer**2*(hi**3-lo**3))
        regions.append(piece);total+=piece
    outside=mu0*np.sum(moment)**2/(12*np.pi*A_RAD[-1]**3)
    total+=outside
    return total,np.array(regions),outside

def omitted_inductive_electric_energy(omdot):
    """Leading E=-dA/dt energy; diagnostic, not included in MQS evolution.

    Integrates the same piecewise vector potential through infinity. At large
    r the instantaneous approximation is not causal, but its finite leading
    near-zone electric energy is a small-parameter consistency diagnostic.
    """
    moment_dot=DIPOLE*omdot/3
    value=0.
    cuts=np.r_[0.,A_RAD]
    for j,(lo,hi) in enumerate(zip(cuts[:-1],cuts[1:])):
        m=np.sum(moment_dot[:j]);w=np.sum(moment_dot[j:]/A_RAD[j:]**3)
        value += ((m*m*(1/lo-1/hi) if lo else 0.)+m*w*(hi*hi-lo*lo)+w*w*(hi**5-lo**5)/5)
    value+=np.sum(moment_dot)**2/A_RAD[-1]
    return 18*np.pi/(12*np.pi*C_DIMENSIONLESS**2)*value

def powers(y,linear,resistance):
    dy=linear@y
    th,ph,om=y[:2],y[2:4],y[4:6]
    omdot=dy[4:6]
    source_work=-np.dot(K_SPRING*(th-ph),om)
    magnetic_work=om@L@omdot
    # Surface integral E_phi B_theta at the outer sphere, independently
    # evaluated with E_phi=-mu0 mdot sin(theta)/(4pi R²).
    moment=np.dot(DIPOLE,om)/3
    moment_dot=np.dot(DIPOLE,omdot)/3
    poynting=18*np.pi*moment*moment_dot/(6*np.pi*A_RAD[-1]**3)
    heat=np.dot(resistance*om,om)
    return np.array([heat,source_work,magnetic_work,poynting])

def rhs(z,linear,resistance):
    return np.r_[linear@z[:8],powers(z[:8],linear,resistance)]

def rk4(z,dt,linear,resistance):
    k1=rhs(z,linear,resistance)
    k2=rhs(z+dt*k1/2,linear,resistance)
    k3=rhs(z+dt*k2/2,linear,resistance)
    k4=rhs(z+dt*k3,linear,resistance)
    return z+dt*(k1+2*k2+2*k3+k4)/6

def exact_reference(y0,linear,resistance):
    """Independent matrix-exponential evolution of state AND quadratic ledgers.

    The four energy transfers are not recovered by subtracting final energies.
    Evolve Y=y y^T by its Kronecker generator and integrate each power form.
    """
    moment_generator=np.kron(linear,np.eye(8))+np.kron(np.eye(8),linear)
    qforms=np.array([quadratic_matrix(lambda y,k=k:powers(y,linear,resistance)[k])
                    for k in range(4)])
    augmented=np.zeros((68,68));augmented[:64,:64]=moment_generator
    augmented[64:,:64]=qforms.reshape(4,64)
    z0=np.r_[np.outer(y0,y0).ravel(),np.zeros(4)]
    zend=expm(END*augmented)@z0
    yend=expm(END*linear)@y0
    return yend,zend[64:],float(np.max(np.abs(zend[:64].reshape(8,8)-np.outer(yend,yend))))

def run(sign,dt,resistance=R_DRAG,feedback=1.,record=False):
    effective,stiffness,linear=matrices(resistance,feedback)
    y0=preparation(sign);z=np.r_[y0,np.zeros(4)]
    e0=np.sum(energies(y0)[:3])
    max_energy=0.;max_ledgers=np.zeros(4);max_geometry=0.;max_fraction=0.
    history=[];state_history=[]
    max_speed=0.
    for step in range(round(END/dt)+1):
        t=step*dt
        ek,ed,eb,eo=energies(z[:8]);heat,ws,wb,flux=z[8:]
        max_energy=max(max_energy,abs(ek+ed+eb+heat-e0))
        residuals=np.array([ed-e0+ws,ek+eb-ws+heat,eb-wb,eo-flux])
        max_ledgers=np.maximum(max_ledgers,np.abs(residuals))
        ub_geom,_,uo_geom=magnetic_radial_integral(z[4:6])
        max_geometry=max(max_geometry,abs(ub_geom-eb),abs(uo_geom-eo))
        if eb>1e-20:max_fraction=max(max_fraction,eo/eb)
        max_speed=max(max_speed,float(np.max(np.abs(z[4:6])*A_RAD))/C_DIMENSIONLESS)
        if record:
            history.append([t,ek,ed,eb,eo,heat,ws,wb,flux,np.dot(DIPOLE,z[4:6])])
            state_history.append(z[:8].copy())
        if step<round(END/dt):z=rk4(z,dt,linear,resistance)
    ref_y,ref_ledger,moment_residual=exact_reference(y0,linear,resistance)
    row=dict(sign=sign,dt=dt,feedback_multiplier=feedback,resistance=resistance.tolist(),
        initial_energy=e0,final_material_kinetic=float(ek),final_driver_energy=float(ed),
        final_total_magnetic=float(eb),final_exterior_dipole=float(eo),
        final_heat=float(heat),cumulative_driver_work=float(ws),
        cumulative_induction_work=float(wb),cumulative_outer_Poynting_flux=float(flux),
        max_complete_energy_absolute_error=max_energy,
        max_complete_energy_relative_error=max_energy/e0,
        max_separate_ledger_errors=max_ledgers.tolist(),
        max_direct_field_geometry_error=max_geometry,
        max_exterior_fraction=max_fraction,max_relative_speed_over_c=max_speed,
        final_state_error_vs_exact_exponential=float(np.max(np.abs(z[:8]-ref_y))),
        final_transfer_error_vs_exact_exponential=float(np.max(np.abs(z[8:]-ref_ledger))),
        exact_second_moment_consistency_error=moment_residual)
    if record:
        data=np.array(history);states=np.array(state_history)
        # Refine physical peaks by evaluating the exact coupled solution.
        peaks={}
        for label,col,ei in [('total_magnetic',3,2),('exterior_dipole',4,3)]:
            idx=int(np.argmax(data[:,col]));left=max(0,data[max(0,idx-2),0]);right=min(END,data[min(len(data)-1,idx+2),0])
            result=minimize_scalar(lambda t:-energies(expm(t*linear)@y0)[ei],bounds=(left,right),method='bounded',options={'xatol':1e-13})
            yp=expm(result.x*linear)@y0;ep=energies(yp)
            peaks[label]=dict(time=float(result.x),energy=float(-result.fun),fraction_of_initial=float(-result.fun/e0),
                             simultaneous_total_magnetic=float(ep[2]),simultaneous_exterior=float(ep[3]),
                             simultaneous_exterior_fraction=float(ep[3]/ep[2]),relative_angular_velocities=yp[4:6].tolist())
        row['exact_solution_peaks']=peaks
        # Quantify the terms omitted by the declared slow-time Maxwell limit.
        dy=states@linear.T
        ddy=dy@linear.T
        electric=np.array([omitted_inductive_electric_energy(v[4:6]) for v in dy])
        radiation=(ddy[:,4:6]@DIPOLE)**2/(3*C_DIMENSIONLESS**3)
        row['magnetoquasistatic_scale_audit']=dict(
            maximum_undamped_natural_angular_frequency=float(np.sqrt(max(eigvalsh(stiffness,effective)))),
            max_frequency_times_radius_over_c=float(np.sqrt(max(eigvalsh(stiffness,effective)))*A_RAD[-1]/C_DIMENSIONLESS),
            max_omitted_inductive_electric_energy_over_initial=float(np.max(electric)/e0),
            leading_magnetic_dipole_radiation_integral_over_initial=float(np.trapezoid(radiation,data[:,0])/e0),
            conservative_max_radiation_power_times_duration_over_initial=float(np.max(radiation)*END/e0),
            status='A posteriori small-parameter diagnostics along MQS evolution. Omitted electric storage and outgoing radiation are not falsely included in its exact reduced ledger.')
        label=('aligned' if sign>0 else 'opposed')+('_lossless' if not np.any(resistance) else '')
        np.savez_compressed(OUT/(label+'_history.npz'),history=data,state=states,
                            columns=np.array(['t','K_relative','E_driver','U_B','U_out','heat','W_driver','W_induction','outer_flux','dipole_coordinate']))
    return row

def geometric_controls():
    # Same total magnetic energy, radically different exterior organization.
    dark=np.array([1.,-DIPOLE[0]/DIPOLE[1]])
    outer=np.array([0.,1.])
    dark/=np.sqrt(dark@L@dark)
    outer/=np.sqrt(outer@L@outer)
    cases=[]
    for name,om in [('signed_cancelled',dark),('outer_shell_only',outer)]:
        ub,pieces,uo=magnetic_radial_integral(om)
        cases.append(dict(name=name,omega=om.tolist(),magnetic_energy=ub,exterior_energy=uo,
                          exterior_fraction=uo/ub,radial_region_energies=pieces.tolist()))
    # Continuum uniform-density relative rotation: j_phi proportional r sinθ.
    # Approximate its exact shell moments with midpoint shell radii.
    refinement=[]
    for n in [16,32,64,128,256,512,1024]:
        edges=np.linspace(0,1,n+1);a=(edges[:-1]+edges[1:])/2
        m=np.diff(edges**5)
        kernel=1/np.maximum.outer(a,a)**3
        ub_coefficient=float(m@kernel@m)
        f=1/(3*ub_coefficient)
        refinement.append(dict(shells=n,exterior_fraction=f,analytic=7/30,error=f-7/30))
    assert abs(cases[0]['exterior_energy'])<1e-29
    assert abs(cases[1]['exterior_fraction']-1/3)<1e-14
    assert abs(refinement[-1]['error'])<2e-6
    assert np.all(np.linalg.eigvalsh(L)>0)
    current_mass=np.diag(I_REL)+L
    return dict(L=L.tolist(),L_out=L_OUT.tolist(),cases=cases,continuum_refinement=refinement,
                total_magnetic_fraction_of_current_mechanical_plus_magnetic_eigenvalue_bounds=eigvalsh(L,current_mass).tolist(),
                exterior_fraction_of_available_energy_upper=float(DIPOLE@np.linalg.solve(current_mass,DIPOLE)/3),
                note='Rayleigh bounds from independently specified inductance and material inertia, not selected transfer efficiencies.')

def main():
    rows=[]
    for sign in [1.,-1.]:
        for dt in [.08,.04,.02,.01]:
            r=run(sign,dt,record=dt==.01);rows.append(r)
            print(json.dumps({k:r[k] for k in ['sign','dt','max_complete_energy_relative_error','final_state_error_vs_exact_exponential']}),flush=True)
    lossless=run(1.,.01,np.zeros(2),record=True)
    mismatch=run(1.,.01,feedback=.5)
    for r in rows:
        assert r['max_exterior_fraction']<=1/3+1e-12
        assert r['max_direct_field_geometry_error']<1e-14
    for r in rows:
        if r['dt']==.01:
            assert r['max_complete_energy_relative_error']<1e-8
            assert r['final_state_error_vs_exact_exponential']<1e-8
            assert max(r['max_separate_ledger_errors'])<1e-9
    assert mismatch['max_complete_energy_relative_error']>.01
    out=dict(scope=__doc__,input_data=dict(radii=A_RAD.tolist(),charge_labels=Q_CHARGE.tolist(),
        material_relative_inertias=I_REL.tolist(),driver_inertias=J_DRIVER.tolist(),spring_constants=K_SPRING.tolist(),
        resistance_torques=R_DRAG.tolist(),equivalent_sheet_conductance_dimensionless=(Q_CHARGE**2/(6*np.pi*R_DRAG)).tolist(),
        initial_driver_angle=ANGLE,final_time=END,c_dimensionless=C_DIMENSIONLESS,
        units='Outer source radius a0, time t0, inertia I0. Charge unit sqrt(18*pi*I0/(mu0*a0)); energy unit I0/t0². mu0=18*pi in these dimensionless variables.',
        retained='Minimal charged coupling, Maxwell magnetic energy, reciprocal induction, complete source-energy and heat accounting.',
        newly_specified='All finite device geometry, material inertias, springs, friction and initial driver preparations. No planetary or observed magnetic amplitude enters.'),
        geometry=geometric_controls(),convergence_runs=rows,lossless_control=lossless,
        inconsistent_half_feedback_negative_control=mismatch,
        check_status='All accepted tests passed; the deliberately inconsistent feedback control violates complete energy as expected.')
    (OUT/'finite_driver_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'accepted':True,'fine_peaks':[r['exact_solution_peaks'] for r in rows if r['dt']==.01],
                      'mismatch_relative_energy_error':mismatch['max_complete_energy_relative_error']}),flush=True)

if __name__=='__main__':main()
