"""Finite-driver magnetic allocation chapter for the new synthesis only."""
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent


def add(d):
    results = json.loads((HERE / 'finite_driver_results.json').read_text())
    fine = [r for r in results['convergence_runs'] if r['dt'] == .01]
    d.h1('Exact inductive geometry for a finite material class', 'finite-inductive-geometry')
    d.p('A source-energy allowance becomes an actual magnetic allocation only after a material evolution is supplied. The following test provides one explicitly: two neutral pairs of oppositely charged spherical shell profiles, each coupled to a finite mechanical driver. The magnetic fields start at zero. No observed field, chosen magnetic efficiency, or prescribed current history enters. The geometry is exact within the fixed-profile magnetostatic class; the subsequent evolution is a controlled magnetoquasistatic reduction, not a full causal Maxwell solution.')
    d.p('For shell pair <i>i</i>, let each charge magnitude be <i>q</i><sub>i</sub>, its radius be <i>a</i><sub>i</sub>, and the relative angular velocity of its two species be ω<sub>i</sub>. The net charge density cancels. Eliminating the common bulk motion at fixed bulk angular momentum leaves a positive relative inertia. The relative current and its dipole moment are')
    d.eq([r'K_{phi,i}=\frac{q_i\omega_i}{4\pi a_i}\sin\theta,\qquad m_i=\frac{q_i a_i^2\omega_i}{3},',
          r'I_i=\frac{I_{+,i}I_{-,i}}{I_{+,i}+I_{-,i}},\qquad K_{\rm rel}=\frac{1}{2}\boldsymbol{\omega}^{T}I\boldsymbol{\omega}.'])
    d.p('The field is uniform inside an individual shell and dipolar outside. Integrating the combined field over all space, including mutual energy and its sign, gives the symmetric inductive inertia matrix. For an enclosing radius <i>R</i>,')
    d.eq([r'U_B=\frac{1}{2}\boldsymbol{\omega}^{T}L\boldsymbol{\omega},\qquad L_{ij}=\frac{\mu_0q_iq_j\min(a_i,a_j)^2}{18\pi\max(a_i,a_j)},',
          r'U_{\rm out}(R)=\frac{\mu_0}{12\pi R^3}\left(\sum_i m_i\right)^2.'])
    d.p('This counts the cross energy once through the quadratic form. Adding separate isolated-shell energies would lose the interference. With ordered radii and cumulative signed moments <i>M</i><sub>j</sub>, a telescoping identity makes the organization penalty explicit:')
    d.eq([r'M_j=\sum_{i\leq j}m_i,\qquad R=a_N,',
          r'U_B=3U_{\rm out}(R)+\frac{\mu_0}{4\pi}\sum_{j=1}^{N-1}M_j^2\left(a_j^{-3}-a_{j+1}^{-3}\right).'])
    d.p('Hence the exterior fraction lies between zero and one third. The upper bound is attained by an outermost current shell alone. Opposite signed moments can cancel the exterior dipole while retaining positive interior magnetic energy. This is a geometric result, not a saturation efficiency. The continuous dipolar-current limit replaces the sum by 3 times the integral of <i>M</i>(<i>r</i>)²/<i>r</i>⁴; uniform-density relative rotation then gives an exterior fraction 7/30, consistent with the separate uniform-ball calculation.')

    d.h1('A finite driver calculates the allocation', 'finite-inductive-evolution')
    d.p('Let θ be the relative material angles and φ the angles of finite mechanical reservoirs, with velocities ω and ν. Positive diagonal matrices <i>J</i>, <i>K</i> and <i>R</i><sub>d</sub> describe driver inertia, torsional springs and relative friction. Eliminating the quasistatic Maxwell field produces an inductive inertia <i>I</i>+<i>L</i>. The reduced Lagrangian and reciprocal equations are')
    d.eq([r'\mathcal{L}_{\rm red}=\frac{1}{2}\boldsymbol{\omega}^{T}(I+L)\boldsymbol{\omega}+\frac{1}{2}\boldsymbol{\nu}^{T}J\boldsymbol{\nu}-\frac{1}{2}(\boldsymbol{\theta}-\boldsymbol{\phi})^{T}K(\boldsymbol{\theta}-\boldsymbol{\phi}),',
          r'(I+L)\dot{\boldsymbol{\omega}}=-K(\boldsymbol{\theta}-\boldsymbol{\phi})-R_d\boldsymbol{\omega},\qquad J\dot{\boldsymbol{\nu}}=K(\boldsymbol{\theta}-\boldsymbol{\phi}).'])
    d.p('The induced electric field is already nonzero when a displaced spring first accelerates the current; its small storage is quantified below. The constraints maintain the spherical profiles and do no radial work. These springs and profiles specify a test material class, not a fluid planetary interior. Friction deposits heat in the same closed system. A resistive sheet realizes the torque coefficient through <i>R</i><sub>d,i</sub>=<i>q</i><sub>i</sub>²/(6πΣ<sub>i</sub>), where Σ is sheet conductance. The complete reduced energy and the independent transfers obey')
    d.eq([r'H=K_{\rm rel}+U_B+E_{\rm driver}+U_{\rm heat},\qquad \dot H=0,',
          r'E_{\rm driver}=\frac{1}{2}\boldsymbol{\nu}^{T}J\boldsymbol{\nu}+\frac{1}{2}(\boldsymbol{\theta}-\boldsymbol{\phi})^{T}K(\boldsymbol{\theta}-\boldsymbol{\phi}),',
          r'\dot W_{\rm driver}=-\boldsymbol{\omega}^{T}K(\boldsymbol{\theta}-\boldsymbol{\phi}),\quad \dot E_{\rm driver}=-\dot W_{\rm driver},\quad \dot U_{\rm heat}=\boldsymbol{\omega}^{T}R_d\boldsymbol{\omega},',
          r'\frac{d}{dt}(K_{\rm rel}+U_B)=\dot W_{\rm driver}-\dot U_{\rm heat},\qquad \dot U_B=\boldsymbol{\omega}^{T}L\dot{\boldsymbol{\omega}}.'])
    d.p('In canonical variables, the current energy is one half of <i>p</i><sup>T</sup>(<i>I</i>+<i>L</i>)<sup>−1</sup><i>p</i>; adding magnetic energy again would double count it. The all-space field energy also already includes the exterior. At a finite enclosing boundary its transfer is checked directly from the induced electric field and the Poynting vector:')
    d.eq(r'\oint_{r=R}\mathbf{S}\cdot d\mathbf{A}=\frac{\mu_0m\dot m}{6\pi R^3}=\frac{dU_{\rm out}}{dt},\qquad m=\sum_i m_i.')
    d.p('The one-shell lossless limit gives an analytic allocation before any numerical integration. Put <i>A</i>=<i>I</i>+<i>L</i> and start with a displaced driver, φ=φ<sub>0</sub>, with zero velocities and current. The initial energy is <i>E</i><sub>0</sub>=<i>k</i>φ<sub>0</sub>²/2. Then')
    d.eq([r'\Omega^2=k\left(\frac{1}{A}+\frac{1}{J}\right),\qquad \frac{U_B(t)}{E_0}=\frac{L}{A}\frac{J}{A+J}\sin^2(\Omega t),',
          r'\frac{U_{\rm out}(t)}{E_0}=\frac{1}{3}\frac{U_B(t)}{E_0}.'])
    d.p('The factor <i>L</i>/<i>A</i> is the inductive share of the current-mode energy; <i>J</i>/(<i>A</i>+<i>J</i>) accounts for recoil of the finite driver. Both follow from the supplied material and geometry. The two-shell test adds mutual induction, signed interference and returned heat to this analytic limit.')
    d.p('Choose radius, time and inertia units <i>a</i><sub>0</sub>, <i>t</i><sub>0</sub>, <i>I</i><sub>0</sub>, charge unit [18π<i>I</i><sub>0</sub>/(μ<sub>0</sub><i>a</i><sub>0</sub>)]<sup>1/2</sup>, and energy unit <i>I</i><sub>0</sub>/<i>t</i><sub>0</sub>². The slow-time scale <i>ct</i><sub>0</sub>/<i>a</i><sub>0</sub>=10000 is specified before evolving. The remaining dimensionless inputs are all new test data:')
    d.table(['Input', 'Inner', 'Outer'], [
        ['Radius a; charge q', '0.55; 1', '1; 1'],
        ['Relative inertia I; driver inertia J', '0.20; 0.70', '0.40; 1.10'],
        ['Spring K; resistance Rd', '0.80; 0.03', '1.20; 0.05'],
        ['Initial driver angle: aligned / opposed', '0.20 / 0.20', '0.20 / −0.20'],
    ], widths=[2.0,1,1], padding=5)
    d.p('Both preparations have zero initial current, magnetic field and velocities, and the same available energy <i>E</i><sub>0</sub>=0.04. Only the relative signs of the initial driver displacements differ. The inductive matrix has entries <i>L</i><sub>11</sub>=0.55, <i>L</i><sub>22</sub>=1 and <i>L</i><sub>12</sub>=<i>L</i><sub>21</sub>=0.3025. Its eigenvalues are 0.397997 and 1.152003; those of <i>I</i>+<i>L</i> are 0.631005 and 1.518995. The material and field quadratic energies are therefore positive.')

    d.h1('Calculated organization, convergence and limits', 'finite-inductive-results')
    rows=[]
    for r,label in zip(fine,['Aligned','Opposed']):
        p=r['exact_solution_peaks']
        rows.append([label, f"{100*p['total_magnetic']['fraction_of_initial']:.4f}%", f"{100*p['exterior_dipole']['fraction_of_initial']:.4f}%", f"{p['exterior_dipole']['time']:.6f}"])
    d.table(['Preparation', 'Peak UB / E0', 'Peak Uout / E0', 'Exterior peak time / t0'], rows, widths=[1,1,1,1.3])
    d.p('These are computed peaks over 80 time units; total and exterior maxima need not occur together. Nearly equal maximum total magnetic allocation gives a 2.22-fold difference in peak exterior dipole energy. The calculation supplies the transfer and organization instead of installing either as an efficiency. It is a finite conversion and decay experiment, not a self-sustaining dynamo or a selected long-term amplitude.')
    d.fig(HERE / 'finite-driver-allocation.png', 'Finite-driver allocation from the coupled equations. The complete total includes material kinetic energy, driver energy, total magnetic energy and heat. Exterior dipole energy is part of the total magnetic energy, not an additional term. The lower panels show the early evolution and the exact organization bound. Both preparations begin with the same finite driver energy and zero current.')
    d.p('Material inertia strengthens the energy allowance. With <i>A</i>=<i>I</i>+<i>L</i> and <i>d</i><sub>i</sub>=<i>q</i><sub>i</sub><i>a</i><sub>i</sub>² in the specified units, the Rayleigh bound is')
    d.eq(r'\frac{U_{\rm out}}{K_{\rm rel}+U_B}\leq\frac{\mathbf d^{T}A^{-1}\mathbf d}{3}=0.241732145,\qquad \frac{U_{\rm out}}{E_0}\leq0.241732145.')
    d.p('This bound follows from the declared inertias and geometry; neither preparation saturates it. A fixed volume and the same complete reduced energy therefore permit different exterior histories. The source conversion is consistent with both at this approximation order; their omitted electric and radiative corrections and a full nonspherical source boundary have not been equated. Its numerical value does not choose one without the material class and preparation.')
    d.h2('Checks and controlled approximation')
    d.p('Time steps 0.08, 0.04, 0.02 and 0.01 show fourth-order state convergence against an independent matrix-exponential solution. At the finest step the state errors are below 2.3×10<sup>−9</sup> and the largest relative complete-energy error is 4.65×10<sup>−10</sup>. Four power ledgers are integrated separately, including the outer Poynting flux; their absolute residuals are below 3×10<sup>−11</sup>. Regional field integrals independently reproduce the inductive quadratic form. A deliberately inconsistent half-strength induction feedback produces a 31.55% energy error and is rejected. A lossless control retains conservative exchange with zero heat.')
    d.p('The maximum natural frequency satisfies ω<sub>max</sub><i>a</i><sub>0</sub>/<i>c</i>=1.5844×10<sup>−4</sup>, and all relative surface speeds satisfy <i>v</i>/<i>c</i>&lt;1.506×10<sup>−5</sup>. Evaluating the leading omitted induction electric storage gives at most 1.93×10<sup>−9</sup> of the initial energy. The leading magnetic-dipole radiation estimate over the full interval is below 1.52×10<sup>−11</sup> of that energy; the conservative maximum-power-times-duration estimate is below 4.46×10<sup>−11</sup>. Generic retardation corrections scale as (ω<i>a</i>/<i>c</i>)². These are consistency diagnostics of the reduction, not a claim of an exact radiative Maxwell solution or a rigorous bound on every observable.')
    d.p('Reproduction and the full derivation are in <i>evolution/FINITE-DRIVER-AND-ORGANIZATION.txt</i>, <i>evolve_finite_inductive_driver.py</i>, <i>check_exact_nested_energy.py</i> and their JSON audit records. The stronger conclusion is limited and constructive: a declared charged-material model can calculate the allocation, while a source-energy scalar alone still does not select the observed planetary magnetic field.')
