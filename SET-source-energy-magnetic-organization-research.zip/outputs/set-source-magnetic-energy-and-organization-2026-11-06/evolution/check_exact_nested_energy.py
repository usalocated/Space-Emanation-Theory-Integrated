"""Symbolic source-current, field-energy and boundary-work identities."""
from pathlib import Path
import sys,json
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
sys.path.insert(0,str(ROOT/'outputs/set-invariant-library/vendor'))
import sympy as s

a,R,mu=s.symbols('a R mu',positive=True)
m1,m2,w1,w2,q1,q2=s.symbols('m1 m2 w1 w2 q1 q2',real=True)
checks={}
def check(name,expression):
    value=s.factor(s.simplify(expression))
    assert value==0,(name,value)
    checks[name]='exact zero'

# Independent analytic integration of B² in the three radial regions.
inner=mu/(6*s.pi)*(m1/a**3+m2/R**3)**2*a**3
between=mu/(12*s.pi)*(m1**2*(a**-3-R**-3)+2*(m2/R**3)**2*(R**3-a**3))
outside=mu*(m1+m2)**2/(12*s.pi*R**3)
total=s.factor(inner+between+outside)
kernel=mu/(4*s.pi)*(m1**2/a**3+(2*m1*m2+m2**2)/R**3)
check('piecewise field integration gives full self and mutual magnetic energy',total-kernel)
check('exact organization penalty above three exterior energies',total-3*outside-mu/(4*s.pi)*(a**-3-R**-3)*m1**2)
check('cancelled exterior retains positive interior energy',total.subs(m2,-m1)-mu/(4*s.pi)*(a**-3-R**-3)*m1**2)

L=mu/(18*s.pi)*s.Matrix([[q1**2*a,q1*q2*a**2/R],[q1*q2*a**2/R,q2**2*R]])
w=s.Matrix([w1,w2])
check('minimal-coupling inductive inertia equals full Maxwell energy',
      total.subs({m1:q1*a**2*w1/3,m2:q2*R**2*w2/3})-(w.T*L*w)[0]/2)
check('positive inductance determinant',s.det(L)-(mu/(18*s.pi))**2*q1**2*q2**2*a*(R**3-a**3)/R**2)

m,mdot,r,theta=s.symbols('m mdot r theta',real=True,positive=True)
Ephi=-mu*mdot*s.sin(theta)/(4*s.pi*r**2)
Btheta=mu*m*s.sin(theta)/(4*s.pi*r**3)
surface_flux=s.integrate(-Ephi*Btheta/mu*2*s.pi*r**2*s.sin(theta),(theta,0,s.pi))
check('vacuum boundary Poynting flux equals change of exterior energy',
      surface_flux-s.diff(mu*m**2/(12*s.pi*r**3),m)*mdot)

# Current shape j_phi = j0 r^p sinθ gives cumulative moment M(r)~r^(p+4).
p=s.symbols('p',positive=True)
coefficient=1+3/(2*p+5)
fraction=s.factor(1/(3*coefficient))
check('uniform relative-rotation ball fraction',fraction.subs(p,1)-s.Rational(7,30))
check('outer shell limit',s.limit(fraction,p,s.oo)-s.Rational(1,3))

# Common generator and finite driver: keep the complete inductive inertia.
i1,i2,j1,j2,k1,k2,r1,r2=s.symbols('i1 i2 j1 j2 k1 k2 r1 r2',positive=True)
d1,d2,v1,v2=s.symbols('delta1 delta2 driver_velocity1 driver_velocity2',real=True)
inertia=s.diag(i1,i2)+L
force=s.Matrix([-k1*d1-r1*w1,-k2*d2-r2*w2])
wdot=inertia.inv()*force
driver_acc=s.Matrix([k1*d1/j1,k2*d2/j2])
current_and_field_rate=(w.T*inertia*wdot)[0]
driver_and_spring_rate=j1*v1*driver_acc[0]+j2*v2*driver_acc[1]+k1*d1*(w1-v1)+k2*d2*(w2-v2)
heat_rate=r1*w1**2+r2*w2**2
check('finite-driver material-field-heat balance',current_and_field_rate+driver_and_spring_rate+heat_rate)
check('driver work debited exactly once',driver_and_spring_rate-(k1*d1*w1+k2*d2*w2))

# One-shell, one-finite-driver lossless limit: allocation in closed form.
ii,ll,jj,kk,phi0,tt=s.symbols('I L J k phi0 t',positive=True)
aa=ii+ll
frequency=s.sqrt(kk*(1/aa+1/jj))
delta=-phi0*s.cos(frequency*tt)
omega=jj/(aa+jj)*phi0*frequency*s.sin(frequency*tt)
nu=-aa/(aa+jj)*phi0*frequency*s.sin(frequency*tt)
initial=kk*phi0**2/2
check('analytic finite-driver current equation',aa*s.diff(omega,tt)+kk*delta)
check('analytic finite-driver reservoir equation',jj*s.diff(nu,tt)-kk*delta)
allocation=ll*jj/(aa*(aa+jj))*s.sin(frequency*tt)**2
check('analytic finite-driver magnetic allocation',ll*omega**2/(2*initial)-allocation)
check('analytic finite-driver energy partition',
      (aa*omega**2+jj*nu**2+kk*delta**2)/2-initial)

out=dict(all_passed=True,count=len(checks),checks=checks,
  exact_two_shell_energy=str(total),exact_inductance_matrix=str(L),
  continuous_profile_exterior_fraction=str(fraction),
  analytic_one_shell_magnetic_allocation=str(allocation),
  domain='0<a<R, positive relative/driver inertias and springs, nonnegative resistance; signed moments and charges permitted. Magnetoquasistatic fixed-profile approximation.')
(OUT/'exact_nested_energy_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'all_passed':True,'checks':len(checks),'continuous_profile_fraction':str(fraction)}))
