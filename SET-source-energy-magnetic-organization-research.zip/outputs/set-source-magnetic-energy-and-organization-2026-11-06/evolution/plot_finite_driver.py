"""Render the scientific comparison from already computed trajectories."""
from pathlib import Path
import os
import sys
sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR'] = str(OUT / '.mplconfig')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

aligned = np.load(OUT / 'aligned_history.npz')['history']
opposed = np.load(OUT / 'opposed_history.npz')['history']
e0 = .04
plt.rcParams.update({'font.size': 10, 'axes.titlesize': 11, 'axes.labelsize': 10,
                     'font.family': 'DejaVu Sans', 'svg.fonttype': 'none'})
fig, axs = plt.subplots(2, 2, figsize=(11, 7.4), constrained_layout=True)
colors = {'driver':'#777777', 'material':'#C67C00', 'magnetic':'#0072B2', 'heat':'#009E73'}
for ax, data, title in zip(axs[0], [aligned, opposed], ['Aligned finite drivers', 'Opposed finite drivers']):
    t = data[:, 0]
    for col, label, color in [(2, 'Driver', colors['driver']), (1, 'Material kinetic', colors['material']),
                             (3, 'Total magnetic', colors['magnetic']), (5, 'Heat', colors['heat'])]:
        ax.plot(t, data[:, col]/e0, label=label, color=color, lw=1.1)
    ax.plot(t, (data[:, 1]+data[:, 2]+data[:, 3]+data[:, 5])/e0,
            color='black', ls='--', lw=1.0, label='Complete total')
    ax.set(xlabel='Time / t₀', ylabel='Energy / initial driver energy', title=title,
           xlim=(0, 80), ylim=(-.025, 1.075))
    ax.grid(alpha=.18)
axs[0, 0].legend(loc='center right', fontsize=8, ncol=1, framealpha=.96)
ax=axs[1, 0]
for data, label, color in [(aligned,'Aligned','#0072B2'), (opposed,'Opposed','#D55E00')]:
    mask = data[:, 0] <= 15
    ax.plot(data[mask, 0], data[mask, 3]/e0, ls='--', lw=1.2, color=color, label=label + ': total magnetic')
    ax.plot(data[mask, 0], data[mask, 4]/e0, lw=1.8, color=color, label=label + ': exterior dipole')
ax.set(xlabel='Time / t₀', ylabel='Energy / initial driver energy',
       title='Calculated allocation and exterior organization', xlim=(0,15), ylim=(0,.34))
ax.grid(alpha=.18)
ax.legend(loc='upper right', fontsize=8, framealpha=.96)
ax=axs[1, 1]
for data,label,color in [(aligned,'Aligned','#0072B2'),(opposed,'Opposed','#D55E00')]:
    mask=(data[:,0]>0) & (data[:,0]<=15)
    ax.plot(data[mask,0],data[mask,4]/data[mask,3],color=color,lw=1.4,label=label)
ax.axhline(1/3,color='black',lw=1.1,ls='--',label='Exact geometry bound 1/3')
ax.set(xlabel='Time / t₀',ylabel='Exterior dipole / total magnetic energy',
       title='Organization changes without a chosen efficiency',xlim=(0,15),ylim=(-.01,.36))
ax.grid(alpha=.18)
ax.legend(loc='lower right',fontsize=8,framealpha=.96)
fig.savefig(OUT / 'finite-driver-allocation.png', dpi=200)
fig.savefig(OUT / 'finite-driver-allocation.svg')
plt.close(fig)
print(OUT / 'finite-driver-allocation.png')
