"""Check chapter API and every equation without writing outside this folder."""
from pathlib import Path
import os
import sys
import json
import re
import importlib.util
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(HERE/'.mplconfig')
from matplotlib.mathtext import MathTextParser
from matplotlib.font_manager import FontProperties

class CheckDraft:
    def __init__(self):
        self.equations=[];self.sections=[];self.figures=[]
    def h1(self,text,key=None):self.sections.append(text)
    def h2(self,text):pass
    def p(self,text,keep=False):pass
    def eq(self,latex,key=None):
        for part in ([latex] if isinstance(latex,str) else latex):
            part=re.sub(r'\\(mathcal|mathbf)\s+([A-Za-z])',r'\\\1{\2}',part)
            part=re.sub(r'\\sqrt(?![\{\[])\s*([A-Za-z0-9])',r'\\sqrt{\1}',part)
            self.equations.append(part)
    def table(self,headers,rows,widths=None,padding=7):
        assert all(len(r)==len(headers) for r in rows)
    def note(self,title,text):pass
    def fig(self,path,caption,width=1):
        assert Path(path).is_file();self.figures.append(str(path))
    def pagebreak(self):pass

spec=importlib.util.spec_from_file_location('chapter',HERE/'chapter.py')
chapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(chapter)
d=CheckDraft();chapter.add(d)
parser=MathTextParser('agg')
sizes=[]
for text in d.equations:
    parsed=parser.parse('$'+text+'$',dpi=72,prop=FontProperties(size=13))
    width,height=parsed.width,parsed.height
    scale=min(1,(6.9*72-48)/width)
    sizes.append(dict(latex=text,width_at_13pt=float(width),height=float(height),
                      expected_effective_font=13*scale))
out=dict(sections=d.sections,math_lines_checked=len(sizes),equations=sizes,figures=d.figures)
(HERE/'chapter-render-check.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(sections=len(d.sections),math_lines_checked=len(sizes),
                     smallest_math_font=min(s['expected_effective_font'] for s in sizes))))
