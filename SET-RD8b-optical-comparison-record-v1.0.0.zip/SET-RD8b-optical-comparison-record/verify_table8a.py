"""Reproduce the published comparison table from frozen contrasts (NumPy only)."""
from pathlib import Path
import json, numpy as np
R=Path(__file__).resolve().parent
summary=json.loads((R/'SUMMARY.json').read_text())
def chisq(y,c):return float(y@np.linalg.solve(c,y))
rows=[]
for label,name,count in [('Pantheon+','pantheonplus',7),('DES-Dovekie','des-dovekie',7)]:
 d=np.load(R/'grouped'/f'{name}-recomputed-arrays.npz')
 cov=d['covariance'][:count,:count];o=d['observed_contrast_mag'][:count]
 vals=[chisq(o,cov),chisq(o-d['old_prediction_contrast_mag'][:count],cov),chisq(o-d['new_prediction_contrast_mag'][:count],cov)]
 rows.append(dict(dataset=label,N=count,baseline=vals[0],original_a=vals[1],new_b=vals[2]))
d=np.load(R/'union/union-comparison-arrays.npz');cov=d['covariance_individual'];o=d['individual_observed']
rows.append(dict(dataset='Union2.1 individuals',N=260,baseline=chisq(o,cov),original_a=chisq(d['individual_residual_a'],cov),new_b=chisq(d['individual_residual_b'],cov)))
for row,ref in zip(rows,summary['comparisons'][:3]):
 for k,rk in [('baseline','chi2_baseline'),('original_a','chi2_old'),('new_b','chi2_new')]:assert abs(row[k]-ref[rk])<1e-7,(row,k,ref[rk])
print(json.dumps({'checks_passed':9,'table8a':rows},indent=2))
