"""Figure 12a: exact archived group contrasts, three stacked print panels.

Bundled Python + ReportLab; PDF is vector and PNG is rendered at 300 dpi.
This changes presentation only. All data and marginal bars are copied from
the verified calculation record and independently compared with its CSV/JSON.
"""
from pathlib import Path
import csv,json,hashlib,subprocess,sys,math
import numpy as np
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor,Color,white
from PIL import Image

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
SOURCE=ROOT/'outputs/set-new-optical-mapping-supernova-test-2026-11-15'
PREFIX=HERE/'figure12a-supernova-mapping-comparison'
sourcefiles=[SOURCE/'grouped/grouped-results.json',SOURCE/'grouped/all15-comparison.csv',
             SOURCE/'union/union-grouped-comparison.csv',SOURCE/'union/union-results.json',
             SOURCE/'make_comparison_plot.py',SOURCE/'verification/independent-mapping-checks.json']
grouped=json.loads(sourcefiles[0].read_text())
union=json.loads(sourcefiles[3].read_text())
with sourcefiles[1].open() as f: grouped_csv=list(csv.DictReader(f))
with sourcefiles[2].open() as f: union_csv=list(csv.DictReader(f))
panels=[]
checks=[]

def close(a,b,name):
    difference=abs(float(a)-float(b))
    assert difference<2e-15,(name,a,b,difference)
    checks.append({'check':name,'absolute_difference':difference})

for name,n in [('Pantheon+',8),('DES-Dovekie',7)]:
    rows=grouped['catalogs'][name]['rows']
    secondary=[r for r in grouped_csv if r['catalogue']==name]
    assert len(rows)==len(secondary)==n
    for i,(a,b) in enumerate(zip(rows,secondary)):
        for key in ['z_mean','observed_flux','observed_flux_1sigma_low',
                    'observed_flux_1sigma_high','old_a_flux','new_b_flux','baseline_flux']:
            close(a[key],b[key],f'{name}:group{i+1}:{key}:JSON_vs_CSV')
        # The bars are the asymmetric flux transform of marginal magnitude sigma.
        close(a['observed_flux_1sigma_low'],a['observed_flux']*10**(-.4*a['sigma_mag']),f'{name}:group{i+1}:lower_bar')
        close(a['observed_flux_1sigma_high'],a['observed_flux']*10**(.4*a['sigma_mag']),f'{name}:group{i+1}:upper_bar')
    panels.append({'name':name,'rows':[
        {'z':r['z_mean'],'observed':r['observed_flux'],'low':r['observed_flux_1sigma_low'],
         'high':r['observed_flux_1sigma_high'],'old_a':r['old_a_flux'],'new_b':r['new_b_flux'],
         'baseline':r['baseline_flux'],'n_objects':r['n_objects'],
         'formal_b':r['beyond_canonical_K_zero']} for r in rows]})

assert len(union_csv)==len(union['grouped_rows'])==7
for i,(a,b) in enumerate(zip(union_csv,union['grouped_rows'])):
    for key in ['z_mean','observed_relative_brightness','observed_flux_1sigma_low',
                'observed_flux_1sigma_high','a_relative_brightness','b_relative_brightness',
                'baseline_relative_brightness']:
        close(a[key],b[key],f'Union:group{i+1}:{key}:CSV_vs_JSON')
    obs=float(a['observed_relative_brightness']);sig=float(a['sigma_mag'])
    close(a['observed_flux_1sigma_low'],obs*10**(-.4*sig),f'Union:group{i+1}:lower_bar')
    close(a['observed_flux_1sigma_high'],obs*10**(.4*sig),f'Union:group{i+1}:upper_bar')
panels.append({'name':'Union2.1 · 260 targets','rows':[
    {'z':float(r['z_mean']),'observed':float(r['observed_relative_brightness']),
     'low':float(r['observed_flux_1sigma_low']),'high':float(r['observed_flux_1sigma_high']),
     'old_a':float(r['a_relative_brightness']),'new_b':float(r['b_relative_brightness']),
     'baseline':float(r['baseline_relative_brightness']),'n_objects':int(r['n_objects']),
     'formal_b':False} for r in union_csv]})

assert [len(p['rows']) for p in panels]==[8,7,7]
assert sum(r['formal_b'] for p in panels for r in p['rows'])==1
assert panels[0]['rows'][-1]['formal_b']
assert sum(r['n_objects'] for r in panels[2]['rows'])==260
assert all(r['baseline']==1. for p in panels for r in p['rows'])
assert all(r['low']<=r['observed']<=r['high'] for p in panels for r in p['rows'])

fontroot=Path('/System/Library/Fonts/Supplemental')
pdfmetrics.registerFont(TTFont('FigureArial',str(fontroot/'Arial.ttf')))
pdfmetrics.registerFont(TTFont('FigureArialBold',str(fontroot/'Arial Bold.ttf')))
W,H=6.1*72,6.5*72
cv=canvas.Canvas(str(PREFIX.with_suffix('.pdf')),pagesize=(W,H),pageCompression=1)
cv.setTitle('Supernova brightness: original and new SET optical mappings')
cv.setAuthor('Erik Echeverria')
cv.setSubject('Archived fixed group predictions and marginal observational uncertainty')
obs=HexColor('#27313A');old=HexColor('#A86624');new=HexColor('#276D94')
muted=HexColor('#64717C');axis=HexColor('#8A959E');grid=HexColor('#E4E8EB')
left,right=48,14
plotw=W-left-right

def text(x,y,string,size=8.3,color=obs,bold=False,align='left'):
    cv.setFillColor(color)
    cv.setFont('FigureArialBold' if bold else 'FigureArial',size)
    {'left':cv.drawString,'center':cv.drawCentredString,'right':cv.drawRightString}[align](x,y,string)

def marker(x,y,kind,size=3,color=obs,hollow=False):
    cv.setStrokeColor(color);cv.setLineWidth(.8 if not hollow else 1.05)
    cv.setFillColor(white if hollow else color)
    if kind=='circle':cv.circle(x,y,size,stroke=1,fill=1)
    elif kind=='square':cv.rect(x-size,y-size,2*size,2*size,stroke=1,fill=1)
    elif kind=='triangle':
        p=cv.beginPath();p.moveTo(x,y+size);p.lineTo(x-size*.9,y-size*.72)
        p.lineTo(x+size*.9,y-size*.72);p.close();cv.drawPath(p,stroke=1,fill=1)

def legend_marker(x,y,label,kind,color,hollow=False):
    marker(x,y+2.3,kind,2.65,color,hollow)
    text(x+10,y,label,8.1)

# One shared legend, two compact rows, no in-image manuscript figure title.
legend_marker(52,452,'Observed ±1σ','circle',obs)
legend_marker(203,452,'Original a','triangle',old,True)
legend_marker(321,452,'New b','square',new)
cv.setStrokeColor(axis);cv.setLineWidth(.75);cv.setDash(3,2)
cv.line(48,440,63,440);cv.setDash()
text(70,437.7,'Baseline = 1',8.1)
legend_marker(203,437.7,'b: formal continuation','square',new,True)

plot_records=[]
for p,bottom,xmax in zip(panels,[316,184,52],[1.66,1.24,1.24]):
    ph=98.;xmin=.06;ymin=.40;ymax=1.04
    xx=lambda z:left+(z-xmin)/(xmax-xmin)*plotw
    yy=lambda b:bottom+(b-ymin)/(ymax-ymin)*ph
    text(left,bottom+ph+9,p['name'],9.6,bold=True)
    for value in [.4,.6,.8,1.]:
        py=yy(value)
        cv.setStrokeColor(axis if value==1 else grid)
        cv.setLineWidth(.75 if value==1 else .5)
        cv.setDash(3,2) if value==1 else cv.setDash()
        cv.line(left,py,left+plotw,py);cv.setDash()
        text(left-7,py-2.8,f'{value:.1f}',8,color=muted,align='right')
    cv.setStrokeColor(axis);cv.setLineWidth(.55)
    cv.line(left,bottom,left,bottom+ph)
    cv.line(left,bottom,left+plotw,bottom)
    xticks=np.arange(.2,xmax,.2)
    for value in xticks:
        px=xx(value);cv.line(px,bottom,px,bottom-3)
        text(px,bottom-13,f'{value:.1f}',8,color=muted,align='center')

    for r in p['rows']:
        x=xx(r['z']);yo=yy(r['observed']);yl,yh=yy(r['low']),yy(r['high'])
        # Validate every marker and bar is visible; no clipped high-z group.
        for val in [r['low'],r['high'],r['observed'],r['old_a'],r['new_b']]:
            assert ymin<val<ymax,(p['name'],r,val)
        assert xmin<r['z']<xmax
        cv.setStrokeColor(obs);cv.setLineWidth(.75)
        cv.line(x,yl,x,yh);cv.line(x-2.5,yl,x+2.5,yl);cv.line(x-2.5,yh,x+2.5,yh)
        marker(x,yo,'circle',2.25,obs)
        marker(x,yy(r['old_a']),'triangle',3.5,old,True)
        marker(x,yy(r['new_b']),'square',2.45 if not r['formal_b'] else 3.1,new,r['formal_b'])
        plot_records.append(dict(panel=p['name'],**r,
            x_point=x,y_observed_point=yo,y_low_point=yl,y_high_point=yh,
            y_old_a_point=yy(r['old_a']),y_new_b_point=yy(r['new_b'])))
    if p['name']=='Pantheon+':
        r=p['rows'][-1]
        # A dashed leader flags only the extrapolated b point, never its
        # observed datum or the still-valid original-a prediction.
        tx=xx(1.16);ty=yy(.426)
        text(tx,ty,'formal b',7.6,color=new)
        cv.setStrokeColor(new);cv.setLineWidth(.65);cv.setDash(2.2,1.8)
        cv.line(tx+36,ty+2,xx(r['z'])-4,yy(r['new_b'])-1)
        cv.setDash()

cv.saveState();cv.translate(12,235);cv.rotate(90)
text(0,0,'Nearby-normalized relative brightness',9.1,align='center')
cv.restoreState()
text(left+plotw/2,15,'Redshift group (weighted mean)',9.1,align='center')
cv.showPage();cv.save()

poppler=Path('/Users/usalocated/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override/pdftoppm')
subprocess.run([str(poppler),'-singlefile','-r','300','-png',str(PREFIX.with_suffix('.pdf')),str(PREFIX)],check=True)
im=Image.open(PREFIX.with_suffix('.png'))
assert im.size==(1830,1950),im.size
hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sourcefiles}
audit={'source_data_unchanged':True,'no_fitting':True,'source_hashes':hashes,
       'panel_group_counts':[8,7,7],'total_group_predictions':22,
       'total_observed_points':22,'total_old_a_points':22,'total_new_b_points':22,
       'formal_b_group_count':1,'formal_b_group':'Pantheon+ group8',
       'formal_b_group_objects':16,'formal_b_group_objects_beyond_K_zero':12,
       'uncertainties':'Marginal asymmetric 1sigma flux intervals, unchanged from archived magnitude covariance diagonal',
       'no_residual_subpanels':True,'shared_legend':True,'size_inches':[6.1,6.5],
       'PNG_dimensions':list(im.size),'PNG_dpi':300,'PDF_vector':True,
       'numeric_crosschecks':checks,'plotted_arrays':panels,'plot_coordinates_points':plot_records,
       'runtime':sys.executable,'render_method':'Bundled ReportLab vector PDF + bundled pdftoppm300dpi',
       'figure_png_sha256':hashlib.sha256(PREFIX.with_suffix('.png').read_bytes()).hexdigest(),
       'figure_pdf_sha256':hashlib.sha256(PREFIX.with_suffix('.pdf').read_bytes()).hexdigest()}
(HERE/'figure12a-data-and-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
(HERE/'figure12a-source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
(HERE/'FIGURE12A-AUDIT.txt').write_text(
    'Figure12a — three stacked panels,6.1in by6.5in.\n'
    'All8 Pantheon+,7 DES-Dovekie and7 Union groups retained.\n'
    'Each panel displays baseline1, observed central values and unchanged marginal1sigma bars, originala and newb.\n'
    'FinalPantheon newb only is hollow and identified by a dashed leader as formalcontinuation; its observation and olda remain ordinary points.\n'
    'No residual subpanels, no data reweighting, no fit, no removed group.\n'
    f'{len(checks)} numeric crosschecks compare plotted source arrays to independent CSV/JSON and rederive the marginal flux interval endpoints.\n'
    'All marker and error-bar endpoints fall inside plotlimits. Sharedlegend, no in-imageFigure12a heading.\n'
    'PDF is vector; PNG is1830x1950pixels rendered at300dpi. Sourcehashes and exact plotted arrays accompany the figure.\n'
    'Visual inspection still required after generation.\n')
print(json.dumps({'png':str(PREFIX.with_suffix('.png')),'pdf':str(PREFIX.with_suffix('.pdf')),
                  'crosschecks':len(checks),'dimensions':im.size},indent=2))
