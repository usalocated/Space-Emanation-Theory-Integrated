RD8b optical comparison calculation record — 15 November 2026

This record accompanies the surgical clarification of Sections11.8,12.3 and
AppendicesJ/P. The original a and newer b predictions use unchanged source
inputs, target membership, nearby-reference weights and released covariance.
No response parameter or intercept was fitted in this transfer test.

Quick reproduction of Table8a:
  python verify_table8a.py
Requires Python and NumPy. The saved arrays contain the original and new
per-object distances/predictions, observational contrasts and covariance.
The three table comparisons use exactly the same rows for a and b. The
highest Pantheon+ group is preserved in the arrays and CSVs as a formal b
continuation, separately from the supported seven-group comparison.

SUMMARY.json retains statistics, scopes and degrees of freedom. The source
verification directory records the independent continuous domain checks and
source/ray evolution. Input provenance and memberships are retained in each
catalogue subdirectory. Figure arrays, drawing code and checks are in figure/.
The figure code retains its original workspace-relative source paths; the
exact displayed arrays are also stored in figure12a-data-and-audit.json.
The original full research scripts remain in the workspace research record
set-new-optical-mapping-supernova-test-2026-11-15; this package is the compact
comparison record, not a replacement for the full observational releases.

SHA256SUMS.json hashes the contents of this record. No publication has been
performed; the manuscript and record are local review artifacts.
