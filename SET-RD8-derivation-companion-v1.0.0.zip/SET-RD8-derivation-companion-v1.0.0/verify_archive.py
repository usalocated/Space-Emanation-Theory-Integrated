"""Verify the packaged files against SHA256SUMS.json before rerunning checks."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
hashes=json.loads((root/'SHA256SUMS.json').read_text())
errors=[]
for name,expected in hashes.items():
 p=root/name
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:errors.append(name)
if errors:raise SystemExit('Checksum mismatch: '+', '.join(errors))
print(str(len(hashes))+' packaged file checksums verified.')
