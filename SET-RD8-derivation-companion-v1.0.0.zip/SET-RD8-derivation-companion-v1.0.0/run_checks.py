"""Run the portable RD8 derivation checks; optional symbolic/ODE checks on request."""
from pathlib import Path
import argparse, json, platform, subprocess, sys
import importlib.metadata as metadata
p=argparse.ArgumentParser()
p.add_argument('--all',action='store_true',help='Also run symbolic/ODE checks (SymPy, mpmath and SciPy required)')
a=p.parse_args()
root=Path(__file__).resolve().parent
(root/'results').mkdir(exist_ok=True)
scripts=['scripts/check_exact_rational.py','scripts/check_rd8.py','scripts/check_phase_and_data.py']
if a.all:scripts+=['optional/check_selection_delay.py','optional/check_selection_supplement.py','optional/check_orbit_delay_independent.py']
records=[]
for name in scripts:
 result=subprocess.run([sys.executable,str(root/name)],cwd=root,text=True,capture_output=True)
 log=root/'results'/(Path(name).stem+'.log')
 log.write_text(result.stdout+result.stderr)
 records.append({'script':name,'returncode':result.returncode})
 print(name+(': PASS' if result.returncode==0 else ': FAIL'))
 if result.returncode:
  print(result.stdout+result.stderr)
  raise SystemExit(result.returncode)
versions={}
for name in ['numpy','sympy','mpmath','scipy']:
 try:versions[name]=metadata.version(name)
 except metadata.PackageNotFoundError:pass
report={'python':platform.python_version(),'platform':platform.system()+' '+platform.machine(),'dependencies':versions,'scripts':records,'status':'All requested checks passed. Checks test the stated identities and model calculations, not observational accuracy or foundational uniqueness.'}
(root/'results/reproduction-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
