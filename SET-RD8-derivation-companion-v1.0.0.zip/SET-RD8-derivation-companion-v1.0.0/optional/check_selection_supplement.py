"""Independent exact checks of upstream selection and delay reparametrization."""
import json
from pathlib import Path
OUT=Path(__file__).resolve().parents[1]/'results'/'optional'
OUT.mkdir(parents=True,exist_ok=True)
import sympy as s

h, alpha, n = s.symbols('h alpha n', positive=True)
H = s.Matrix([[h, h - 1], [h - 1, h]])
e = s.Matrix([-alpha, 1])
checks = {}
checks['line_matrix_local_response'] = s.factor(
    (e.T * H.inv() * e)[0] - 2 * alpha
    - h * (alpha - 1)**2 / (2 * h - 1))
psi, chi = s.sqrt(alpha * n), alpha * s.sqrt(alpha * n)
checks['delay_Jacobian'] = s.simplify(
    s.Matrix([psi, chi]).jacobian([alpha, n]).det() + alpha / 2)
a1, a2, n1, n2 = s.symbols('a1 a2 n1 n2')
product = sum(
    (s.diff(psi, alpha) * ad + s.diff(psi, n) * nd)
    * (s.diff(chi, alpha) * ad + s.diff(chi, n) * nd)
    for ad, nd in [(a1, n1), (a2, n2)])
expected = (3*n*(a1*a1+a2*a2)+4*alpha*(a1*n1+a2*n2)
            +alpha**2/n*(n1*n1+n2*n2))/4
checks['delay_energy_transform'] = s.simplify(product - expected)

m1, m2, j1, j2, r1, r2, phi, z = s.symbols(
    'm1 m2 j1 j2 r1 r2 phi z', positive=True)
phi2 = phi - m1/(2*r1) + m1/(2*r2)
residuals = s.Matrix([
    phi - m1/(2*r1) - m2/(2*r2),
    z+s.Rational(1, 2)*(-m1*phi/r1+m1*j1/r1**3
                       -m2*phi2/r2+m2*j2/r2**3),
    m1*j1/(2*r1*r1)-m1*m1/(4*r1),
    m2*j2/(2*r2*r2)-m2*(2*m1+m2)/(4*r2)])
root = {j1: m1*r1/2, j2: (m1+m2/2)*r2,
        phi: m1/(2*r1)+m2/(2*r2),
        z: m1*m2/(4*r2)*(1/r1-1/r2)}
for i, residual in enumerate(residuals):
    checks[f'two_shell_root_{i}'] = s.factor(
        residual.subs(root, simultaneous=True))
checks['two_shell_determinant'] = s.factor(
    residuals.jacobian([phi, z, r1, r2]).det().subs(root, simultaneous=True)
    -m1*m1*m2*(2*m1+m2)/(16*r1*r1*r2*r2))

record = {name: {'residual': str(value), 'passed': bool(value == 0)}
          for name, value in checks.items()}
assert all(value == 0 for value in checks.values())
(OUT/'selection-supplement-checks.json').write_text(
    json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
