import json
from pathlib import Path
OUT=Path(__file__).resolve().parents[1]/'results'/'optional'
OUT.mkdir(parents=True,exist_ok=True)
import sympy as s
import mpmath as mp

a, k, b, r, ar = s.symbols('a k b r ar', positive=True)
alpha=s.sqrt(a)
f=alpha/k
alpha_prime=b*k/(r**2*alpha)
old=alpha*(f-1)**2/f+2*r*alpha_prime*(f-1)
new=a/k+k+2*b/r-2*(alpha+r*alpha_prime)
checks={'energy_integrand':s.simplify(old-new)}
y, yp=s.symbols('y yp', real=True)
rr=2*b*s.exp(-y)
kk=-1/(s.exp(y)*yp)
checks['variable_change']=s.simplify((a/kk+kk)*(-rr*yp)-2*b*(a*yp**2+s.exp(-2*y)))
eta=s.symbols('eta', real=True)
end1=-4*b*a*eta/(1-a)-2*b*eta-4*b*s.sqrt(a)*(s.exp(-eta)-1)/(1-a)
end2=-2*b/(1-a)*((1-s.sqrt(a))**2*eta+2*s.sqrt(a)*(s.exp(-eta)-1+eta))
checks['combined_endpoint']=s.simplify(end1-end2)
checks['reference_euler_equation']=s.simplify(s.diff(a*s.diff(s.log(1-a),a),a)+(1-a)**-2)

mp.mp.dps=60
control=[]
for lam in [-1,0,1]:
    ll=mp.mpf(lam)
    def vals(t):
        aa=1-2*t+ll*t**3*(1-4*t)**2
        at=-2+ll*t**2*(1-4*t)*(3-20*t)
        kap=-at/2
        al=mp.sqrt(aa)
        ff=al/kap
        return aa,at,kap,al,ff
    def w(t):
        if t==0: return mp.mpf('0.5')
        aa,at,kap,al,ff=vals(t)
        return -(al*(ff-1)**2/ff-t*at*(ff-1)/al)/(2*t**2)
    def gap(t):
        if t==0 or lam==0: return mp.mpf('0')
        aa,at,kap,al,ff=vals(t)
        ss=ll*t**2*(1-4*t)**2/2
        et=-mp.log1p(-ss)
        et_t=ll*t*(1-4*t)*(1-8*t)/(1-ss)
        convex=mp.expm1(-2*et)+2*et
        return (aa*(et_t/at)**2+convex/(1-aa)**2)*(-at)
    ww=mp.quad(w,[0,mp.mpf('0.125'),mp.mpf('0.25')])
    ii=mp.quad(gap,[0,mp.mpf('0.125'),mp.mpf('0.25')])
    material=4*mp.sqrt(mp.mpf('.5'))*(1-mp.sqrt(mp.mpf('.5')))
    total=material+ww
    residual=total-1+ii
    control.append({'lambda':lam,'W_total':mp.nstr(total,25),'gap_I':mp.nstr(ii,25),'energy_identity_residual':mp.nstr(residual,8)})
    assert abs(residual)<mp.mpf('1e-45')
out={'symbolic':{key:{'residual':str(val),'passed':bool(val==0)} for key,val in checks.items()},'controls':control}
assert all(v==0 for v in checks.values())
(OUT/'selection-delay-checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
