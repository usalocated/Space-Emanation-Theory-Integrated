"""Optional symbolic and canonical-orbit verification; see README for dependencies."""
from pathlib import Path
import json
import math
import sympy as s
import mpmath as mp
import numpy as np
from scipy.integrate import solve_ivp

out = Path(__file__).resolve().parents[1]/'results'/'optional'
out.mkdir(parents=True,exist_ok=True)
checks = {}

# Derive the canonical momenta from the massive-particle Lagrangian.
r, vr, om, mu, c, m = s.symbols('r vr om mu c m', positive=True)
A = 1 - 2*mu/(c**2*r)
beta2 = A - vr**2/(A*c**2) - r**2*om**2/c**2
beta = s.sqrt(beta2)
lag = -m*c**2*beta
pr_lag = s.diff(lag, vr)
L_lag = s.diff(lag, om)
checks['polar_radial_momentum'] = s.simplify(pr_lag-m*vr/(A*beta))
checks['polar_angular_momentum'] = s.simplify(L_lag-m*r**2*om/beta)
checks['legendre_energy'] = s.simplify(pr_lag*vr+L_lag*om-lag-m*c**2*A/beta)

pr, L, E0 = s.symbols('pr L E0', real=True)
H = s.sqrt(A*E0**2+c**2*(A**2*pr**2+A*L**2/r**2))
checks['radial_hamilton_velocity'] = s.simplify(s.diff(H,pr)-c**2*A**2*pr/H)
checks['angular_hamilton_velocity'] = s.simplify(s.diff(H,L)-c**2*A*L/(H*r**2))
checks['clock_hamilton_derivative'] = s.simplify(s.diff(H,E0)-A*E0/H)
checks['radial_hamilton_force'] = s.simplify(
    -s.diff(H,r)+(s.diff(A,r)*E0**2+c**2*(2*A*s.diff(A,r)*pr**2
      +L**2*(s.diff(A,r)/r**2-2*A/r**3)))/(2*H))

# Derive Binet directly from the exact first integral.
w,j,eps = s.symbols('w j eps', positive=True)
Aw=1-2*mu*w/c**2
R=c**2*(eps**2-Aw)/j**2-Aw*w**2
checks['binet'] = s.simplify(s.diff(R,w)/2+w-mu/j**2-3*mu*w**2/c**2)

# Exact turning radii, not the leading Kepler p_N=j^2/mu.
p,e,x,z = s.symbols('p e x z', positive=True)
C = 1-(3+e**2)*x
j2 = c**2*p**2*x/C
eps2 = ((1-2*x)**2-4*e**2*x**2)/C
Rorb = R.subs({mu:c**2*p*x,j:s.sqrt(j2),eps:s.sqrt(eps2),w:(1+e*z)/p})
checks['turning_point_periapsis'] = s.factor(Rorb.subs(z,1))
checks['turning_point_apoapsis'] = s.factor(Rorb.subs(z,-1))
checks['radial_anomaly_factorization'] = s.factor(Rorb-e**2*(1-z**2)*(1-2*x*(3+e*z))/p**2)

# Full first-order particular solution, including the bounded terms.
phi,pN,b = s.symbols('phi pN b', positive=True)
w0 = (1+e*s.cos(phi))/pN
dw = 3*b/pN**2*(1+e**2/2+e*phi*s.sin(phi)-e**2*s.cos(2*phi)/6)
checks['full_first_order_correction'] = s.trigsimp(s.diff(dw,phi,2)+dw-3*b*w0**2)

# Exact conversion to isotropic radius: unequal areal delay factors become one n.
rho = s.symbols('rho', positive=True)
zz=b/(2*rho)
rr=rho*(1+zz)**2
AA=1-2*b/rr
n=(1+zz)**3/(1-zz)
checks['isotropic_radial_delay'] = s.factor(s.diff(rr,rho)**2/AA**2-n**2)
checks['isotropic_angular_delay'] = s.factor(rr**2/AA-n**2*rho**2)
al=(1-zz)/(1+zz)
checks['isotropic_index_alpha'] = s.factor(n-4/(al*(1+al)**2))

assert all(v == 0 for v in checks.values()), checks

# Independent integration: obtain all three equations by differentiating H.
# Dimensionless units: c=mu=m=1. p=50 is a mathematical illustration.
pp,ee=50.0,0.3
LL=math.sqrt(pp/(1-(3+ee**2)/pp))
hh=H.subs({mu:1,c:1,E0:1,L:LL})
rhs_f=s.lambdify((r,pr),(s.diff(hh,pr),-s.diff(hh,r),
                      s.diff(H,L).subs({mu:1,c:1,E0:1,L:LL})),'numpy')
energy_f=s.lambdify((r,pr),hh,'numpy')
def ode(t,y):
    return np.asarray(rhs_f(y[0],y[1]),dtype=float).reshape(3)
def pericenter(t,y):
    return y[1]
pericenter.direction=1
pericenter.terminal=False
periodN=2*math.pi*(pp/(1-ee**2))**1.5
initial=[pp/(1+ee),0.,0.]
sol=solve_ivp(ode,(0,2.3*periodN),initial,method='DOP853',
              rtol=3e-13,atol=3e-14,max_step=2.,events=pericenter)
event_y=sol.y_events[0]
assert len(event_y)>=3
cycle_angles=np.diff(event_y[:3,2])
mp.mp.dps=70
P=mp.mpf('50');ec=mp.mpf('.3')
exact_angle=mp.quad(lambda chi:1/mp.sqrt(1-2/P*(3+ec*mp.cos(chi))),[0,mp.pi,2*mp.pi])
energy_drift=float(np.max(np.abs(energy_f(sol.y[0],sol.y[1])/energy_f(*initial[:2])-1)))
angle_error=max(abs(float(v)-float(exact_angle)) for v in cycle_angles)
assert angle_error<1e-10
assert energy_drift<1e-11

# Current primary-source constants, with JPL approximate J2000 elements treated
# as a representative pair of exact turning-radius parameters of this model.
muM=mp.mpf('1.32712440041279419e20')
cc=mp.mpf('299792458')
au=mp.mpf('149597870700')
aM=mp.mpf('0.38709927')*au
eM=mp.mpf('0.20563593')
pM=aM*(1-eM**2)
xM=muM/(pM*cc**2)
bM=muM/cc**2
FM=mp.sqrt((1-2*xM)**2-4*eM**2*xM**2)
def phase(chi):
    return 1/mp.sqrt(1-2*xM*(3+eM*mp.cos(chi)))
def period_density(chi):
    v=1+eM*mp.cos(chi)
    return pM**mp.mpf('1.5')/mp.sqrt(muM)/v**2*FM/(1-2*xM*v)*phase(chi)
angleM=mp.quad(lambda chi:phase(chi)-1,[0,mp.pi,2*mp.pi])
periodM=mp.quad(period_density,[0,mp.pi,2*mp.pi])
proper_periodM=mp.quad(lambda chi:pM**mp.mpf('1.5')/mp.sqrt(muM)
    *mp.sqrt(1-(3+eM**2)*xM)/(1+eM*mp.cos(chi))**2*phase(chi),
    [0,mp.pi,2*mp.pi])
newtonian_periodM=2*mp.pi*mp.sqrt(aM**3/muM)
arcsec=180*3600/mp.pi
mercury={
 'mu_m3_s2':str(muM), 'c_m_s':str(cc), 'au_m':str(au),
 'a_m':str(aM), 'e':str(eM), 'p_m':str(pM), 'b_m':str(bM), 'x':str(xM),
 'leading_rad_per_cycle':str(6*mp.pi*xM),
 'leading_arcsec_per_cycle':str(6*mp.pi*xM*arcsec),
 'exact_arcsec_per_cycle':str(angleM*arcsec),
 'model_radial_reference_period_s':str(periodM),
 'model_radial_reference_period_day':str(periodM/86400),
 'model_radial_probe_proper_period_s':str(proper_periodM),
 'same_turning_radii_Newtonian_period_s':str(newtonian_periodM),
 'exact_arcsec_per_Julian_century_model_period':str(angleM*arcsec*36525*86400/periodM),
 'leading_arcsec_per_Julian_century_87_969_day_convention':str(6*mp.pi*xM*arcsec*36525/mp.mpf('87.969')),
 'clock_and_delay_profiles':[]
}
for label,chi in [('periapsis',mp.mpf(0)),('quadrature',mp.pi/2),('apoapsis',mp.pi)]:
    AM=1-2*xM*(1+eM*mp.cos(chi))
    mercury['clock_and_delay_profiles'].append({
     'location':label,
     'areal_r_m':str(pM/(1+eM*mp.cos(chi))),
     'radial_index_excess_ppb':str((1/AM-1)*mp.mpf(10)**9),
     'tangential_index_excess_ppb':str((1/mp.sqrt(AM)-1)*mp.mpf(10)**9),
     'phase_angle_excess_ppb':str((phase(chi)-1)*mp.mpf(10)**9),
     'angular_rate_ratio_excess_ppb':str((AM/FM-1)*mp.mpf(10)**9),
     'radial_rate_ratio_excess_ppb':str((AM/FM/phase(chi)-1)*mp.mpf(10)**9)
    })
result={
 'symbolic_checks':{k:str(v) for k,v in checks.items()},
 'canonical_flow':{'p_in_mu_over_c2':pp,'e':ee,
   'angles_from_two_radial_cycles':cycle_angles.tolist(),
   'angle_from_independent_quadrature':str(exact_angle),
   'maximum_absolute_angle_error_rad':angle_error,
   'maximum_relative_energy_drift':energy_drift},
 'Mercury_illustrative':mercury,
 'sources':{
  'JPL_constants':'https://ssd.jpl.nasa.gov/astro_par.html',
  'JPL_approximate_elements':'https://ssd.jpl.nasa.gov/planets/approx_pos.html',
  'Jacobi_optical_math_context':'https://arxiv.org/abs/1508.06755'},
 'scope':'No fit. Exact arithmetic identities test algebra, not the SET premises. Numerical Mercury orbit is isolated, spherical, static and test body; source rotation, other planets and full ephemeris are not included.'
}
(out/'orbit-delay-independent-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
