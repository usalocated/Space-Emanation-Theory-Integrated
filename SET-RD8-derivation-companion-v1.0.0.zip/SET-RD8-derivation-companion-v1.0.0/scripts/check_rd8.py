"""Independent checks of RD8's new variable and orbital-rate correspondences.

Uses the bundled Python and NumPy. No observations or parameters are fitted.
"""
from pathlib import Path
import json, math
import numpy as np

HERE=Path(__file__).resolve().parents[1]
rng=np.random.default_rng(8007)
worst={'field_density':0.,'jacobian':0.,'material_variation':0.,
       'boundary_variation':0.,'delay_inverse':0.,'phase_rate_ratio':0.}
def residual(a,b):
    return abs(a-b)/max(1.,abs(a),abs(b))

for _ in range(200):
    alpha=float(rng.uniform(.1,1.4));n=float(rng.uniform(.3,5.))
    ga=rng.normal(size=3);gn=rng.normal(size=3)
    psi=math.sqrt(alpha*n);chi=alpha*psi
    gp=psi/2*(ga/alpha+gn/n)
    gc=chi/2*(3*ga/alpha+gn/n)
    old=4*np.dot(gp,gc)
    new=3*n*np.dot(ga,ga)+4*alpha*np.dot(ga,gn)+alpha**2/n*np.dot(gn,gn)
    worst['field_density']=max(worst['field_density'],residual(old,new))
    Jac=np.array([[psi/(2*alpha),psi/(2*n)],[3*psi/2,alpha*psi/(2*n)]])
    worst['jacobian']=max(worst['jacobian'],residual(np.linalg.det(Jac),-alpha/2))
    da,dn=rng.normal(size=2);dpsi=Jac[0]@np.array([da,dn]);dchi=Jac[1]@np.array([da,dn])
    eps,stress=rng.normal(size=2)
    oldm=psi**6*eps*da-2*alpha*psi**5*stress*dpsi
    newm=alpha**3*n**3*((eps-stress)*da-alpha/n*stress*dn)
    worst['material_variation']=max(worst['material_variation'],residual(oldm,newm))
    normal=rng.normal(size=3);normal/=np.linalg.norm(normal)
    oldb=4*(np.dot(gc,normal)*dpsi+np.dot(gp,normal)*dchi)
    newb=np.dot(6*n*ga+4*alpha*gn,normal)*da+np.dot(4*alpha*ga+2*alpha**2/n*gn,normal)*dn
    worst['boundary_variation']=max(worst['boundary_variation'],residual(oldb,newb))
    matrix=rng.normal(size=(3,3));q=matrix.T@matrix+np.eye(3)
    D=q/alpha**2
    worst['delay_inverse']=max(worst['delay_inverse'],float(np.max(np.abs(np.linalg.inv(D)-alpha**2*np.linalg.inv(q)))))
    e=float(rng.uniform(.01,.9));P=float(rng.uniform(6+2*e+.1,1000.));xi=float(rng.uniform(0,2*math.pi))
    x=1/P;A=1-2*x*(1+e*math.cos(xi));K=1-2*x*(3+e*math.cos(xi));F=math.sqrt((1-2*x)**2-4*e*e*x*x)
    ra=A/F;rr=A*math.sqrt(K)/F
    worst['phase_rate_ratio']=max(worst['phase_rate_ratio'],residual(ra/rr,1/math.sqrt(K)))

# A quadrature of the exact excess, with algebraic cancellation removed.
mu=1.3271244004127942e20;c=299792458.;a=.38709927*149597870700.;e=.20563593
p=a*(1-e*e);x=mu/(p*c*c)
nodes,weights=np.polynomial.legendre.leggauss(128)
xi=math.pi*(nodes+1);z=2*x*(3+e*np.cos(xi));root=np.sqrt(1-z)
phase_excess=z/(root*(1+root))
angle=math.pi*np.dot(weights,phase_excess)
arcsec=angle*180*3600/math.pi
leading=6*math.pi*x*180*3600/math.pi
profiles=[]
for name,xi in [('periapsis',0.),('apoapsis',math.pi)]:
    A=1-2*x*(1+e*math.cos(xi));K=1-2*x*(3+e*math.cos(xi));F=math.sqrt((1-2*x)**2-4*e*e*x*x)
    profiles.append({'location':name,'angular_excess_ppb':(A/F-1)*1e9,'radial_excess_ppb':(A*math.sqrt(K)/F-1)*1e9})

assert all(v<2e-12 for v in worst.values()),worst
assert abs(arcsec-0.1035173147)<2e-9,arcsec
result={'sample_count':200,'maximum_scaled_residuals':worst,
        'Mercury':{'mu_m3_s2':mu,'a_m':a,'e':e,'p_m':p,
                   'exact_arcsec_per_cycle':arcsec,'leading_arcsec_per_cycle':leading,
                   'leading_arcsec_per_century_87_969_days':leading*36525/87.969,
                   'rate_profiles':profiles},
        'status':'All checks passed. These verify representations and calculations, not observational accuracy.'}
(HERE/'results').mkdir(exist_ok=True)
(HERE/'results/RD8-NEW-IDENTITY-CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
