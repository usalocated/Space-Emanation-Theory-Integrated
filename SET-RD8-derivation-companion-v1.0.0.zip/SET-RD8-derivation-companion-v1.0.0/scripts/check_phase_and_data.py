"""RD8 exact Mercury phase figure and independent arithmetic checks.

Authored with the bundled Python runtime, numpy and ReportLab. No fit, new
observational data or source-input adjustment. The phase formula and frozen
Mercury values are those already checked in the standalone delay manuscript.
"""
from pathlib import Path
from decimal import Decimal, localcontext
from fractions import Fraction
import csv
import hashlib
import json
import math
import subprocess

import numpy as np

HERE = Path(__file__).resolve().parents[1]
FIG = HERE/'figures'
RES = HERE/'results'
FIG.mkdir(parents=True, exist_ok=True)
RES.mkdir(parents=True, exist_ok=True)
BASE = HERE/'inputs/frozen-orbit-delay-independent-checks.json'
source = json.loads(BASE.read_text())
M = source['Mercury_illustrative']

# A small exact polynomial checker is sufficient for the new radial identity.
# Exponent tuples label powers of x, e and t=cos(xi); all coefficients are rational.
def poly(value):
    return value if isinstance(value, dict) else {(0,0,0): Fraction(value)}
def add(a,b):
    out=poly(a).copy()
    for k,v in poly(b).items(): out[k]=out.get(k,Fraction(0))+v
    return {k:v for k,v in out.items() if v}
def neg(a): return {k:-v for k,v in poly(a).items()}
def sub(a,b): return add(a,neg(b))
def mul(a,b):
    out={}
    for ka,va in poly(a).items():
        for kb,vb in poly(b).items():
            k=tuple(ka[i]+kb[i] for i in range(3))
            out[k]=out.get(k,Fraction(0))+va*vb
    return {k:v for k,v in out.items() if v}
def sq(a): return mul(a,a)
xP={(1,0,0):Fraction(1)}
eP={(0,1,0):Fraction(1)}
tP={(0,0,1):Fraction(1)}
wP=add(1,mul(eP,tP))
AP=sub(1,mul(2,mul(xP,wP)))
denP=sub(1,mul(xP,add(3,sq(eP))))
f2P=sub(sq(sub(1,mul(2,xP))),mul(4,mul(sq(eP),sq(xP))))
kP=sub(1,mul(2,mul(xP,add(3,mul(eP,tP)))))
# With p=c=1, numerator of the exact radial-energy bracket is this polynomial.
radial_identity=sub(sub(f2P,mul(AP,add(denP,mul(xP,sq(wP))))),
                    mul(mul(xP,sq(eP)),mul(sub(1,sq(tP)),kP)))
assert radial_identity == {}, radial_identity

with localcontext() as ctx:
    ctx.prec=70
    xd=Decimal(M['x'])
    ed=Decimal(M['e'])
    F=((1-2*xd)**2-4*ed**2*xd**2).sqrt()
    rate_rows=[]
    for name,t in [('perihelion',Decimal(1)),('aphelion',Decimal(-1))]:
        A=1-2*xd*(1+ed*t)
        K=1-2*xd*(3+ed*t)
        angular=A/F
        radial=A*K.sqrt()/F
        phase=1/K.sqrt()
        assert abs(angular/radial-phase)<Decimal('1e-65')
        rate_rows.append({
            'location':name,
            'angular_ratio':str(angular),
            'radial_ratio_limit':str(radial),
            'angular_excess_ppb':str((angular-1)*Decimal(10)**9),
            'radial_excess_ppb':str((radial-1)*Decimal(10)**9),
            'phase_excess_ppb':str((phase-1)*Decimal(10)**9),
        })

x=float(M['x'])
ecc=float(M['e'])
arcsec_per_rad=180/math.pi*3600
xi=np.linspace(0,2*math.pi,4001)
z=2*x*(3+ecc*np.cos(xi))
root=np.sqrt(1-z)
# Cancellation-resistant exact 1/sqrt(1-z)-1.
excess=z/(root*(1+root))
phase=np.zeros_like(xi)
phase[1:]=np.cumsum((excess[:-1]+excess[1:])*np.diff(xi)/2)*arcsec_per_rad

def gauss_phase(n):
    a,w=np.polynomial.legendre.leggauss(n)
    t=math.pi*(a+1)
    zz=2*x*(3+ecc*np.cos(t))
    rr=np.sqrt(1-zz)
    return float(math.pi*np.dot(w,zz/(rr*(1+rr)))*arcsec_per_rad)
phase64=gauss_phase(64)
phase128=gauss_phase(128)
expected=float(M['exact_arcsec_per_cycle'])
assert abs(phase128-expected)<1e-14
assert abs(phase64-phase128)<1e-14
assert abs(phase[-1]-expected)<1e-12

# Independently integrate the weak ray magnitude after z/d=tan(theta).
# Then 2bd/(d^2+z^2)^(3/2) dz=(2b/d) cos(theta) dtheta.
gn,gw=np.polynomial.legendre.leggauss(64)
theta=(math.pi/2)*gn
weak_deflection_coefficient=float((math.pi/2)*np.dot(gw,2*np.cos(theta)))
assert abs(weak_deflection_coefficient-4)<1e-13

# Check the new coordinate-rate comparisons away from apsides on multiple exact
# rational source/orbit samples; the symbolic polynomial above covers all x,e,t.
fraction_checks=[]
for xf,ef,tf in [(Fraction(1,100),Fraction(1,5),Fraction(1,3)),
                 (Fraction(1,50),Fraction(3,10),Fraction(-2,5)),
                 (Fraction(1,1000),Fraction(7,10),Fraction(4,5))]:
    A=1-2*xf*(1+ef*tf);D=1-(3+ef**2)*xf
    F2=(1-2*xf)**2-4*ef**2*xf**2
    K=1-2*xf*(3+ef*tf)
    eps2=F2/D;j2=xf/D;rad=1/(1+ef*tf)
    radial2=A*A/eps2*(eps2-A*(1+j2/(rad*rad)))
    newton_radial2=xf*ef*ef*(1-tf*tf)
    assert radial2/newton_radial2 == A*A*K/F2
    assert A*A*j2/(eps2*xf) == A*A/F2
    fraction_checks.append({'x':str(xf),'e':str(ef),'cos_xi':str(tf),'exact_residual':'0'})

with (RES/'mercury-phase-excess.csv').open('w',newline='') as f:
    out=csv.writer(f)
    out.writerow(['xi_rad','xi_fraction_of_2pi','dphi_dxi_minus_1','excess_ppb','cumulative_arcsec'])
    for row in zip(xi,xi/(2*math.pi),excess,excess*1e9,phase):
        out.writerow([format(float(v),'.17g') for v in row])

audit={
    'source_file':'inputs/frozen-orbit-delay-independent-checks.json','source_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),
    'inputs':{k:M[k] for k in ['mu_m3_s2','c_m_s','au_m','a_m','e','p_m','b_m','x']},
    'exact_polynomial_radial_identity':'F^2 - A[D+x(1+e t)^2] - x e^2(1-t^2)K = 0; every coefficient vanishes',
    'definitions':'D=1-(3+e^2)x; F^2=(1-2x)^2-4e^2x^2; A=1-2x(1+e t); K=1-2x(3+e t)',
    'rational_rate_checks':fraction_checks,
    'turning_point_rate_limits':rate_rows,
    'phase_gauss64_arcsec':phase64,'phase_gauss128_arcsec':phase128,
    'phase_dense_trapezoid_arcsec':float(phase[-1]),
    'phase_archived_arcsec':M['exact_arcsec_per_cycle'],
    'weak_ray_integral_coefficient':weak_deflection_coefficient,
    'weak_ray_analytic_primitive':'2b z/[d sqrt(d^2+z^2)], whose limits differ by 4b/d',
    'radial_infall_identity':'epsilon=1 implies beta=A; beta^2=A-rdot^2/(c^2 A) gives rdot^2=c^2 A^2(1-A)',
    'control':'The unchanged RD7 Appendix B control has the same A with B=1 and leading 4pi b/p rather than 6pi b/p; no control values were overwritten.',
    'scope':'Isolated spherical stationary test-body orbit. Frozen approximate J2000 turning points. Rate differences are exact-model matched-state calculations, not new observations. Existing century/period conventions remain unchanged.',
}
(RES/'orbit-additions-checks.json').write_text(json.dumps(audit,indent=2)+'\n')

print(json.dumps({'phase_gauss128_arcsec':phase128,'exact_polynomial_passed':True,'output':'results/mercury-phase-excess.csv'},indent=2))
