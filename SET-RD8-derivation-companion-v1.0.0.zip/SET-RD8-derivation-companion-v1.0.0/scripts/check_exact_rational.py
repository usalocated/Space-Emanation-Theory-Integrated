"""Exact rational checks copied from the approved RD8 selection edit validation."""
from pathlib import Path
from fractions import Fraction as F
import json

# Independent exact rational verification of the analytic transformation.
# Parameterize n=t^2/alpha, so psi=t and chi=alpha*t are rational.
# Check arbitrary independent variations and gradient components, not solved fields.
math_checks=0
for a in (F(1,5),F(2,3),F(1),F(7,4)):
 for t in (F(1,3),F(1),F(5,2)):
  n=t*t/a; psi=t; chi=a*t
  j11=psi/(2*a); j12=psi/(2*n)
  j21=3*chi/(2*a); j22=chi/(2*n)
  assert j11*j22-j12*j21 == -a/2
  for ga,gn,da,dn in ((F(2,7),F(-3,5),F(4,9),F(5,11)),(F(-1),F(3),F(-2),F(1,2))):
   gps=j11*ga+j12*gn; gch=j21*ga+j22*gn
   assert gps*gch == (3*n*ga*ga+4*a*ga*gn+a*a/n*gn*gn)/4
   dps=j11*da+j12*dn; dch=j21*da+j22*dn
   boundary_old=gch*dps+gps*dch
   boundary_new=((6*n*ga+4*a*gn)*da+(4*a*ga+2*a*a/n*gn)*dn)/4
   assert boundary_old == boundary_new
   eps=F(11,3); sig=F(7,5)
   wm_old=psi**6*(eps*da-2*a*sig*dps/psi)
   wm_new=a**3*n**3*((eps-sig)*da-a*sig*dn/n)
   assert wm_old == wm_new
   math_checks+=1

result={"exact_rational_checks":math_checks,"independent_positive_response_samples":12,"checks":["Jacobian","gradient contraction","boundary variation","material stress variation"],"status":"All exact residuals vanish."}
root=Path(__file__).resolve().parents[1]
(root/'results').mkdir(exist_ok=True)
(root/'results/exact-rational-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
