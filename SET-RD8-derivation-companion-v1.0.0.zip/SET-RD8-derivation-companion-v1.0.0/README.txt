SET RD8 derivation companion — version 1.0.0

Purpose
This archive accompanies Space Emanation Theory — Integrated Rough Draft 8.
It reproduces the new delay-variable and orbital-phase calculations and keeps
their independent checks, frozen inputs, original figure and equation mapping.
It contains no manuscript, no new data fit and no changed galaxy or cosmology
calculation. The companion is a reproducible mathematical record, not a new
observational test.

What is checked
1. Independent alpha and n variables reproduce the original field-gradient
   energy, Jacobian, physical material/stress variation and surface variation.
   The exact rational test checks 24 variation cases at 12 positive response
   points. A separately authored NumPy test checks 200 seeded random states.
2. The positive delay tensor and its inverse retain the same common probe
   energy. The static conformally flat variational class, source boundary,
   material measure and physical supports remain the stated ones.
3. The exact radial/angular rates for matched turning radii factor into the
   same phase integral. A polynomial identity is checked coefficient by
   coefficient over rational numbers; turning-point limits are evaluated at
   70-digit Decimal precision. The weak light-ray integral yields 4b/d at its
   retained first order.
4. The frozen Mercury model gives 0.1035173147527568 arcsec per radial cycle.
   The traditional leading-order 87.969-day conversion gives approximately
   42.9807 arcsec per Julian century. These are isolated spherical test-body
   calculations using the specified approximate J2000 elements, not a full
   ephemeris or fresh Mercury measurement.
5. Optional symbolic scripts check the source-energy gap, upstream selection
   identities, canonical Hamiltonian, Binet equation, isotropic coordinate
   transform and the independent integration of a representative orbit.

Main reproduction (Python 3.10 or later)
From the extracted companion directory:

  python3 -m venv .venv
  .venv/bin/python -m pip install -r requirements-core.txt
  .venv/bin/python run_checks.py

On Windows use .venv\Scripts\python.exe instead of .venv/bin/python.
The core requires only NumPy; the exact rational and Decimal work otherwise
uses the standard library. The verified packaging environment is Python
3.12.14, NumPy 2.3.5 on Darwin arm64. No network is needed after dependencies
are installed. All input and output paths are relative to the archive.

Optional complete symbolic/ODE checks

  .venv/bin/python -m pip install -r requirements-full.txt
  .venv/bin/python run_checks.py --all

Optional dependencies are SymPy, mpmath and SciPy. Their original passed
results are preserved. The packaging runtime did not supply these packages;
the packaging portability test runs the complete core suite. This is stated
in results/reproduction-report.json and provenance/PORTABILITY-TEST.txt.

Outputs
run_checks.py writes check logs and JSON summaries to results/. It regenerates
results/mercury-phase-excess.csv, with 4,001 rows covering one radial cycle.
The figure assets in figures/ are the unchanged RD8 figure; the CSV contains
every plotted point and the script contains the generating equations. Figure
rendering is not required to reproduce its numerical content.

Frozen inputs and provenance
inputs/frozen-inputs.json lists all source/orbit values and their primary
reference URLs. inputs/frozen-orbit-delay-independent-checks.json is the
unchanged high-precision independent calculation that supplied those values.
The phase script deliberately consumes that frozen input. Optional reruns
write separate results and never overwrite it.

frozen-results/ contains the previously passed checks and original phase
CSV. reviews/ contains the independent mathematical review and a concise
RD7-to-RD8 equation mapping and final revision change ledger. The ledger
records preservation of all original observational tables and media bytes,
12 original figures plus the new phase figure, and all 467 original equation
groups (466 literally preserved and one approved equivalent extension). With
29 inserted groups, there are 496 total. Selected new groups are RD8 24–25, 54, 67, 72–74, 118, 121–125,
133, 151–155, 296 and 402–410. Some review notes use the pre-renumbering
insertion labels; use equation-correspondence.json to resolve them.

provenance/source-manifest.json identifies the original research files and
hashes, and records the small portability-only adaptations. No original
manuscript or research script was modified to make this archive. Final PDF
and DOCX identifiers are recorded separately in provenance/.
SHA256SUMS.json records every other packaged file for integrity checking.
Before rerunning numerical checks, run: python3 verify_archive.py. Reproducing
results may intentionally update output files and environment metadata.

Comparison rules and scope
The rate comparisons hold source mass, turning radii, eccentricity, incoming
or outgoing phase and the same infinity-normalized reference time fixed.
At an apsis both radial speeds vanish; quoted radial ratios are limits.
They do not compare two trajectories at the same elapsed coordinate time.
An invertible delay representation preserves spatial response information.
Changing the physical radial coefficient to B=1 is a different field, and
its retained leading precession is 4pi b/p rather than 6pi b/p.
The static proof is used within its stated source and field class. These
checks verify the algebra, representations and model calculations; they do
not independently select every field structure or test empirical accuracy.
